/* Adds (prepends) key file to key ring file */
int addto_keyring(char *keyfile, char *ringfile);
