/*____________________________________________________________________________
	Copyright (C) 1996-1999 Network Associates, Inc.
	All rights reserved.

	$Id: CPacketWatch.h,v 1.5 1999/03/10 02:35:21 heller Exp $
____________________________________________________________________________*/
#ifndef CPACKETWATCH_H
#define CPACKETWATCH_H


class CPFWindow;

extern CPFWindow *gPacketWatch; 


#endif

