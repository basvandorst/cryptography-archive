//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PGPFone.rc
//
#define IDS_BROWSERERROR                28
#define IDS_INFOTEXT                    37
#define IDS_CREDITSTEXT                 38
#define IDD_ABOUTBOX                    100
#define IDP_SOCKETS_INIT_FAILED         104
#define IDR_MAINFRAME                   128
#define IDR_PGPFONTYPE                  129
#define IDB_ABOUT                       130
#define IDB_ABOUT8                      130
#define IDD_MODEM                       131
#define IDB_LOGO                        131
#define IDD_ENCRYPTION                  132
#define IDB_LOGO_MASK                   132
#define IDD_PHONE                       133
#define IDB_TRIANGLE                    133
#define IDD_FILETRANSFER                134
#define IDB_TRIANGLE_MASK               134
#define IDB_MICROPHONE                  135
#define IDB_MICROPHONE_MASK             136
#define IDB_VOLUME                      137
#define IDB_VOLUME_MASK                 138
#define IDR_SECURE                      143
#define IDR_INSECURE                    144
#define IDR_CONNECTED                   145
#define IDR_WAITING                     146
#define IDB_CREDITS8                    148
#define IDB_ABOUT4                      149
#define IDD_FTP                         149
#define IDB_ABOUT1                      150
#define IDI_RECVICON                    150
#define IDB_CREDITS4                    151
#define IDB_CREDITS1                    152
#define IDC_PREF_DECOMPRESSOR           1000
#define ID_CANCEL_SEND                  1000
#define IDC_ALT_DECOMPRESSOR            1001
#define ID_CANCEL_RECV                  1001
#define IDC_LISTEN_FOR_CALLS            1002
#define IDC_SENDLIST                    1002
#define IDC_SEND_LIST                   1002
#define IDC_PLAY_RING                   1003
#define IDC_RECVLIST                    1003
#define IDC_RECV_LIST                   1003
#define IDC_MODEM_CONNECTION            1004
#define IDC_SEND_PROGRESS               1004
#define IDC_INTERNET_CONNECTION         1005
#define IDC_RECV_PROGRESS               1005
#define IDC_FULLDUPLEX                  1006
#define IDC_SEND_FILE                   1006
#define IDC_IDENTITY                    1007
#define IDC_SEND_SIZE                   1007
#define IDC_NAME                        1008
#define IDC_RECV_FILE                   1008
#define IDC_NAMEEDIT                    1009
#define IDC_RECV_SIZE                   1009
#define IDC_IDINCOMING                  1010
#define IDC_WWWLINK                     1010
#define IDC_IDOUTGOING                  1011
#define IDC_BROWSE                      1011
#define IDC_IDUNENCRYPTED               1012
#define IDC_RECEIVE_FOLDER              1012
#define IDC_COM1                        1013
#define IDC_COM2                        1014
#define IDC_COM3                        1015
#define IDC_COM4                        1016
#define IDC_COM5                        1017
#define IDC_COM6                        1018
#define IDC_COM7                        1019
#define IDC_COM8                        1020
#define IDC_BAUD_RATE                   1021
#define IDC_PREF_ENCRYPTION             1022
#define IDC_1536_BITS                   1023
#define IDC_768_BITS                    1024
#define IDC_2048_BITS                   1025
#define IDC_1024_BITS                   1026
#define IDC_3072_BITS                   1027
#define IDC_4096_BITS                   1028
#define IDC_PREFERRED_PRIME             1029
#define IDC_CASTENCRYPTOR               1030
#define IDC_BLOWFISHENCRYPTOR           1031
#define IDC_3DESENCRYPTOR               1032
#define IDC_NOENCRYPTOR                 1033
#define IDC_PORT_SPEED                  1034
#define IDC_INIT_STRING                 1035
#define IDC_CREDITS                     1040
#define ID_FILE_ANSWER                  32771
#define ID_EDIT_PREFERENCES             32772
#define ID_VIEW_STATUS_INFO             32773
#define ID_VIEW_ENCODING_DETAILS        32774
#define ID_TRANSFER_FILE                32775
#define IDS_STATUS_SECURE               57638
#define IDS_STATUS_UNSECURE             57639
#define IDS_WEBLINK                     61204

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        151
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
