//////////////////////////////////////////////////////////////////////////////
// CPGPdiskAppWinutils.h
//
// Contains declarations for CPGPdiskAppWinutils.cpp.
//////////////////////////////////////////////////////////////////////////////

// $Id: CPGPdiskAppWinutils.h,v 1.5 1998/12/14 18:57:53 nryan Exp $

// Copyright (C) 1998 by Network Associates, Inc.
// All rights reserved.

#ifndef Included_CPGPdiskAppWinutils_h	// [
#define Included_CPGPdiskAppWinutils_h

// Nothing needed here.

#endif	// ] Included_CPGPdiskAppWinutils_h
