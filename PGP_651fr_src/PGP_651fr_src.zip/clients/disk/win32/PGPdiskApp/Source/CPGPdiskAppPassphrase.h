//////////////////////////////////////////////////////////////////////////////
// CPGPdiskAppPassphrase.h
//
// Declarations for CPGPdiskAppPassphrase.cpp.
//////////////////////////////////////////////////////////////////////////////

// $Id: CPGPdiskAppPassphrase.h,v 1.4 1998/12/14 18:57:39 nryan Exp $

// Copyright (C) 1998 by Network Associates, Inc.
// All rights reserved.

#ifndef Included_CPGPdiskAppPassphrase_h	// [
#define Included_CPGPdiskAppPassphrase_h

// Nothing needed here.

#endif	// ] Included_CPGPdiskAppPassphrase_h
