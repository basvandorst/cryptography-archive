//////////////////////////////////////////////////////////////////////////////
// CPGPdiskAppRegistry
//
// Declarations for CPGPdiskAppRegistry.cpp.
//////////////////////////////////////////////////////////////////////////////

// $Id: CPGPdiskAppRegistry.h,v 1.6 1998/12/14 18:57:43 nryan Exp $

// Copyright (C) 1998 by Network Associates, Inc.
// All rights reserved.

#ifndef Included_CPGPdiskAppRegistry_h	// [
#define Included_CPGPdiskAppRegistry_h

// Nothing needed here.

#endif	// ] Included_CPGPdiskAppRegistry_h
