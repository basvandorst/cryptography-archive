//////////////////////////////////////////////////////////////////////////////
// CPGPdiskAppErrors.h
//
// Declarations for CPGPdiskAppErrors.cpp
//////////////////////////////////////////////////////////////////////////////

// Copyright (C) 1998 by Network Associates, Inc.
// All rights reserved.

#ifndef Included_CPGPdiskAppErrors_h	// [
#define Included_CPGPdiskAppErrors_h

#include "PGPdiskPfl.h"

// Nothing needed here.

#endif	// ] Included_CPGPdiskAppErrors_h
