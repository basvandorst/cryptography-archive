//////////////////////////////////////////////////////////////////////////////
// CPGPdiskAppVolumes.h
//
// Contains declarations for CPGPdiskAppVolumes.cpp.
//////////////////////////////////////////////////////////////////////////////

// $Id: CPGPdiskAppVolumes.h,v 1.4 1998/12/14 18:57:48 nryan Exp $

// Copyright (C) 1998 by Network Associates, Inc.
// All rights reserved.

#ifndef Included_CPGPdiskAppVolumes_h	// [
#define Included_CPGPdiskAppVolumes_h

// Nothing needed here.

#endif	// ] Included_CPGPdiskAppVolumes_h
