//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by E:\Source\CLIENTS\DISK\win32\PGPdiskApp\PGPdiskApp.rc
//
#define IDC_BUYNOW_BUTTON               3
#define IDD_MAIN_DLG                    102
#define IDI_MAINFRAME                   128
#define IDD_UNMOUNT_DLG                 130
#define IDI_NEW                         136
#define IDI_MOUNT                       137
#define IDI_PREFS                       138
#define IDR_MAINDLG_ACCEL               149
#define IDD_ABOUTBOX_DLG                150
#define IDD_PROP_AUTO                   162
#define IDD_SINGLEPASS1_DLG             165
#define IDD_PROP_HOTKEY                 168
#define IDD_CONFIRMPASS1_DLG            169
#define IDD_SINGLEPASS2_DLG             170
#define IDD_GETUSERINFO_DLG             181
#define IDR_MAIN_MENU                   186
#define IDB_SPLASHSCREEN8               190
#define IDD_SPLASH_DLG                  191
#define IDI_UNMOUNT                     193
#define IDI_PGPDISK                     194
#define IDI_CAPSLOCK                    198
#define IDB_SIDEBAR1                    201
#define IDB_SPLASHSCREEN1               203
#define IDB_SIDEBAR8                    206
#define IDB_SPLASHSCREEN4               207
#define IDB_SIDEBAR4                    209
#define IDB_CREDITS4                    212
#define IDB_CREDITS1                    213
#define IDB_CREDITS8                    217
#define IDD_NAGBUY_DLG                  252
#define IDC_SIZE_EDIT                   1003
#define IDC_KB_CHECK                    1014
#define IDC_MB_CHECK                    1015
#define IDC_GB_CHECK                    1016
#define IDC_NEWPGPDISK                  1020
#define IDC_MOUNTPGPDISK                1023
#define IDC_PREFERENCES                 1024
#define IDC_UNMOUNTPGPDISK              1025
#define IDC_CHECK_UNMOUNT               1026
#define IDC_EDIT_UNMOUNT                1027
#define IDC_CHECK_SLEEP                 1029
#define IDC_CHECK_PREVENT               1030
#define IDC_HOTKEY_EDIT                 1052
#define IDC_CONFIRM_EDIT                1054
#define IDC_RO_CHECK                    1055
#define IDC_PASSPHRASE_EDIT             1056
#define IDC_HIDETYPE_CHECK              1057
#define IDC_QUALITY_BAR                 1066
#define IDC_ADK                         1066
#define IDC_DRIVE_COMBO                 1077
#define IDC_HOTKEY_CHECK                1082
#define IDM_ADDPASS                     1083
#define IDM_CHANGEPASS                  1084
#define IDM_REMOVEPASS                  1085
#define IDC_NEWPASSMSG_TEXT             1091
#define IDC_SINGLEPASSMSG_TEXT          1092
#define IDC_MINUTETEXT                  1094
#define IDM_ABOUT                       1097
#define IDC_CAPSLOCK_TEXT               1098
#define IDC_DISKNAME_TEXT               1099
#define IDM_NEWPGPDISK                  1100
#define IDC_SIZE_SPIN                   1100
#define IDC_DIRNAME_TEXT                1100
#define IDM_MOUNTPGPDISK                1101
#define IDM_UNMOUNTPGPDISK              1102
#define IDC_FREESIZE_TEXT               1102
#define IDM_PREFS                       1103
#define IDC_UNMOUNT                     1103
#define IDM_EXIT                        1104
#define IDC_EDIT_SPIN                   1104
#define IDM_HELPCONTENTS                1105
#define IDC_USER_EDIT                   1105
#define IDC_ORG_EDIT                    1106
#define IDM_PUBLICKEYS                  1106
#define IDC_SERIAL_EDIT                 1107
#define IDC_SIDEBAR                     1107
#define IDM_GLOBALCONVERT               1107
#define IDC_CREDITS                     1108
#define IDC_PGP_LINK                    1109
#define IDC_NAGBUYMSG_TEXT              1110
#define IDC_SEARCHSTATUS_TEXT           1115
#define IDC_PGPDISKS_LIST               1118
#define IDD_DISKWIZ_RANDOM              1119
#define IDD_DISKWIZ_PASSPHRASE          1121
#define IDD_DISKWIZ_CREATION            1122
#define IDC_PROGRESS_BAR                1123
#define IDC_RANDOM_BAR                  1123
#define IDD_DISKWIZ_VOLINFO             1123
#define IDD_DISKWIZ_INTRO               1124
#define IDD_DISKWIZ_DONE                1125
#define IDD_CONFIRMPASS2_DLG            1126
#define IDD_DISKWIZ_ADK                 1127
#define IDD_RANDDATA_DLG                1129
#define IDD_CVRTWIZ_INTRO               1130
#define IDD_CVRTWIZ_DONE                1131
#define IDD_CVRTWIZ_RANDOM              1132
#define IDD_CVRTWIZ_CONVERT             1133
#define IDD_GLOBWIZ_INTRO               1134
#define IDD_GLOBWIZ_DONE                1135
#define IDD_GLOBWIZ_SEARCH              1136
#define IDD_SINGLEPASS3_DLG             1137

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        253
#define _APS_NEXT_COMMAND_VALUE         1108
#define _APS_NEXT_CONTROL_VALUE         1119
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
