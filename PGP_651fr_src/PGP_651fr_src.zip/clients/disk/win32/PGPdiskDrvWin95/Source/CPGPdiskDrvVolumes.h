//////////////////////////////////////////////////////////////////////////////
// CPGPdiskDrvVolumes.h
//
// Declarations for CPGPdiskDrvVolumes.cpp.
//////////////////////////////////////////////////////////////////////////////

// $Id: CPGPdiskDrvVolumes.h,v 1.4 1998/12/14 19:00:09 nryan Exp $

// Copyright (C) 1998 by Network Associates, Inc.
// All rights reserved.

#ifndef Included_CPGPdiskDrvVolumes_h	// [
#define Included_CPGPdiskDrvVolumes_h

// Nothing needed here.

#endif	// ] Included_CPGPdiskDrvVolumes_h
