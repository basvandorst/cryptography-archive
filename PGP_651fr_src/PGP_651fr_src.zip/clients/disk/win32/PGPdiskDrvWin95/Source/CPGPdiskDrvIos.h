//////////////////////////////////////////////////////////////////////////////
// CPGPdiskDrvIos.h
//
// Declarations for CPGPdiskDrvIos.cpp.
//////////////////////////////////////////////////////////////////////////////

// $Id: CPGPdiskDrvIos.h,v 1.4 1998/12/14 19:00:07 nryan Exp $

// Copyright (C) 1998 by Network Associates, Inc.
// All rights reserved.

#ifndef Included_CPGPdiskDrvIos_h	// [
#define Included_CPGPdiskDrvIos_h

// Nothing needed here.

#endif	// ] Included_CPGPdiskDrvIos_h
