//////////////////////////////////////////////////////////////////////////////
// CPGPdiskDrvComm.h
//
// Declarations for CPGPdiskDrvComm.cpp.
//////////////////////////////////////////////////////////////////////////////

// $Id: CPGPdiskDrvComm.h,v 1.4 1998/12/14 19:00:00 nryan Exp $

// Copyright (C) 1998 by Network Associates, Inc.
// All rights reserved.

#ifndef Included_CPGPdiskDrvComm_h	// [
#define Included_CPGPdiskDrvComm_h

// Nothing needed here.

#endif	// ] Included_CPGPdiskDrvComm_h
