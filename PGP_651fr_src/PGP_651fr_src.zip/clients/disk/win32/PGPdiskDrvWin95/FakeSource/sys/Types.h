//////////////////////////////////////////////////////////////////////////////
// Types.h
//
// A fake source file designed to pacify the PFL.
//////////////////////////////////////////////////////////////////////////////

// $Id: Types.h,v 1.4 1999/02/13 04:24:34 nryan Exp $

// Copyright (C) 1998 by Network Associates, Inc.
// All rights reserved.

#ifndef Included_Types_h	// [
#define Included_Types_h

// Don't include both vtoolscp and vtoolsc.
#ifndef __vtoolscp_h_
#include <vtoolsc.h>
#endif	// __vtoolscp_h_

#endif	// ] Included_Types_h
