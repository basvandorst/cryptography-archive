//////////////////////////////////////////////////////////////////////////////
// Crtdbg.h
//
// A fake source file designed to pacify the PFL.
//////////////////////////////////////////////////////////////////////////////

// $Id: Crtdbg.h,v 1.3 1999/03/31 23:51:07 nryan Exp $

// Copyright (C) 1998 by Network Associates, Inc.
// All rights reserved.

#ifndef Included_Crtdbg_h	// [
#define Included_Crtdbg_h

#define	__w64
#include <vdw.h>

#endif	// ] Included_Crtdbg_h
