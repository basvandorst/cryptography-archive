//////////////////////////////////////////////////////////////////////////////
// CPGPdiskInterfaceVolumes.h
//
// Declarations for CPGPdiskInterfaceVolumes.cpp.
//////////////////////////////////////////////////////////////////////////////

// $Id: CPGPdiskInterfaceVolumes.h,v 1.3 1998/12/14 18:59:34 nryan Exp $

// Copyright (C) 1998 by Network Associates, Inc.
// All rights reserved.

#ifndef Included_CPGPdiskInterfaceVolumes_h	// [
#define Included_CPGPdiskInterfaceVolumes_h

// Nothing needed here.

#endif	// ] Included_CPGPdiskInterfaceVolumes_h
