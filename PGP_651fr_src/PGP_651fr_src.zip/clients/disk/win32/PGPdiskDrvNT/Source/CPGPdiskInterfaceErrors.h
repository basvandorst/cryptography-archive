//////////////////////////////////////////////////////////////////////////////
// CPGPdiskInterfaceErrors.h
//
// Ddeclarations for CPGPdiskInterfaceErrors.cpp.
//////////////////////////////////////////////////////////////////////////////

// $Id: CPGPdiskInterfaceErrors.h,v 1.3 1998/12/14 18:59:32 nryan Exp $

// Copyright (C) 1998 by Network Associates, Inc.
// All rights reserved.

#ifndef Included_CPGPdiskInterfaceErrors_h	// [
#define Included_CPGPdiskInterfaceErrors_h

// Nothing needed here.

#endif	// ] Included_CPGPdiskInterfaceErrors_h
