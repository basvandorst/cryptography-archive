extern int zipup(FILE *, FILE *);
