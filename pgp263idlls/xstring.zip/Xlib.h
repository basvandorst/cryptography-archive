#ifndef __XLIB_H__
#define __XLIB_H__

#ifndef DEBUG
  #define DEBUG  // release: clear this
#endif

#ifndef XString_i
  #define XString_i "XString.h"
#endif


#ifndef NULL
  #define NULL 0
#endif

#define X_ERR -1
#define X_OK  0

#ifdef DEBUG
  #include "assert.h"
  #define X_ASSERT(x) assert(x)
#else
  #define X_ASSERT(x)
#endif

#ifndef ABSTRACT
  #define ABSTRACT = 0
#endif

#ifndef XSIZE_T
  #define XSIZE_T unsigned long int
#endif

/* no longer reqired: STL's bool, true and false are used instead!
#ifndef XBOOL
#define XBOOL signed int
#define XTRUE 1
#define XFALSE 0
#endif
*/
#endif

