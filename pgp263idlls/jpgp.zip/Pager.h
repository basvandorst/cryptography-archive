// Pager.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPager dialog

class CPager : public CDialog
{
// Construction
public:
	CPager(const CString&, CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CPager)
	enum { IDD = IDD_PAGER };
	CString	m_FileStr;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPager)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPager)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
