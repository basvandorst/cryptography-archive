// RandAccum.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CRandAccum dialog

class CRandAccum : public CDialog
{
// Construction
public:
	CRandAccum(unsigned int inCount, CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CRandAccum)
	enum { IDD = IDD_TESTRND };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRandAccum)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	
	int m_Count;

	// Generated message map functions
	//{{AFX_MSG(CRandAccum)
	afx_msg void OnChangeInput();
	virtual void OnOK();
	virtual void OnCancel();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
