// pgptestDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPgptestDlg dialog

class CPgptestDlg : public CDialog
{
// Construction
public:
	CPgptestDlg(CString, CWnd* pParent = NULL);	// standard constructor
	int PGPOut ( const char *string) ;

	int m_RetCode;

// Dialog Data
	//{{AFX_DATA(CPgptestDlg)
	enum { IDD = IDD_PGPTEST_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPgptestDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

	
// Implementation
protected:
	HICON m_hIcon;
	CString m_CmdLine;

	// Generated message map functions
	//{{AFX_MSG(CPgptestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnCallpgp();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
