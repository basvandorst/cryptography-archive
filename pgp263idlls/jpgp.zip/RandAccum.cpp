// RandAccum.cpp : implementation file
//

#include "stdafx.h"
#include "pgptest.h"


#include "..\pgpdll.h"
#include "XString.h"

#include "RandAccum.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRandAccum dialog


CRandAccum::CRandAccum(unsigned int inCount, CWnd* pParent /*=NULL*/)
	: CDialog(CRandAccum::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRandAccum)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_Count = inCount;
}


void CRandAccum::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRandAccum)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRandAccum, CDialog)
	//{{AFX_MSG_MAP(CRandAccum)
	ON_EN_CHANGE(IDC_INPUT, OnChangeInput)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRandAccum message handlers

void CRandAccum::OnChangeInput() 
{
	// TODO: Add your control notification handler code here
	static BOOLEAN USERIN = TRUE;
	if (USERIN)
	{
		USERIN = FALSE;
		
		CString inputStr;
		CString outputStr;
		GetDlgItem(IDC_INPUT)->GetWindowText(inputStr);
		GetDlgItem(IDC_RNDOUTPUT)->GetWindowText(outputStr);
		
		outputStr += RANDEVENT(inputStr[0]) ? '.' : '?';
		inputStr = "";
		if (outputStr.GetLength()>20) outputStr = outputStr.Right(20);
		GetDlgItem(IDC_RNDOUTPUT)->SetWindowText(outputStr);
		
		GetDlgItem(IDC_INPUT)->SetWindowText(inputStr);

		m_Count--;
		GetDlgItem(IDC_COUNT)->SetWindowText(XString((int)m_Count)());
		if (m_Count < 0)
		{
			AfxMessageBox("Ok, that' enough");
			EndDialog(1);
		}


		USERIN = TRUE;
	}
	


}

void CRandAccum::OnOK() 
{
	// TODO: Add extra validation here
	
	// CDialog::OnOK();
}

void CRandAccum::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	// CDialog::OnCancel();
}

BOOL CRandAccum::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	GetDlgItem(IDC_COUNT)->SetWindowText(XString((int)m_Count)());
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
