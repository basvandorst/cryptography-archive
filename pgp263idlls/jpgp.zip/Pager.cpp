// Pager.cpp : implementation file
//

#include "stdafx.h"
#include "pgptest.h"
#include "Pager.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPager dialog


CPager::CPager(const CString& inFileStr, CWnd* pParent /*=NULL*/)
	: CDialog(CPager::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPager)
	m_FileStr = _T("");
	//}}AFX_DATA_INIT
	m_FileStr = inFileStr;
}


void CPager::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPager)
	DDX_Text(pDX, IDC_PAGE, m_FileStr);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPager, CDialog)
	//{{AFX_MSG_MAP(CPager)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPager message handlers
