#ifndef _PGPOUT_H_
#define _PGPOUT_H_

#if defined (JvP_DLL)

#include "stdio.h"


extern int JvP_fprintf( FILE *stream, const char *format ,...);
extern int JvP_fputs( const char *string, FILE *stream );
extern int JvP_fputc( int c, FILE *stream );

extern int JvP_in(char *strbuf, unsigned maxlen, int echo);

extern void JvP_Exit(int returnval);

extern void JvP_RandAcc( unsigned int count);

extern int JvP_PhantomRead (  void *buffer, size_t size, size_t count, FILE *stream );
extern int JvP_PhantomWrite(  const void *buffer, size_t size, size_t count, FILE *stream );

#define fprintf JvP_fprintf
#define fputs JvP_fputs
#define putc JvP_fputc
#define fputc JvP_fputc


#define exit JvP_Exit



#endif


#endif