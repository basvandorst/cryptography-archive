/*
 * crypt.h        1.1 4/30/95
 *
 *      (c) Copyright 1995 by Lance Cottrell. All right reserved.
 *      The author assumes no liability for damages resulting from the
 *      use of this software, even if the damage results from defects in
 *      this software. No warranty is expressed or implied.
 *
 *      This software is being distributed under the GNU Public Licence,
 *      see the file GNU.license for more details.
 *
 *                      - Lance Cottrell (loki@obscura.com) 4/23/95
 *
 */

#include <stdio.h>
#include <math.h>
#include <limits.h>
#include <time.h>
#include <stdlib.h>
#include <stddef.h>

#ifndef TRUE
#define TRUE 1
#define FALSE 0
#endif

typedef short unsigned Ukey[9];
typedef unsigned Ikey[7][10];
typedef unsigned Idata[5];
struct shadow_struct {
	int		x;
	unsigned	y;
};


long int **make_matrix(long int nrl,long int nrh,long int ncl,long int nch);
unsigned prand(unsigned n);
FILE  *tempfile(char *rootname);
FILE  *open_mix_file(char *s, char * attr);
