/*
 * type1.c        1.0 4/23/95
 *
 *      (c) Copyright 1995 by Lance Cottrell. All right reserved.
 *      The author assumes no liability for damages resulting from the
 *      use of this software, even if the damage results from defects in
 *      this software. No warranty is expressed or implied.
 *
 *      This software is being distributed under the GNU Public Licence,
 *      see the file GNU.license for more details.
 *
 *                      - Lance Cottrell (loki@obscura.com) 4/23/95
 *
 */

#include "mixmaster.h"
#include <stdio.h>

/*
The purpose of this code is just to send 
the type 1 message to an apropriate 
program. No processing of the message is done
*/
int type_1(char *filename)
{
        int     len;
        char    chunk[1024],name[80]="";
        FILE	*fptr,*pptr;

        if((fptr = fopen(filename,"r"))== NULL) return(1);
        if((pptr = popen(TYPE1,"w"))==NULL) {
           fprintf(stderr,"Could not open pipe to %s\n",TYPE1);
           return(2);
        }
        while((len = fread(chunk,1,1024,fptr)) > 0) {
          fwrite(chunk,1,len,pptr);
        }
        fclose(fptr);
        pclose(pptr);
        if(len == 0) {
          return(0);
        }
        return(1);
}
