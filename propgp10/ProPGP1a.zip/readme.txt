-----BEGIN PGP SIGNED MESSAGE-----


			        ProPGP 
			  Version 1.0 beta 1
	         
		 * A Freeware 32-bit front end for PGP *


        ProPGP was designed so that someone knowing no PGP commands can
use PGP with ease.  Virtually *all* options in PGP 2.6.2 are supported,
including nearly every key operation (e.g., adding public keys to your
keyring, viewing fingerprints, etc.).  You can even encrypt data from the
clipboard!  ProPGP also lets you easily view text files before or after 
encrypting/decrypting.  
         

				  SETUP:

        ProPGP does NOT come with PGP; you must obtain that program off 
the 'net.  The latest version, 2.6.2 ( (C)1994 by Philip Zimmermann), is 
available from many FTP sites.  Just use Lycos or InfoSeek to search the 
Internet if you don't already know where to find PGP.
	ProPGP also assumes that PGP resides in a directory in your path.  
For example, your autoexec.bat file might contain a statement like this 
one:

path=C:\WINDOWS;C:\;C:\ASRAPI\BIN\;C:\DOS;C:\PGP


Note that your PGP directory *must* be in your path for ProPGP to function
correctly.
        
        

		 	     USING ProPGP:

	When selecting a key operation, you'll notice a few text boxes
at the bottom of the screen.  Depending on the key function you intend to
execute, you'll need to enter either your user ID or someone else's user
ID.  You may save this information---along with your public and private
keyring locations---by clicking on the "Save contents" button.  Edit
the keyring locations upon your first use of the program if necessary.
        Should you choose one of the first four options under "Key 
Operations," you will be prompted to select a file on which to perform 
the chosen function.  For example, if you choose to add a public key file's
contents to your public keyring, you will be asked to click on the file
containing the public key(s) you wish to add.
        To verify a signature on a file, just use the default decryption 
option (already checked for you) and then click on "Do it!"  
        Keep in mind that a PGP user ID must be surrounded by quotation 
marks if more than just the first name is used.  For example, when executing 
a key operation, the following possibilities are acceptable as user ID's:

				Richard
			     "Richard Rubin"

But NOT:
 			      Richard Rubin



        Future releases of this program will include the ability to decrypt
data copied from the clipboard.

        If you find this program useful, please send E-mail to the author
regarding your thoughts on ProPGP's design.  


This program may be freely distributed as long as the files herein
are unmodified.

Richard Rubin
E-mail: rrubin@holli.com
WWW:  http://www.holli.com/~rrubin/
PGP public key available from key servers and from home page.



-----BEGIN PGP SIGNATURE-----
Version: 2.6.2

iQEVAwUBMRqRQGUiLDnu9czBAQGuHgf+KEZaM8V2l36cWGayq4Elfh9nsJoJZu+o
zyevU2hhrJ/+Ur7hPe/R8+DanNmFlSyed++18Rccur9G8/K3Ok6QbpjTDEXOSeJw
zOGKKhbfKJZ2qoaxLkOxB/T4v+PG5NoEUq5fLpKFdix7L5t0uwo2o03uDobwaF8W
Ir8AHmxBtEm/s+0/rsurMISRkl6s5dd0WZJpawRxN9v2dmhx5w2uQR3ssUEMq3WZ
NR4x2ew4WhGM8Uhj0ofnGNPotVNg/eMXxAYOMoysBTf0JVWFhpk1yTvU7qSfGmD/
XR4RnYaZEEI7lgFwhMDVRW7x5QwLY09ZZ5S3/J0f9f/85vdvk7iBBw==
=HaFY
-----END PGP SIGNATURE-----
