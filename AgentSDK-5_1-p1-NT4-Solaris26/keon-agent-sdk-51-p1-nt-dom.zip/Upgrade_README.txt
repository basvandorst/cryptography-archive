RSA Keon SDK v5.1 Upgrade REDAME
================================

1. General Notes
================

1.1 Base System Upgrade
-----------------------
The Base System upgrade is sufficient for incorporating the latest bug
fixes for an installed Agent (or Agents).

o Obtain the most recent Base System that contains all the latest
  changes.

o "cd" to the platform-specific directory of the new Base System
  distribution.

o On UNIX:
  Run the installation program in the installed base system
  (default: /opt/SDTI/Agents/bin/install)

  On Windows NT:
  Run the setup.exe program in the distribution

o You will be presented with a list containing only the new Base System
  with a note "Upgradable". Select the Base System and the
  installation will proceed as usual.

o Any Agents currently running must be restarted in order to re-read
  the patched shared objects/dlls. The easiest way to do this is to 
  restart catd.
	
  The examples below assume that the default installation locations
  are used:

  To restart catd on a UNIX system:
	
	% cd /opt/SDTI/Agents/bin
	% ./start restart

  To restart catd on Windows NT:

        > cd C:\Program Files\Security Dynamics/Agents/bin
        > .\start restart

1.2 SDK Users
-------------
If you are using the SDK to develop and package installable Agents you
should obtain the latest SDK (that contains the latest Base Bystem).
As the SDK is used to produce new Base Systems that
are to be bundled with the Agents you are developing, you should
uninstall the entire SDK and install the new one. 

If you try the upgrade procedure (which is possible) with the SDK
module, the Base Systems you create with the SDK will NOT include all
the latest changes.

Hence, do as follows:

o Remove any configured Agents in your current installation.

o Uninstall all modules.

o Make a clean installation of the newest SDK.

o Continue development as usual.

o Your old Agents that were uninstalled (if any), can be reinstalled
without being rebuilt since they will use the new shared objects/dlls.


2. Patch Level 1 Notes
======================

On Solaris 2.6 SPARC, a number of bugs have been fixed (see
Patch1_README.txt). A Base System upgrade is insufficient for correcting
the bug that catd is not restarted on reboot. 
Instead, the following procedure is required:

o Uninstallation of the old Base System and any associated Agents
o Reinstallation, starting with the new Base System
o Reinstallation of the previously installed Agent modules (if any)
