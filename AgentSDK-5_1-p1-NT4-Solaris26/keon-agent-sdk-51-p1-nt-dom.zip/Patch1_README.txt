Patch Level 1 Changes
=====================

Below are the changes for the patched Base System and the RSA Keon SDK
v 5.1 on the supported platforms Solaris 2.6 on SPARC and Windows NT
4.0 SP5 on the intel x86 architecture.

The changes for the unsupported platforms are subsets of the fixes
mentioned below.


Base System Patch Level 1
=========================

Solaris 2.6 & Windows NT 4.0
----------------------------

o Spelling error in the config program for the "host VC" option.

o Solaris 2.6 only:
  Error starting catd on reboot fixed.

o Solaris 2.6 only: 
  The TCP I/O Handler now uses writev() instead of send(), thus
  enabling the use of generic file descriptors as I/O channels instead
  of just sockets.

o A bug that a closing session could close a socket for another
  session is fixed.

o The "show" option now works for the command line mode of the config
  program.


RSA Keon SDK v 5.1 Patch Level 1
================================

Windows NT 4.0 SP5 and Solaris 2.6 SPARC
-----------------------------------------

o The catpac_openears() function now uses also the version argument
  when it determines the number of valid User Access Rights in a PAC.

o A problem with the Telnet example where it would not handle telnet
  options > 100 is fixed.

o The account information has been corrected in the README for the 
  Simple Web Server example. 

o The reference pages for catd, config, catgen, catnet_iohandler,
  catpac_openears, catssl_setdb and gencfg have been corrected or 
  updated.
