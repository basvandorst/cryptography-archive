/*
 * @(#)$Id: boks.h,v 1.4 1999/05/24 08:58:50 micke Exp $
 *
 * Copyright � 1998 Security Dynamics
 * This is unpublished proprietary source code.
 *
 * Description:
 *
 *	BoKS interoperability functions for the
 *	SecurSight Connect Agent Toolkit.
 *
 * Requires <cat/cat.h>
 *
 */

#ifndef _cat_boks_h
#define _cat_boks_h

#ifdef __cplusplus
extern "C" {
#endif

#define CATBOKS_DBITEMLEN	48
#define CATBOKS_STATUSLEN	16

typedef struct catboks_dbinfo {
    const char *givenuser;
    const char *givenpsw;
    const char *givendbid;
    char user[CATBOKS_DBITEMLEN];
    char psw[CATBOKS_DBITEMLEN];
    char dbid[CATBOKS_DBITEMLEN];
} catboks_dbinfo;

typedef struct catboks_loginfo {
    int sys;
    char *user;
    char *prog;
    char *label;
    int argc;
    char **argv;
    unsigned elscode;
    char *elsfmt;
} catboks_loginfo;

char *catboks_tcpmethod(cat_session *sess, const char *method,
			char **result, unsigned int maxlen);

int catboks_init(unsigned short port, char *nodekey, int cachettl,
		 char *myaddress, int nservers, char **servers);
void catboks_closeall(void);

int catboks_route(const char *route,
		  char encryption_status[CATBOKS_STATUSLEN],
		  char auth_status[CATBOKS_STATUSLEN]);
int catboks_log(cat_session *sess, const catboks_loginfo *loginfo);

int catboks_certtouser(cat_session *sess, char **user, int maxlen);
int catboks_auth(const char *route, const char *user, const char *prog);
int catboks_dbmap(const char *route, const char *user, catboks_dbinfo *dbinfo);

int catboks_dblogin(cat_session *sess,
		    const char *method, catboks_dbinfo *dbinfo);
int catboks_version(void);

int catboks_checkcert(cat_session *sess, int keyUsage);
#ifdef __cplusplus
}
#endif

#endif /* !_cat_boks_h */
