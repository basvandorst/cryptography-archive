/*
 * @(#)$Header: /srcroot/Lego-CVSROOT/catagent/example_ws/ws.h,v 1.6 2000/03/16 15:49:02 elias Exp $
 *
 * Copyright (c) 2000 RSA Security
 *
 * Description:	Misc definitions.
 *            
 *
 * MT-Level:    Safe
 */

#ifndef _ws_h
#define _ws_h

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#ifdef WIN32
#include <winsock2.h>
#else
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>
#include <ctype.h>
#endif

#define MAXLINE 1024
#define HDRBUFLEN 8192

#define SERV_PORT 4712
#define LISTENQ 10

#define DEFPORT 4711          /* Default server port */

#define MEMBLOCKSIZE 8192

#define HTMLDIR   "./html"    /* The html root */
#define PROTDIR   "private"   /* The protected dir under the root */
#define PROTREALM "Private"   /* The http realm */

#define USER "roger"          /* "Hard-wired" account */
#define PASS "ramjet"

#ifdef WIN32
#define DIRSEP ('\\')
#define BAD_SOCKET INVALID_SOCKET
#define SOCKERR    SOCKET_ERROR
#define Snprintf   _snprintf
#define Vsnprintf  _vsnprintf
#define Close      closesocket
typedef SOCKET WS_SOCK;
#else
#define DIRSEP ('/')
#define BAD_SOCKET -1
#define SOCKERR    -1
#define Snprintf   snprintf
#define Vsnprintf  vsnprintf
#define Close      close
typedef int WS_SOCK;
#endif

#define WS_EINVAL      -1      /* App specific error codes */
#define WS_EPERM       -2
#define WS_ERROR       -3
#define WS_EUNKNOWN    -4
#define WS_ECONNCLOSED -5
#define WS_EOVERFLOW   -6
#define WS_EACCES      -7
#define WS_ENOMEM      -8
#define WS_EOF         -9
#define WS_ENOTFOUND  -10
#define WS_EBADREQ    -11
#define WS_ETIMEOUT   -12

#define GET  0                  /* HTTP methods */
#define HEAD 1
#define POST 2

#define HTTP_CONNTYPE "Connection: close\r\n"

#define DEBUG(x) do {if (debuglvl) {debug x;}} while(0)
#define WSERROR(x) do {debug x; exit(1);} while(0)

typedef struct datum {
    char *value;   /* Payload */
    int  len;      /* Length of value */
    int  is_dyn;   /* 1 if value is dynamically allocated */
} datum;

typedef struct http_reply {
    datum *status;
    datum *header;
    datum *body;
} http_reply;

extern int debuglvl;             /* global debug level */

#ifndef USE_CAT
int read_request(WS_SOCK sockfd, char *header, int *hbuflen);
#endif
int generate_reply(void *data, char *request, char *header, int *hlen, 
		   char **body, int *bodylen);
int base642bin(char *in64, void *bin);
int parse_req(char *req, char **meth, char **uri, char **ver, char **header);
int uri_to_file(char *uri, char *pathbuf, int bufsize);
int reply_to_buf(http_reply *rep, char **buf);
int get_login_data(char creds[], char **user, char **passwd);
int validate_login(char *realm, char* file, char *user, char *passwd);
int is_protected(char *filepath, char *realm, int realmbufsize);
int has_auth(char *buf, char **credentials);
void debug(const char *fmt, ...);
http_reply *new_http_reply();
void free_http_reply(http_reply *r);
datum *new_datum();
void free_datum(datum *d);
int file_to_mediatype(char *filename, char **mediabuf);
int readfile(char *name, char **data, int zero_term);

#endif
