#ifndef _wscat_h
#define _wscat_h

#include <cat/cat.h>
#include <cat/log.h>
#include <cat/catutil.h>
#include "ws.h"
#include "version.h"

#define APPSERVNAME     SERVICE "-" VERSION  /* service name and version  */
#define DEFMETHOD       "WSCAT"              /* default method name */
#define MAX_ELS_SERVERS 10                   /* Max number of ELS servers */
#define CONFIGFILE      "./wscat.cfg"        /* configuration file */
#define WS_FACILITYLBL  "CONAGT"             /* log facility code */
#define SSLTIMEOUT      30                   /* Timeout in seconds */

/*
 * Index symbols for the global log label array
 */
#define WS_CNOPAC	       	 0
#define WS_MISSLOGID	         1
#define WS_AUTHFAIL	         2
#define WS_CEXPIRED		 3
#define WS_CINVALID		 4
#define WS_CCRITICAL		 5
#define WS_CREVOKED		 6
#define WS_CISSUERUNKNOWN 	 7
#define WS_CBADSIGNATURE	 8
#define WS_SERVAUTHFAIL		 9
#define WS_AUTHUSEROK		 10

struct cache {
    int setup;
    catdb_func *func;
    void *data;
};

typedef struct settings {
    int require_pac;              /* Require a PAC from the peer */
    char *method;                 /* Method name */
    cat_psd *psd;                 /* PSD handle */
    catlog_dispatcher *logdisp;   /* Log dispatcher */
    int log_success;              /* Do logging of successful authorization */
    struct cache sslcache;        /* SSL session resumption cache */
    struct cache certcache;       /* Verified certificate cache */
} settings;

extern settings *Info;            /* The global settings */
extern char *wsloglbls[];          /* The log label array */

int read_request(cat_session *sess, char *header, int *hbuflen);
cat_session *create_session(CATSOCK fd);
int init_sess(cat_session *sess);
int init_global(void);
int earauth(cat_session *sess, 
	    char *svc,
	    char *method,
	    char *user, 
	    char *pass, 
	    char **logid, 
	    char **mapuser, 
	    char **mappass);

#endif /* _wscat_h */
