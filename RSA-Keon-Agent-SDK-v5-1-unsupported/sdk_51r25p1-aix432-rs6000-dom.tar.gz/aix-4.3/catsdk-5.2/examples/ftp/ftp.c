/*
 * @(#)$Id: ftp.c,v 1.9 2000/03/17 09:19:36 elias Exp $
 *
 * Copyright (c) 1999 RSA Security
 *
 * Description:
 *    A proxy ftp-agent that handles passive connections from clients.
 *    Will use a configurable port range for the data connection.
 *
 * Arguments:
 *    Standard Agent Args. For more information refer to the SDK manual.
 */

#include <stdio.h>
#include <string.h>
#include <cat/cat.h>
#include <cat/gen.h>
#include <cat/catutil.h>
#include <ctype.h>

/*
 * Commands from the ftp client the filter should trigger on.
 */
static char *cmdlist[] = {
#define CMD_UNKNOWN    -1
    "PASV\r\n",
#define CMD_PASV	0
    "PORT ",
#define CMD_PORT	1
    "USER ",
#define CMD_USER	2
    "PASS ",
#define CMD_PASS	3

    /* Any other commands added here will be filtered out */

    NULL,
};

/*
 * Application-specific configuration parameters
 */

#define CATINFO_START_PORT 	"ftp.start_port"
#define CATINFO_PORTS   	"ftp.ports"
#define CATINFO_DATA_TIMEOUT	"ftp.datatimeout"
#define CATINFO_LISTEN_RETRY	"ftp.listenretry"
#define CATINFO_LISTEN_WAIT	"ftp.listenwait"
#define CATINFO_LISTEN_TIMEOUT	"ftp.listentimeout"

/*
 * State flags for the control channel connection. 
 */
#define FTP_LOGIN_DONE  0x01
#define FTP_GOT_USER    0x02


#define FTP_FD_CONN     0x04

/*
 * Default values
 */

#define FTP_SLEEP_TIME  	2   /* Wait time when looking for a socket */
#define FTP_MAX_RETRY		5   /* How many times to try */
				/* How long to wait for client to connect */
#define FTP_LISTEN_TIMEOUT	((FTP_SLEEP_TIME * FTP_MAX_RETRY) - 1)
#define FTP_DATA_TIMEOUT	60  /* Idle time for data channel */
#define BUF_SIZE		256 /* Size of misc buffers */


#define DATA_EQ(d0, d1)	((d0)->len == (d1)->len \
			 && memcmp((d0)->data, (d1)->data, (d0)->len) == 0)

/*
 * Filter data structure. 
 */
typedef struct _f_data {
    char user[BUF_SIZE];
    char pass[BUF_SIZE];
    int  state;
} f_data;

/*
 * Data connection session structure.
 */
typedef struct _s_data {
    cat_data peer_key;
    CATSOCK  server_fd;
    char client_addr[CATNET_ADDRLEN];
    int  server_fd_flag;
    int  control_port;
} s_data;

/* 
 * Global data key. Used to store data that should be used by
 * the data connection session. Will keep track of a data connection
 * session structure.
 */
static int ftp_data = 0;

/* Callbacks used by the SDK framework. */
static int  newsession(cat_session *sess, const char *port, void *data);
static int  listener_handler(cat_session *, int, int *, void *);
static void ftp_free_func(void *sess_data);

/* Filter functions. */
static int  ftp_init(cat_session *sess, struct cat_filter *f);
static int  ftp_rw(cat_session *sess, struct cat_filter *f, int fd_id);
static void ftp_free(cat_session *sess, struct cat_filter *f);

/* 
 * Use the line filter so the filters above will only see whole 
 * lines (ie lines terminated with '\r\n').
 */
extern cat_filter *cat_linefilter(int fd_ids, cat_filter *filter);

/* Functions that take care of the different commands from the client. */
static int  cmd_user(cat_session *sess, cat_filter *f, cat_buffer *b);
static int  cmd_pass(cat_session *sess, cat_filter *f, cat_buffer *b);
static int  cmd_pasv(cat_session *sess, cat_filter *f, cat_buffer *b);

/* Utility functions to make life a bit easier. */
static int  getcmd(cat_buffer *b);
static int  send_string(cat_session *sess, int fd_id, ...);
static int  ftp_recv(cat_session *, int, char *, char *, int);
static int  ftp_getpeerkey(cat_session *sess, cat_data *key);
static int  ftp_getport(cat_session *sess, cat_session *ds, catnet_info *info);
cat_filter  *ftp_newfilter(int fd_ids, cat_filter *f);

int 
main(int argc, char *argv[])
{
    int code = CAT_OK;

    /*
     * Needs to be called first. Catgen_server() will not mind
     * that we call it "manually".
     */
    cat_init(NULL);
    /* 
     * Create a memory slot in each session. Will contain an s_data 
     * structure.
     */
    ftp_data = cat_newdatakey();
    
    code = catgen_server("ftp_sample-5.0", argc, argv, newsession, NULL);

    return code;
}

/*
 * newsession()
 *
 * Description:
 *    A callback used by the catgen_server() function.
 *    Gets called for each new connection. Establishes a encryption
 *    channel and authenticates the conneting peer. Pushes the
 *    user defined filters (linefilter and ftp proto filter).
 *
 * Arguments:
 *    sess      IN: cat_session pointer.
 *    port      IN: The port number that the connection came in on.
 *    data      IN: Any data sent when calling catgen_server 
 *                  (None in this case).
 *
 * Returns:
 *    Returns an integer status code. For information on valid
 *    error codes, please refer to the manual. The CAT_CONTINUE return 
 *    value will cause the framework to take over and run the session.
 */
static int
newsession(cat_session *sess, const char *port, void *data)
{
    char *F = "newsession";
    cat_filter ftp;
    int error  = CAT_OK;

    /*
     * Establish an encryption channel for the control connection 
     * and authenticate the user. The user's accessrights are 
     * checked when he tries to log in to the server.
     */
    if ((error = catgen_serverencryption(sess)) < 0 ) {
	return error;
    }

    /*
     * Push the ftp filter. The filter understands some of the ftp protocol
     * commands. Authenticates and maps the user to the ftp-user he should
     * be logged in as.
     */
    error = cat_pushfilter(sess, ftp_newfilter(CAT_CLIENT_RFD, &ftp));
    if (error < 0) {
	return error;
    }
    return CAT_CONTINUE;
}

/*
 * ftp_newfilter()
 *
 * Description:
 *    A utility function that will initialize a cat_filter data
 *    element to be a ftp protocol filter. 
 *
 * Arguments:
 *    sess      IN: cat_session pointer.
 *    f         IN: The cat filter data structure to be used. Must be 
 *                  allocated by the caller.
 *
 * Returns:
 *    Returns a pointer to the incoming filter structure or NULL
 *    if it failed.
 */
cat_filter *
ftp_newfilter(int fd_ids, cat_filter *f)
{
    f_data *d = NULL;

    memset(f, 0, sizeof(cat_filter));
    if ((d = malloc(sizeof(f_data))) == NULL) {
	return NULL;
    }
    memset(d, 0, sizeof(f_data));
    d->state = 0;

    strncpy(f->name, "ftp-protocol", sizeof(f->name));
    f->fd_ids = fd_ids;
    f->init = ftp_init;
    f->rw = ftp_rw;
    f->free = ftp_free;
    f->filterdata = d;

    return f;
}

/*
 * ftp_init()
 *
 * Description:
 *    A callback that will get called when the ftp proto filter
 *    gets pushed on the filter stack.
 *
 * Arguments:
 *    sess      IN: cat_session pointer.
 *    f         IN: The cat filter data structure used. 
 *
 * Returns:
 *    Should return an integer status code. For valid codes and their meaning
 *    refer to the manual.
 */
static int
ftp_init(cat_session *sess, struct cat_filter *f)
{
    int error;
    cat_filter line;

    /*
     * Push the line filter. This will guarantee that the filters
     * above will only receive whole lines. That is, lines terminated
     * with '\r\n'.
     */
    error = cat_pushfilter(sess, cat_linefilter(CAT_CLIENT_RFD, &line));
    if (error < 0) {
	return error;
    }
    error = cat_pushfilter(sess, cat_linefilter(CAT_SERVER_RFD, &line));
    if (error < 0) {
	return error;
    }
    return CAT_OK;
}

/*
 * ftp_free()
 *
 * Description:
 *    A callback that will get called when the ftp proto filter
 *    is popped from the filter stack. 
 *
 * Arguments:
 *    sess      IN: cat_session pointer.
 *    f         IN: The cat filter data structure used. 
 *
 * Returns:
 *    No return value.
 */
static void
ftp_free(cat_session *sess, struct cat_filter *f)
{
    f_data *d = (f_data *)f->filterdata;

    /*
     * Remove the line filters.
     */
    cat_popfilter(sess);
    cat_popfilter(sess);

    if (d) {
	free(d);
    }
}

/*
 * ftp_rw()
 *
 * Description:
 *    The ftp-proto function that gets called for each time
 *    data is availabe on any of the descriptors the filter
 *    is registered for. Recognizes some ftp commands and
 *    takes the appropriate action. Anyy command not recogized
 *    is forwarded to the ftp-server.
 *
 * Arguments:
 *    sess      IN: cat_session pointer.
 *    f         IN: The cat filter data structure used. 
 *    fd_id     IN: Specifies on what descriptor the function got called.
 *
 * Returns:
 *    A valid CAT_ error code. CAT_CONTINUE will continue normal execution.
 */
static int
ftp_rw(cat_session *sess, struct cat_filter *f, int fd_id)
{
    char *F = "ftp_rw";
    int cmd = CMD_UNKNOWN;
    cat_buffer *b = NULL;
    
    if ((b = catbuf_get(sess, fd_id)) == NULL) {
	CAT_DEBUG3((sess, F, "Failed to get the client buffer"));
	return CAT_EINTERNAL; 
    }
    cmd = getcmd(b);

    switch (cmd) {
      case CMD_UNKNOWN:
	CAT_DEBUG3((sess, F, "Unknown command, forward it to the server"));
	break;

      case CMD_USER:
	cmd_user(sess, f, b);
	catbuf_free(b);
	return CAT_CONTINUE;

      case CMD_PASS:
	cmd_pass(sess, f, b);
	catbuf_free(b);
	return CAT_CONTINUE;

      case CMD_PORT:
	CAT_DEBUG3((sess, F, "'Port' command encountered"));	  
	send_string(sess, CAT_CLIENT_WFD, 
		    "502 Port command not implemented.",
		    NULL);
	catbuf_free(b);
	return CAT_CONTINUE;

      case CMD_PASV:
	if (cmd_pasv(sess, f, b) < 0) {
	    send_string(sess, CAT_CLIENT_WFD, 
			"425 Can't open data connection.",
			NULL);
	}
	catbuf_free(b);
	return CAT_CONTINUE;

      default:
	CAT_DEBUG3((sess, F, "Faulty command"));
	send_string(sess, CAT_CLIENT_WFD, 
		    "500 '", 
		    cmdlist[cmd],
		    "': command not understood.", 
		    NULL);
	catbuf_free(b);
	return CAT_CONTINUE;
    }
    catbuf_put(sess, fd_id, b);

    return CAT_CONTINUE;
}

/*
 * cmd_user()
 *
 * Description:
 *    This function is called if we recognized the 'USER <xxx>' command
 *    from the ftp-client. Saves the user name and sends a 'Password 
 *    required' request back. No data is forwarded to the ftp server.
 *
 * Arguments:
 *    sess      IN: cat_session pointer.
 *    f         IN: The cat filter data structure used. 
 *    b         IN: The cat buffer containing the user request.
 *
 * Returns:
 *    A valid CAT_ error code.
 */
static int
cmd_user(cat_session *sess, cat_filter *f, cat_buffer *b)
{
    char   *F  = "cmd_user";
    f_data *d  = NULL;
    char   *t  = NULL;
    int    len, err;

    d = (f_data *)f->filterdata;
    len = err = 0;

    /*
     * Extract the user name from the client packet and send
     * a '331 Password ...' message back. Save the user name in 
     * the filter data structure. 
     */
    len = catbuf_extract(b, 5, (sizeof(d->user) - 1), d->user);

    while (len > 0 && isspace(d->user[len-1])) {
	--len;
    }
    d->user[len] = '\0';

    if (len <= 0) {
	send_string(sess, CAT_CLIENT_WFD, 
		    "500 'USER': Command not understood.",
		    NULL);

	return CAT_EINVAL;
    }
    CAT_DEBUG3((sess, F, "Received user name:%s", d->user));
    
    send_string(sess, CAT_CLIENT_WFD, 
		"331 Password required for ", 
		d->user,
		NULL);
    
    d->state |= FTP_GOT_USER;

    return CAT_OK;
}

/*
 * cmd_pass()
 *
 * Description:
 *    This function is called if we recognized the 'PASS <xxx>' command
 *    from the ftp-client. Saves the password and tries to map the 
 *    given name and given password to a new name/password pair.
 *    Then tries to log in the user with the new name/password to the 
 *    ftp-server. If the mapping and login succeeded a 
 *    'User <xxx> logged in' is sent to the ftp client. 
 *
 * Arguments:
 *    sess      IN: cat_session pointer.
 *    f         IN: The cat filter data structure used. 
 *    b         IN: The cat buffer containing the pass request.
 *
 * Returns:
 *    A valid CAT_ error code.
 */
static int
cmd_pass(cat_session *sess, cat_filter *f, cat_buffer *b)
{
    char *F   = "cmd_pass";
    char *t   = NULL;
    char *map_user = NULL;
    char *map_pass = NULL;
    char buf[BUF_SIZE];
    f_data *d = NULL;
    int len, error;

    d = (f_data *)f->filterdata;
    error = CAT_OK;
    len = 0;

    len = catbuf_extract(b, 5, (sizeof(d->pass) - 1), d->pass);
    d->pass[len] = '\0';
    
    t = strchr(d->pass, '\r');
    if (t == NULL || len < 3) {
	CAT_DEBUG3((sess, F, "Failed to extract password"));
	send_string(sess, CAT_CLIENT_WFD, 
		    "500 'PASS': command not understood",
		    NULL);
	return CAT_EINVAL;
    }
    *t = '\0';
    CAT_DEBUG3((sess, F, "Received password %s", d->pass));

    if (!(d->state & FTP_GOT_USER)) {
	send_string(sess, CAT_CLIENT_WFD, 
		    "503 Login with USER first.", 
		    NULL);
	return CAT_CONTINUE;
    }


    /*
     * Authenticate user and try and map the user 
     * to correct ftp-user to login as to the ftp-server.
     */
    error = catgen_checkauth(sess, d->user, d->pass, NULL);
    if (error == 0) {
	error = catgen_dbmap(sess, d->user, d->pass, NULL,
			   &map_user, &map_pass, NULL);
	if (error != 0) {
	    catgen_log(sess, CATLOG_MAPFAIL);
	}
    }
    if (error != 0) {
	CAT_DEBUG3((sess, F, "Failed to auth. and map user: %d", error));
	error = CAT_EACCES;
	goto done;
    }

    /* Send USER command to sever. */
    send_string(sess, CAT_SERVER_WFD, "USER ", map_user, NULL);

    if (ftp_recv(sess, CAT_SERVER_RFD, "331", buf, sizeof(buf)) < 0) {
	CAT_DEBUG3((sess, F, "Could not find password request:%s", buf));
	error = CAT_ENOTFOUND;
	goto done;
    }

    /* Send PASS command to server. And check if the answer is OK */
    send_string(sess, CAT_SERVER_WFD, "PASS ", map_pass, NULL);

    if (ftp_recv(sess, CAT_SERVER_RFD, "230", buf, sizeof(buf)) < 0) {
	CAT_DEBUG3((sess, F, "Login to ftp server failed, got: %s", buf));
	error = CAT_ENOTFOUND;
	goto done;
    }

    /* Send OK message back to client. */
    send_string(sess, CAT_CLIENT_WFD, "230 User ", 
		d->user, 
		" logged in.",
		NULL);
    
    d->state |= FTP_LOGIN_DONE;

done:
    d->state &= ~FTP_GOT_USER;

    if (map_user) {
	free(map_user);
    }
    if (map_pass) {
	free(map_pass);
    }
    if (error != CAT_OK) {
	send_string(sess, CAT_CLIENT_WFD, "530 Login incorrect.", NULL);
    }
    return error;
}

/*
 * cmd_pasv()
 *
 * Description:
 *    This function is called if we recognized the 'PASV' command
 *    from the ftp-client. Creates the data connection channel and
 *    connects to the ftp server. Sends a 'PASV (IP,port)' command back
 *    to the client.
 *
 * Arguments:
 *    sess      IN: cat_session pointer.
 *    f         IN: The cat filter data structure used. 
 *    b         IN: The cat buffer containing the pasv request.
 *
 * Returns:
 *    A valid CAT_ error code.
 */
static int
cmd_pasv(cat_session *sess, cat_filter *f, cat_buffer *b)
{
    char *F = "cmd_pasv";
    cat_session *ds  = NULL;
    s_data *ds_info = NULL;
    f_data *d = NULL;
    catnet_info info;
    int len, flags, error, proto;
    unsigned int ip[4], s_port[2], port;
    char buf[BUF_SIZE];
    char *s = NULL;

    error = CAT_OK;
    len = flags = 0;
    d = (f_data *)f->filterdata;
    memset(&info, 0, sizeof(catnet_info));

    if (!(d->state & FTP_LOGIN_DONE)) {
	send_string(sess, CAT_CLIENT_WFD, 
		    "530 Please login with USER and PASS first.", 
		    NULL);
	goto done;;
    }

    /* Send PASV command to server. */
    send_string(sess, CAT_SERVER_WFD, "PASV", NULL);
    
    /* 
     * Read and parse the answer to find out what port to connect to 
     * on the server. It is best to configure this agent to connect
     * to localhost for security reasons. 
     */ 
    if (ftp_recv(sess, CAT_SERVER_RFD, "227", buf, sizeof(buf)) < 0) {
	CAT_DEBUG3((sess, F, "Failed to read PASV port answer from server"));
	error = CAT_EINVAL;
	goto done;
    }

    /* 
     * Get the address and port to connect to
     */
    port = 0;
    for (s = buf + 4; *s != '\0'; s++) {
	if (isdigit(*s)) {
	    len = sscanf(s, "%u,%u,%u,%u,%u,%u", 
			 &ip[0], &ip[1], &ip[2], &ip[3], 
			 &s_port[0], &s_port[1]);
	    if (len == 6) {
		port = (s_port[0] << 8) + s_port[1];
		break;
	    }
	}
    }
    if (port == 0) {
	CAT_DEBUG3((sess, F, "Could not find port in: %s", buf));
	error = CAT_EINVAL;
	goto done;
    } 

    /* Create the data-connection session. */
    if ((ds = cat_newsession()) == NULL) {
	CAT_DEBUG3((sess, F, "Could not create data-connection session"));
	error = CAT_EINTERNAL;
	goto done;
    }

    /*
     * Create the data-connection session data. Some information
     * is saved in there so that the new session created will
     * get some information from the control connection
     * (eg user's public key, server fd etc). Associate the session
     * data with the newly created session.
     */
    ds_info = (s_data *)malloc(sizeof(s_data));
    memset(ds_info, 0, sizeof(s_data));

    cat_setsessdata(ds, ftp_data, ds_info, ftp_free_func);

    catnet_getnetinfo(sess, CAT_CLIENT_WFD, &info);

    ds_info->control_port = info.my_port;
    memcpy(ds_info->client_addr, info.peer_addr, sizeof(info.peer_addr));
    
    /* Install the tcp-iohandler. */
    cat_installiohandler(ds, catnet_iohandler(NULL), NULL);

    /* Connect to the ftp-server. */
    sprintf(buf, "tcp:%u.%u.%u.%u:%u", ip[0], ip[1], ip[2], ip[3], port); 
    if ((error = catnet_connect(ds, buf, CAT_SERVER_WFD)) < 0) {
	CAT_DEBUG3((sess, F, "Failed to connect to %s", buf));
	goto done;
    } 

    /* 
     * Retrieve network information and save the server socket and socket 
     * state. Remove the server socket from the session, if we don't do that
     * we can't make it a listening session. The saved socket will be used 
     * when setting up the data connection.
     */
    catnet_getnetinfo(ds, CAT_SERVER_WFD, &info);
    ds_info->server_fd = info.fd;
    ds_info->server_fd_flag |= FTP_FD_CONN;
    catnet_setfd(ds, CAT_SERVER_RFD | CAT_SERVER_WFD, CATSOCK_INVALID);

    /*
     * Retrieve certificate information and add it. Save the information
     * in the session info structure together with server fd info etc. 
     */
    proto = catgen_protocol(sess);
    if ((proto != CATGEN_PROTO_PLAIN) 
	&& (error = ftp_getpeerkey(sess, &ds_info->peer_key)) < 0) 
    {
	goto done;
    }

    /* 
     * Retrieve a listening port for the client to connect to.
     * The port range is read from the agent configuration.
     */
    if ((error = ftp_getport(sess, ds, &info)) < 0) {
	goto done;
    }

    for (s = info.my_addr; *s != '\0'; s++) {
	if (*s == '.') {
	    *s = ',';
	}
    }

    sprintf(buf, "227 Entering Passive Mode (%s,%u,%u)",
	    info.my_addr, info.my_port >> 8, info.my_port & 0xff);
    send_string(sess, CAT_CLIENT_WFD, buf, NULL);

    /*
     * Add the newly created session to the framework. It will
     * run as a new thread (if possible).
     */
    flags = 0;
    flags = CATSOCK_THREAD | CATSOCK_POLL | CATSOCK_CLIENT_READ; 
    if ((error = catsock_add(ds, flags, listener_handler)) < 0) {
	CAT_DEBUG3((sess, F, "Failed to add the listening session"));	
	goto done;
    }
    
done:
    if (error < 0) {
	if (ds != NULL) {
	    cat_close(ds);
	}
    }
    return error;
}

/*
 * listener_handler()
 *
 * Description:
 *    Callback function that gets called by the framework when
 *    a new data connection session is added to the framework.
 *    Listens for incoming connections from the client. When a connections
 *    is accepted, the IP adress and the public key of the user is checked
 *    so that it is the same as for the control connection.
 *
 * Arguments:
 *    sess      IN: cat_session pointer.
 *    event     IN: Why the function was called.
 *    flags     IN: State flags for the session.
 *    data      IN: Any session specific data.
 *
 * Returns:
 *    A valid CAT_ error code.
 */
static int
listener_handler(cat_session *ds, int event, int *flags, void *data)
{
    char *F = "listener_handler";
    s_data *ds_info = NULL;
    int error = CAT_OK;
    int fl = 0;
    int proto = 0;
    int timeout;
    catnet_info net;
    cat_data pub_key;

    CAT_DEBUG3((ds, F, "event = 0x%04x", event));

    if (event != CATSOCK_CLIENT_READ) {
	return 0;
    }

    if ((ds_info = (s_data *)cat_getsessdata(ds, ftp_data)) == NULL) {
	CAT_DEBUG3((ds, F, "Failed to get session data"));
	error = CAT_EINTERNAL;
	goto done;
    }
    memset(&net, 0, sizeof(catnet_info));
    memset(&pub_key, 0, sizeof(cat_data));

    /* Accept client connection on the listening port. */
    if ((error = catnet_accept(ds, NULL, 0)) < 0) {
	goto done;
    }

    /* Compare IP-adresses to see if it's the correct client connecting. */
    catnet_getnetinfo(ds, CAT_CLIENT_RFD, &net);
    if (strcmp(net.peer_addr, ds_info->client_addr) != 0) {
	CAT_DEBUG3((ds, F, "IP address does not match for connecting peer"));
	error = CAT_EBADADDR;
	goto done;
    }
    CAT_DEBUG3((ds, F, "Clients IP adress matches data<->control"));    

    /*
     * Set up the info search path for catgen_serverencryption.
     * will negotiate the same protocol (DASP/SSL) for the
     * data connection as for the control connection.
     */
    catgen_infopath(ds, NULL, ds_info->control_port);

    /* Do DASP/SSL negotiation. */
    if ((error = catgen_serverencryption(ds)) < 0 ) {
	CAT_DEBUG3((ds, F, "Failed to set up data channel encryption"));
	goto done;
    }

    /* 
     * Check the connecting user's public key to make it very probable it
     * is the same user connetcing on the data channel.
     */
    proto = catgen_protocol(ds);
    if (proto != CATGEN_PROTO_PLAIN) {
	if ((error = ftp_getpeerkey(ds, &pub_key)) < 0) {
	    goto done;
	}
    }
    if (!DATA_EQ(&pub_key, &ds_info->peer_key)) {
	CAT_DEBUG3((ds, F, "Key mismatch, hostile take over ?"));
	error = CAT_EACCES;
	goto done;
    }
    CAT_DEBUG3((ds, F, "User's public key matches data<->control"));

    /* 
     * Connect the server descriptor with the client descriptor. 
     * Closes the already open fd's that are substituted.
     */
    fl = CAT_SERVER_RFD | CAT_SERVER_WFD | CAT_CLOSED;
    if ((error = catnet_setfd(ds, fl, ds_info->server_fd)) < 0) {
	CAT_DEBUG3((ds, F, "Failed to set server descriptor !"));	
	goto done;
    }

    /* 
     * Remove the CAT_CLIENT_READ flag. The session will be run by 
     * the framework. 
     */
    *flags = 0;

    /* 
     * Remove the fd connected flag. It now belongs to the session and 
     * should be closed automatically when the session is closed.
     */
    ds_info->server_fd_flag = 0;

    /*
     * Free some memory that will not be used again.
     */

    free(ds_info->peer_key.data);
    ds_info->peer_key.data = NULL;

    timeout = FTP_DATA_TIMEOUT;
    if (catgen_getint(ds, CATINFO_DATA_TIMEOUT, &timeout) < 0) {
	catgen_getint(ds, "timeout", &timeout);
    }
    catnet_settimeout(ds, timeout);

done:
    if (pub_key.data) {
	free(pub_key.data);
    }
    return error;
}

/*
 * getcmd()
 *
 * Description:
 *    A utility function that tries to determine if there is a 
 *    recognisable command in the buffer and what command that is.
 *
 * Arguments:
 *    b       IN: The received data that is examined for valid commands.
 *
 * Returns:
 *    The command as an integer or a negative code on error.
 */
static int
getcmd(cat_buffer *b)
{
    char cmdstr[10];
    int n, i;
    char *s;

    if (catbuf_len(b) < 6) {
	return CMD_UNKNOWN;
    }
    n = catbuf_copy(b, 0, 6, cmdstr);
    cmdstr[n] = 0;
    
    for (s = cmdstr; *s != '\0'; s++) {
	*s = toupper(*s);
    }
    for (i = 0; cmdlist[i] != NULL; i++) {
	if (strncmp(cmdlist[i], cmdstr, strlen(cmdlist[i])) == 0) {
	    return i;
	}
    }
    return CMD_UNKNOWN;
}

/*
 * send_string()
 *
 * Description:
 *    A utility function that concatenates the string arguments,
 *    adds CR-LF and sends it back into the framework. It may
 *    short circuit the filter stack.
 *
 * Arguments:
 *    sess     IN: The session that the message "belongs" to.
 *    fd_id    IN: File descriptor to send the data on.
 *    ...      IN: Variable number of string to append to te cat buffer.
 *                 The last element must be NULL.
 *
 * Returns:
 *    Always returns 0.
 */
static int
send_string(cat_session *sess, int fd_id, ...)
{
    char *s;
    va_list ap;
    int len;
    cat_buffer *b;
    char *F ="send_string";

    if ((b = catbuf_new(sess, 0, NULL)) == NULL) {
	CAT_DEBUG3((sess, F, "Failed to create reply buffer"));
	goto done;
    }

    va_start(ap, fd_id);
    while ((s = va_arg(ap, char *)) != NULL) {
        len = strlen(s);
        catbuf_append(b, len, s);
    }
    va_end(ap);
    catbuf_append(b, 2, "\r\n");

    if (cat_send(sess, fd_id, b) < 0) {
	CAT_DEBUG3((sess, F, "Failed to send message"));
	goto done;
    }

  done:
    return CAT_OK;

}

/*
 * ftp_free_func()
 *
 * Description:
 *    A callback free function that is called when a session is closed
 *    that as any data that has been associated to the session with the
 *    cat_setsessdata() function.
 *    
 * Arguments:
 *    sess_data     IN: Data to free. 
 *
 * Returns:
 *    No return value.
 */
static void
ftp_free_func(void *sess_data)
{
    s_data *ds_info = NULL;

    ds_info = (s_data *)sess_data;
    
    if (ds_info->peer_key.data != NULL) { 
	free(ds_info->peer_key.data); 
    }
    if (ds_info->server_fd_flag & FTP_FD_CONN) {
	cat_closesocket(ds_info->server_fd);
    }
    if (ds_info != NULL) {
	free(ds_info);
    }
}

/*
 * ftp_recv()
 *
 * Description:
 *    Receive ftp commands from filedescriptor and check if the
 *    data has the correct ftp status code in the beginning. Should skip any
 *    1xx messages.
 *    
 * Arguments:
 *    sess          IN: Cat session that the fd belongs to.
 *    fd            IN: File descriptor to read from.
 *    code          IN: The (three digit) code as a string to look for.
 *    buf           IN: A buffer that will contain the reply string
 *                      if the call succeeded. Must be allocated by the 
 *                      caller.
 *    b_len         IN: Size of the supplied buffer.
 *
 * Returns:
 *    Returns zero if OK otherwise a negative value.
 */
static int
ftp_recv(cat_session *sess, int fd, char *code, char *buf, int b_len)
{
    cat_buffer *b;
    int b_read = 0;
    int len, n;
    char tmp[4];

    buf[0] = 0;
    len = strlen(code);
    n = 0;
    while ((n = cat_recv(sess, fd, &b)) >= 0) {
	if (n == 0) { /* May happen due to the line filter */
	    continue;
	}
	if (len == 0) {
	    n = catbuf_extract(b, 0, 4, tmp);
	    catbuf_free(b);
	    if (n != 4 || tmp[3] == ' ') {
		break;
	    }
	} else {
	    b_read = catbuf_extract(b, 0, (b_len - 1), buf);
	    while (b_read > 0 && isspace(buf[b_read-1])) {
		--b_read;
	    }
	    buf[b_read] = '\0';
	    catbuf_free(b);
	    if (buf[0] == '1') { 
		continue;
	    } else if (strncmp(buf, code, len) == 0) {
		if (buf[3] == ' ') {
		    break;
		}
		len = 0;
	    } else {
		return CAT_ENOTFOUND;
	    }
	}
    }
    CAT_DEBUG4((sess, "ftp_recv", "<%s>", buf));

    return b_read;
}

/*
 * ftp_getpeerkey()
 *
 * Description:
 *    Extract the user's public key from the certificate. A succesful
 *    SSL or DASP negotiation must have taken place first. The
 *    function will allocate memory for the resulting key.
 *    
 * Arguments:
 *    ds       IN: Session to work with.
 *    cat_data IN/OUT: A cat data structure who's data element will
 *                     contain the public key of the user.
 *
 * Returns:
 *    Returns zero if OK otherwise a negative value.
 */
static int 
ftp_getpeerkey(cat_session *ds, cat_data *pub_key)
{
    char *F = "ftp_getpeerkey";
    int error = CAT_OK;
    cat_cert *c = NULL;
    cat_data cert;

    if ((error = catcert_getpeercert(ds, &cert, 1)) < 0) {
	CAT_DEBUG3((ds, F, "Failed to get peer cert"));
	goto done;
    }
    if ((error = catcert_parse(&cert, &c)) < 0) {
	CAT_DEBUG3((ds, F, "Failed to parse certificate"));
	goto done;
    }
    if ((error = catcert_publickey(c, pub_key)) < 0) {
	CAT_DEBUG3((ds, F, "Failed to retrieve public key"));
	goto done;
    }
    CAT_DEBUG3((ds, F, "Extracted public key, len: %d bytes", pub_key->len));

done:
    catcert_free(c);

    return error;
}

/*
 * ftp_getport()
 *
 * Description:
 *    Reads the cat_info tree to find a port range with valid
 *    ports that the data connection may be set up on.
 *    
 * Arguments:
 *    sess        IN: The session for the control connection.
 *    ds          IN: The session for the data connection.
 *    info        IN/OUT: Will contain a listening port
 *                        if successful.
 *
 * Returns:
 *    Returns zero if OK otherwise a negative value.
 */
static int
ftp_getport(cat_session *sess, cat_session *ds, catnet_info *info)
{
    char *F = "ftp_getport";
    int error = CAT_OK;
    int i, start_port, end_port, ports, port, timeout;
    char buf[BUF_SIZE];
    
    memset(info, 0, sizeof(catnet_info));

    if ((error = catgen_getint(sess, CATINFO_START_PORT, &start_port)) < 0) {
	CAT_DEBUG3((sess, F, "Failed to get data port begin"));
	goto done;
    }
    if ((error = catgen_getint(sess, CATINFO_PORTS, &ports)) < 0) {
	CAT_DEBUG3((sess, F, "Failed to get data port end"));
	goto done;
    }
    end_port = start_port + ports - 1;
    CAT_DEBUG3((sess, F, "Port range is from %d to %d", start_port, end_port));
    
    catnet_getnetinfo(sess, CAT_CLIENT_WFD, info);
    info->my_port = 0;
    for (i = 0; i < FTP_MAX_RETRY; i++) {
	for (port = start_port; port <= end_port; port++) {
	    sprintf(buf, "tcp:%s:%d", info->my_addr, port);
	    if (catnet_listen(ds, buf) == 0) {
		catnet_getnetinfo(ds, CAT_CLIENT_RFD, info);
		break;
	    }
	} 
	if (info->my_port == 0) {
	    CAT_DEBUG3((ds, F, "Unable to find a listening port"));
	    cat_sleep(FTP_SLEEP_TIME);
	} else {
	    break;
	}
    }
    if (i == FTP_MAX_RETRY) {
	CAT_DEBUG3((ds, F, "Timeout, no listening ports available"));
	error = CAT_ETIMEDOUT;
	goto done;
    }
    timeout = FTP_LISTEN_TIMEOUT;
    catgen_getint(sess, CATINFO_LISTEN_TIMEOUT, &timeout);
    catnet_settimeout(ds, timeout * 1000);

done:
    return error;
}
