/*
 * @(#)$Header: /srcroot/Lego-CVSROOT/catagent/prog/popagent.c,v 1.17 2000/01/16 19:45:22 mikko Exp $
 *
 * Copyright (c) 1998 Security Dynamics
 * This is unpublished proprietary source code.
 *
 * Description: Sample POP3 agent.
 */


#include <stdio.h>
#include <string.h>
#include <cat/gen.h>

#include "pop3.h"
#include "version.h"

#define SVC_VER		SERVICE "-" VERSION

static int doit(cat_session *sess, const char *port, void *data);


/*
 * Standard agent.  Takes standard arguments for
 * agents on whatever platform it is compiled for.
 */

int
main(int argc, char **argv)
{
    /*
     * If this call returns, there is nothing more to do.
     *
     * There should normally be no extra code in the main
     * program when using catgen_server(), as it would get
     * executed at different points depending on how the
     * agents was started (As standalone daemon, from
     * inetd on unix, or as an NT service)
     */

    return catgen_server(SVC_VER, argc, argv, doit, NULL);
}


/*
 * Called for each new incoming client connection, directly
 * after the server connection has been established.
 */

static int
doit(cat_session *sess, const char *port, void *data)
{
    cat_filter f;
    int err;

    /*
     * Set up a secure channel.
     */

    if ((err = catgen_serverencryption(sess)) != 0) {
	return err;
    }

    /*
     * Handle the application protocol by pushing a filter to
     * take care of it.
     */

    if ((err = cat_pushfilter(sess, cat_pop3filter(&f))) < 0) {
	return err;
    }

    /*
     * Tell toolkit to handle the session.
     */

    return CAT_CONTINUE;
}
