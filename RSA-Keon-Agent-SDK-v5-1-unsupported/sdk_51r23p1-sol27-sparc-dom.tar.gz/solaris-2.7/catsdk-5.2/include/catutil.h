/*
 * @(#)$Id: catutil.h,v 1.11 2000/01/17 09:36:08 mikko Exp $
 *
 * Copyright � 1998 Security Dynamics
 * This is unpublished proprietary source code.
 *
 * Description:
 *
 *	Assorted useful utilities for use with the CAT.
 *	Requires <cat/cat.h>
 */

#ifndef _cat_catutil_h
#define _cat_catutil_h

#ifdef CAT_UNIX
# include <netdb.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif


typedef struct catnet_host {
    char **names;		/* name, alias, ..., NULL */
    char **addrs;		/* addresses, as strings, NULL-terminated */
} catnet_host;

typedef struct catnet_serv {
    char **names;		/* name, alias, ..., NULL */
    int port;			/* port number */
} catnet_serv;

catnet_host *catnet_hostbyname(const char *name);
catnet_host *catnet_hostbyaddr(const char *addr);
catnet_serv *catnet_servbyname(const char *name, const char *proto);
catnet_serv *catnet_servbyport(int port, const char *proto);

char *cat_hostname(char *buf, int buflen);

int cat_utftowc(const char *input, wchar_t **output);
int cat_wctoutf(const wchar_t *input, char **output);
int cat_utftolatin1(const char *input, char **output, int unknown);
int cat_latin1toutf(const char *input, char **output);
char *cat_needutf(const char *latin1);
int cat_bintobase64(const void *binbuf, int binlen, char *base64buf);
int cat_base64tobin(char **base64ptr, char *binbuf);

typedef struct cat_memdb cat_memdb;

#define CATMEMDB_UPDATE		0x01	/* Mark entries up-to-date on GET */
#define CATMEMDB_NOCOPY_GET	0x02	/* Do not copy data on GET */
#define CATMEMDB_NOCOPY_PUT	0x04	/* Do not copy data on PUT */
#define CATMEMDB_FREEFUNC       0x08    /* Indicates special free function */
#define CATMEMDB_NOCASE		0x10	/* Ignore case (for string keys) */
#define CATMEMDB_MAXSIZE	0x20	/* Set size limit */

typedef void cat_memdbfreefunc(catdb_data *);
typedef int cat_memdbtraversefunc(cat_memdb *, catdb_data *, void *);

int cat_newmemdb(int nbuckets, int ttl, cat_memdb **db);
int cat_freememdb(cat_memdb *db);
int cat_memdbfunc(int op, catdb_data *entry, void *handle);
int cat_memdbforeach(cat_memdb *db, cat_memdbtraversefunc *fun, void *data);
int cat_memdbflags(cat_memdb *db, int flags, ...);

typedef struct cat_filedb cat_filedb;

int cat_newfiledb(const char *filename,
		  int entries, int ttl, cat_filedb **db);
int cat_filedbfunc(int op, catdb_data *entry, void *handle);
int cat_freefiledb(cat_filedb *db);

long cat_filelength(const char *path);
time_t cat_filetime(const char *path);
int cat_getfile(const char *path, char **ptr);
int cat_truncatefile(FILE *f, unsigned long len);
int cat_lockfile(FILE *f, int nowait);
int cat_unlockfile(FILE *f);

int cat_pushback(cat_session *sess, int fd, cat_data data);

#ifdef CAT_UNIX
extern int cat_optind;
extern int cat_opterr;
extern int cat_optopt;
extern char *cat_optarg;
#endif

#ifdef CAT_WIN32
extern int *___cat_optind();
#define cat_optind (*(___cat_optind()))
extern int *___cat_opterr();
#define cat_opterr (*(___cat_opterr()))
extern int *___cat_optopt();
#define cat_optopt (*(___cat_optopt()))
extern char **___cat_optarg();
#define cat_optarg (*(___cat_optarg()))
#endif

#ifdef CAT_UNIX
pid_t cat_fork(void);
#endif


int cat_getopt(int argc, char **argv, const char *options);

#ifdef CAT_WIN32
# define cat_sleep(N)		Sleep((N) * 1000)
#endif
#ifdef CAT_UNIX
# define cat_sleep(N)		sleep(N)
#endif

#ifdef __cplusplus
}
#endif

#endif /* !_cat_catutil_h */
