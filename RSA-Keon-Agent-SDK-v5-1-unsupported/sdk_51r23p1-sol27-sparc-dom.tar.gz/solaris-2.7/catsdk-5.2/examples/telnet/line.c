/*
 * @(#)$Header: /srcroot/Lego-CVSROOT/catagent/example_telnet/line.c,v 1.7 2000/01/17 14:57:49 elias Exp $
 *
 * Copyright (c) 1998 Security Dynamics
 *
 * Description:	Line buffering filter.  If pushed on a read descriptor,
 *		it ensures that the filters above it will get exactly one
 *		line per call.  Partial lines are merged, multiple lines
 *		are split.
 *
 *		A "line" is defined as any sequence of bytes terminated
 *		by a newline (ascii 10 decimal).
 *
 * MT-Level:    Safe
 */

#include <cat/cat.h>
#include "telnet.h"

struct filterdata {
    cat_buffer *keep;
};

static void line_free(cat_session *sess, cat_filter *me);
static int line_rw(cat_session *sess, cat_filter *me, int fd_id);

#define DEBUG_MODULE "line."

/*
 * cat_linefilter() --
 *
 *   Initialize the line filter
 *
 * Arguments:
 *   fd_ids	IN:     The descriptors to filter
 *   filter	IN/OUT: Pointer to the filter struct to initialize
 *
 * Returns a pointer to the supplied filter.
 */

cat_filter *
cat_linefilter(cat_filter *filter)
{
    struct filterdata *data;

    memset(filter, 0, sizeof(cat_filter));
    if ((data = malloc(sizeof(struct filterdata))) == NULL) {
	return NULL;
    }
    data->keep = NULL;

    strncpy(filter->name, "line", sizeof(filter->name));
    filter->fd_ids = CAT_CLIENT_RFD;
    filter->rw = line_rw;
    filter->free = line_free;
    filter->filterdata = data;

    return filter;
}


/*
 * Filtering function.
 */

static int
line_rw(cat_session *sess, cat_filter *me, int fd_id)
{
    static const char *F = DEBUG_MODULE "line_rw";
    int c, c1;
    cat_buffer *b;
    struct filterdata *data;

    /*
     * Get current buffer.  If there is a partial line from a
     * previous call, prepend that.  If there is no current
     * buffer, this function has been called because it returned
     * CAT_MORE_DATA on the previous call, and thus has
     * data available.
     */

    b = catbuf_get(sess, fd_id);
    if (b != NULL) {
	catbuf_index(b, 0);
	if (catbuf_ch(b) == TELNET_IAC) {
	    /*
	     * This was telnet data, pass it on...
	     */
	    catbuf_put(sess, fd_id, b);
	    CAT_DEBUG5((sess, F, "Passing telnet data through"));
	    return 0;
	}
	catbuf_index(b, 0);
    }
    data = me->filterdata;
    if (data->keep != NULL) {
	b = catbuf_join(data->keep, b);
	data->keep = NULL;
    }

    /*
     * Scan for a separator byte.  
     * We allow '\n', '\r\n' and '\r', in that order
     * of preference.
     * Note that when there was data left over from a previous call, 
     * we start at the end of it, as the buffer keeps it's position.
     */
    
    while ((c = catbuf_ch(b)) != -1) {
	if (c == '\n') {
	    break;
	}
	if (c == '\r') {
	    c1 = catbuf_ch(b);
	    if (c1 == '\n') {
		c = c1;
		break;
	    }
	    if (c1 == -1) {
		break;
	    }
	    catbuf_index(b, catbuf_pos(b) - 1);
	    break;
	}
    }

    /*
     * Reached the end of the buffer, so we still only have a
     * partial line.  Keep it and return without passing any
     * data further up the stack.
     */

    if (c == -1) {
	data->keep = b;
	CAT_DEBUG5((sess, F, "Keeping data"));
	return 0;
    }


    /*
     * There was a separator.  If it is at the end of the buffer,
     * we don't need to do anything more.  Otherwise split the
     * buffer, keep the rest, and return CAT_MORE_DATA to come
     * back and scan the rest for more lines.
     */

    if (catbuf_pos(b) < catbuf_len(b)) {
	data->keep = catbuf_split(b, catbuf_pos(b));
    }
    catbuf_put(sess, fd_id, b);

    return (data->keep != NULL) ? CAT_MORE_DATA : 0;
}


/*
 * Free anything in this filter when it is popped, silently
 * discarding any partial lines. Pop the telnetline filter
 * below as well...
 */

static void
line_free(cat_session *sess, cat_filter *me)
{
    struct filterdata *data;

    if ((data = me->filterdata) != NULL) {
	if (data->keep != NULL) {
	    catbuf_free(data->keep);
	}
	free(data);
    }
    cat_popfilter(sess);
}

