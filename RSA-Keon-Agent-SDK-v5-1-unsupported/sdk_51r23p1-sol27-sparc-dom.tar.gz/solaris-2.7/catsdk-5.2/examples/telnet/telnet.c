/*
 * @(#)$Header: /srcroot/Lego-CVSROOT/catagent/example_telnet/telnet.c,v 1.12 2000/03/17 15:39:22 elias Exp $
 *
 * Copyright (c) 1998 Security Dynamics
 *
 * Description:	Sample filter for login via telnet.
 *
 * MT-Level:    Safe
 */

#include <cat/gen.h>
#include <cat/cat.h>
#include <ctype.h>
#include "telnet.h"

#define DEBUG_MODULE "telnet."

#define ACTN_ALLOW    0
#define ACTN_DISALLOW 1


/*
 * Filter private data
 */

typedef struct telnetdata telnetdata;

typedef int actncb(cat_session *sess, cat_buffer *b, telnetdata *tnd, int fd_id, void *data);

typedef struct {
    int     action;       /* Aliow or disallow this option to be negotiated */
    actncb *acb;          /* Callback to take certain action for certain options */
} optaction;

struct telnetdata {
    int state;		         /* State. What we look for. */
    char *mapuser;		 /* User from database */
    char *mappass;		 /* Password from database */
    int seenlogin;               /* seen "login: " from server? */
    int loginsent;
    int do_rolemap;              /* Should we catch rolename from client def: FALSE */
    unsigned char optact_s[256]; /* Allow or disallow the basic options, server side */
    unsigned char optact_c[256]; /* client side */
    actncb *opt_cb[256];         /* callbacks for options */
    char *errmess;               /* error message on failed login */
};


/*
 * The "commands" we recv from the server
 */

static char *cmdlist[4] = {
#define CMD_LOGIN	0
    NULL,
#define CMD_PASSWD	1
    NULL,
#define CMD_DONE        2
    NULL,
#define CMD_FAIL        3
    NULL,
};



static int telnet_init(cat_session *sess, cat_filter *me);
static void telnet_free(cat_session *sess, cat_filter *me);
static int tnsso_rw(cat_session *sess, cat_filter *me, int fd_id);
static int tnrolemap_rw(cat_session *sess, cat_filter *me, int fd_id);
static int appendbuf(cat_buffer *b, ...);
static int pattern_match(cat_buffer *b, unsigned char *string, int len);
static int examine_option(cat_session *sess, cat_buffer *b, 
			  telnetdata *tndata, int fd_id);
static int
telnet_trace(cat_session *sess, cat_buffer *b, telnetdata *tnd, int fd_id, 
	     void *data);



/*
 * cat_telnetfilter() --
 *
 *   Initialize a filter that will do secure login of a TELNET
 *   connection.  The client is assumed to be on CAT_CLIENT_xFD,
 *   the server on CAT_SERVER_xFD.
 *
 * Arguments:
 *   filter	IN/OUT: Pointer to the filter struct to initialize
 *
 * Returns a pointer to the supplied filter.
 */

cat_filter *
cat_telnetfilter(cat_filter *filter)
{
    telnetdata *data;

    memset(filter, 0, sizeof(cat_filter));
    if ((data = malloc(sizeof(*data))) == NULL) {
	return NULL;
    }
    memset(data, 0, sizeof(*data));
    strncpy(filter->name, "telnet", sizeof(filter->name));
    filter->fd_ids = CAT_SERVER_RFD | CAT_CLIENT_RFD;
    filter->rw = tnsso_rw;
    filter->free = telnet_free;
    filter->init = telnet_init;
    filter->filterdata = data;

    return filter;
}



/*
 * Read/write for role-mapping. This involves catching the login
 * name and map it to an account and exchange the password sent by 
 * the client to a mapped password.
 *
 * We don't have to keep track of the telnet options here, since the 
 * The data flow is identical to the case without the Agent.
 *
 * However, it can be of interest to examine the telnet options 
 * negotiated if certain options are considered "dangerous" and 
 * needs to be prevented.
 */

static int
tnrolemap_rw(cat_session *sess, cat_filter *me, int fd_id)
{
    static const char *F = DEBUG_MODULE "tnrolemap_rw";
    cat_buffer *b, *buf = NULL;
    telnetdata *data;
    int i = 0, idx, ret, len;
    char role[1024];
    
    ret = 0;
    data = me->filterdata;
    b = catbuf_get(sess, fd_id);
    
    examine_option(sess, b, data, fd_id);
    if (catbuf_len(b) == 0) {
	/*
	 * examine option may have refused this one
	 */
	return CAT_OK;
    }

    if (fd_id == CAT_SERVER_RFD) {

	/*
	 * Data from server.
	 *
	 * Look for the string indicated by the current state.
	 */
	
	switch (data->state) {
	  case CMD_LOGIN:
	    if ((idx = pattern_match(b, 
				     cmdlist[data->state], 
				     strlen(cmdlist[data->state]))) >= 0)
	    {
		data->seenlogin = 1;
		CAT_DEBUG3((sess, F, "Seen login"));
		ret = CAT_OK;
		data->state = CMD_PASSWD;
	    }
	    break;
	  case CMD_PASSWD:
	    if ((idx = pattern_match(b, 
				     cmdlist[data->state], 
				     strlen(cmdlist[data->state]))) >= 0)
	    {
		data->state = CMD_DONE;
	    }
	    break;
	  case CMD_DONE:
	    if ((idx = pattern_match(b, 
				     cmdlist[data->state], 
				     strlen(cmdlist[data->state]))) >= 0)
	    {
		ret = CAT_POP_FILTER;
	    } else if ((idx = pattern_match(b, 
					    cmdlist[data->state + 1], 
					    strlen(cmdlist[data->state + 1]))) >= 0)
	    {
		/*
		 * Login failed. Log, notify client and close connection
		 */
		catgen_log(sess, CATLOG_AUTHFAIL);
		buf = catbuf_new(sess, 0, NULL);
		catbuf_insert(buf, 0, strlen(data->errmess), data->errmess);
		cat_send(sess, CAT_CLIENT_WFD, buf);
		buf = NULL;
		b = NULL;
		ret = CAT_EACCES;
		break;
	    }
	    break;
	  default:
	    /* XXX: fix this */
	    CAT_DEBUG3((sess, F, "Inconsistent state. Internal error. Closing..."));
	    ret = CAT_EINTERNAL;
	}
    } else {
	/*
	 * Data from client
	 *
	 * If we have seen "login: " we expect that the next thing sent by the 
	 * client is the login name and use that for role-mapping.
	 *
	 * If we have seen "Password: " we expect that the client sends the password which
	 * we rip out and ue the mapped password instead.
	 */
	catbuf_index(b, 0);
	switch (data->state) {
	case CMD_PASSWD:
	  if (catbuf_ch(b) == TELNET_IAC) {
	      break;
	  }
	  /*
	   * Get the role name and clear buffer
	   */
	  len = catbuf_extract(b, 0, sizeof(role)-1, role);
	  role[len] = 0;
	  CAT_DEBUG3((sess, F, "Removing rolename \"%s\" sent by client", role));
	  
	  /*
	   * Strip trailing whites
	   */
	  while(role[i]) {
	      if (isspace(role[i])) {
		  role[i] = 0;
		  break;
	      }
	      i++;
	  }
	  /*
	   * Authenticate user.
	   */
	  ret = catgen_checkauth(sess, role, NULL, NULL);
	  if (ret != 0) {
	      return ret;
	  }
	  catgen_log(sess, CATLOG_AUTHOK);
	  
	  /*
	   * Get mapped authentication information.
	   * User must already have been authenticated.
	   */
	  ret = catgen_dbmap(sess, role, NULL, NULL,
			     &data->mapuser, &data->mappass, NULL);
	  if (ret != 0) {
	      
	      /*
	       * Mapping failed.  Send an error message to client
	       * and close connection by returning an error.
	       */
	      
	      catgen_log(sess, CATLOG_MAPFAIL);
	      CAT_DEBUG2((sess, F, "USER mapping failed"));
	      ret = CAT_EACCES;
	  } else {
	      catgen_log(sess, CATLOG_AUTHUSEROK);
	  }
	  /*
	   * Insert mapped login into buffer
	   */
	  appendbuf(b, data->mapuser, "\r\n", NULL);
	  (data->loginsent)++;
	  CAT_DEBUG3((sess, F, "Sending %s", data->mapuser));
	  break;
	  case CMD_DONE:
	    /*
	     * Remove the password sent by the client and send the 
	     * mapped password.
	     */
	    if (catbuf_ch(b) == TELNET_IAC) {
		break;
	    }
	    catbuf_delete(b, 0, catbuf_len(b));
	    appendbuf(b, data->mappass, "\r\n", NULL);
	    break;
	  default:
	    /*
	     * Remove anything else sent by client (unless telnet data). 
	     * It really shouldn't be talking here.
	     */
	    if (catbuf_ch(b) == TELNET_IAC) {
		break;
	    }
	    catbuf_free(b);
	    b = NULL;
	    break;
	}
    }
    
    /*
     * Return buffer to the data stream, if it is still non-null.
     */
    if (b != NULL) {
	catbuf_put(sess, fd_id, b);
    }

    /*
     * Send reply to server if any
     */
    if (buf != NULL) {
	cat_send(sess, CAT_SERVER_WFD, buf);
    }

    return ret;
}


/*
 * Non-rolemap case. Here we just send the mapped username when the login string 
 * is seen from the server and the mapped password when the server has sent the 
 * password string.
 *
 * To avoid getting "in between" the telnet options passed, we wait for all
 * telnet options whose negotiation started prior to the server sending "login: " 
 * to finish before replying with the username.
 * This will hopefully make the telnet state consistent even though we break the
 * normal order of the data-flow.
 */
static int
tnsso_rw(cat_session *sess, cat_filter *me, int fd_id)
{
    static const char *F = DEBUG_MODULE "tnsso_rw";
    cat_buffer *b, *buf = NULL;
    telnetdata *data;
    int idx, ret, len;
    char tmp[1024];

    ret = 0;
    data = me->filterdata;
    b = catbuf_get(sess, fd_id);

    /* 
     * Keep track of the current options negotiation status
     */
    
    examine_option(sess, b, data, fd_id);
    if (catbuf_len(b) == 0) {
	/*
	 * examine option may have refused this one
	 */
	catbuf_free(b);
	return CAT_OK;
    }
    
    if (fd_id == CAT_SERVER_RFD) {

	/*
	 * Data from server.
	 *
	 * Look for the "login:" string. If found we know that we
	 * should reply with the username.
	 * Must cut out the string ad pass the packet onto the 
	 * client. May contain control characters.
	 */
	
	switch (data->state) {
	  case CMD_LOGIN:
	    if ((idx = pattern_match(b, 
				     cmdlist[data->state], 
				     strlen(cmdlist[data->state]))) >= 0) 
	    {
		data->seenlogin = 1;
		catbuf_extract(b, idx, strlen(cmdlist[data->state]), tmp);
		tmp[strlen(cmdlist[data->state])] = 0;
		CAT_DEBUG3((sess, F, "Seen (and removed) login string"));
		
		/*
		 * Send login to server
		 */
		buf = catbuf_new(sess, 0, NULL);
		appendbuf(buf, data->mapuser, "\r\n", NULL);
		CAT_DEBUG3((sess, F, "Sending %s", data->mapuser));
		
		ret = CAT_OK;
		data->state = CMD_PASSWD;
	    }
	    break;
	  case CMD_PASSWD:
	    if ((idx = pattern_match(b, 
				     cmdlist[data->state], 
				     strlen(cmdlist[data->state]))) >= 0)
	    {
		catbuf_extract(b, idx, strlen(cmdlist[data->state]), tmp);
		tmp[strlen(cmdlist[data->state])] = 0;
		CAT_DEBUG3((sess, F, "Seen (and removed) password string"));

		/*
		 * Send password to server 
		 */
		buf = catbuf_new(sess, 0, NULL);
		appendbuf(buf, data->mappass, "\r\n", NULL);
		CAT_DEBUG3((sess, F, "Sending %s", data->mappass));
		ret = CAT_OK;
		data->state = CMD_DONE;
	    }
	    break;
	  case CMD_DONE:
	    if ((idx = pattern_match(b, 
				     cmdlist[data->state], 
				     strlen(cmdlist[data->state]))) >= 0)
	    {
		/*
		 * login successful; pop the filter
		 */
		ret = CAT_POP_FILTER;
	    } else if ((idx = pattern_match(b, 
					    cmdlist[data->state + 1], 
					    strlen(cmdlist[data->state + 1]))) >= 0)
	    {
		/*
		 * Login failed. Log, notify client and close connection
		 */
		catgen_log(sess, CATLOG_AUTHFAIL);
		buf = catbuf_new(sess, 0, NULL);
		catbuf_insert(buf, 0, strlen(data->errmess), data->errmess);
		cat_send(sess, CAT_CLIENT_WFD, buf);
		buf = NULL;
		b = NULL;
		ret = CAT_EACCES;
		break;
	    }
	    break;
	  default:
	    CAT_DEBUG3((sess, F, "Inconsistent state. Internal error. Closing..."));
	    ret = CAT_EINTERNAL;
	}
    } else {
	/*
	 * Data from client
	 * 
	 * Mute the client during login (pass telnet option though)
	 */
	catbuf_index(b, 0);
	
	if (catbuf_ch(b) != TELNET_IAC) {
	    len = catbuf_extract(b, 0, sizeof(tmp)-1, tmp);
	    tmp[len] = 0;
	    CAT_DEBUG3((sess, F, "Removing \"%s\" from client", tmp));
	    catbuf_free(b);
	    b = NULL;
	}
    }

    /*
     * Return buffer to the data stream, if it is still non-null.
     */
    if (b != NULL) {
	catbuf_put(sess, fd_id, b);
    }

    /*
     * Send reply to server if any
     */
    if (buf != NULL) {
	cat_send(sess, CAT_SERVER_WFD, buf);
    }

    return ret;
}



/*
 * Called when the filter is pushed.
 * Check if the user is allowed to log in and if so,
 * obtain the credentials.
 */

static int
telnet_init(cat_session *sess, cat_filter *me)
{
    static const char *F = DEBUG_MODULE "telnet_init";
    int ret = 0;
    telnetdata *data;
    cat_filter f;
    char *loginstr, *passwdstr, *okstr, *failstr, *failmsg;
    int  do_rolemap;
    data = me->filterdata;

    data->state = CMD_LOGIN;

    /*
     * Determine if we have rolemap mode or just SSO
     * and set the rw function accordingly (SSO is default).
     */
    ret = catgen_getint(sess, "do_rolemap", &do_rolemap);
    if (ret < 0) {
	CAT_DEBUG3((sess, F, "\"do_rolemap\" param not set. Using SSO."));
	data->do_rolemap = FALSE;
    } else {
	if (do_rolemap) {
	    data->do_rolemap = TRUE;
	    me->rw = tnrolemap_rw;
	} else {
	    data->do_rolemap = FALSE;
	}
    }

    /*
     * If we don't use role-mapping we can get the user 
     * credentials right away.
     */
    if (!data->do_rolemap) {
	int i;
	/*
	 * Authenticate user.
	 */
	ret = catgen_checkauth(sess, NULL, NULL, NULL);
	if (ret != 0) {
	    return ret;
	}
	catgen_log(sess, CATLOG_AUTHOK);
	
	/*
	 * Get mapped authentication information.
	 * User must already have been authenticated.
	 */
	ret = catgen_dbmap(sess, NULL, NULL, NULL,
			   &data->mapuser, &data->mappass, NULL);
	if (ret != 0) {
	    
	    /*
	     * Mapping failed.  Send an error message to client
	     * and close connection by returning an error.
	     */
	    
	    catgen_log(sess, CATLOG_MAPFAIL);
	    CAT_DEBUG2((sess, F, "USER mapping failed"));
	    ret = CAT_EACCES;
	} else {
	    catgen_log(sess, CATLOG_AUTHUSEROK);
	}
	
	/*
	 * Don't allow echo on the client side. Should not be needed,
	 * and sometimes causes trouble in the SSO-case where we break
	 * the natural order of the login and password.
	 */
	data->optact_c[TELOPT_ECHO] = ACTN_DISALLOW;
	
	/*
	 * Set a trace function as callback for all options
	 */
	for (i = 0; i <= TELOPT_EXOPL; i++) {
	    data->opt_cb[i] = telnet_trace;
	}
    } else {
	/*
	 *  Set a trace function as callback for all options
	 */
	int i;
	for (i = 0; i <= TELOPT_EXOPL; i++) {
	    data->opt_cb[i] = telnet_trace;
	}
    }

    /*
     * Set up the expect strings for the login sequence
     */
    catinfo_get(sess, "loginstrs.login", &loginstr);
    catinfo_get(sess, "loginstrs.passwd", &passwdstr);
    catinfo_get(sess, "loginstrs.done", &okstr);
    catinfo_get(sess, "loginstrs.fail", &failstr);
    catinfo_get(sess, "loginstrs.failmsg", &failmsg);
    
    cmdlist[CMD_LOGIN]  = (loginstr ? loginstr : strdup(DEFLOGIN));
    cmdlist[CMD_PASSWD] = (passwdstr ? passwdstr : strdup(DEFPWD));
    cmdlist[CMD_DONE]   = (okstr ? okstr : strdup(DEFDONE));
    cmdlist[CMD_FAIL]   = (failstr ? failstr : strdup(DEFINCORR));
    data->errmess = (failmsg ? failmsg : strdup(DEFERRMSG));
    
    if (!(cmdlist[CMD_LOGIN] && cmdlist[CMD_PASSWD] && cmdlist[CMD_DONE] &&
	cmdlist[CMD_FAIL] && data->errmess))
    {
	CAT_DEBUG2((sess, F, "Could not find all expect strings."));
	ret = CAT_ERROR;
    }
    
    ret = cat_pushfilter(sess, cat_telnetline(&f));
    ret = cat_pushfilter(sess, cat_linefilter(&f));   
    
    return (ret < 0) ? ret : 0;
}


/*
 * Called when the filter is popped.
 * Deallocate the private data of the filer, and pop the line filter.
 */

static void
telnet_free(cat_session *sess, cat_filter *me)
{
    telnetdata *data;

    if ((data = me->filterdata) != NULL) {
	if (data->mapuser != NULL) {
	    free(data->mapuser);
	}
	if (data->mappass != NULL) {
	    free(data->mappass);
	}
	free(cmdlist[CMD_LOGIN]);
	free(cmdlist[CMD_PASSWD]);
	free(cmdlist[CMD_DONE]);
	free(cmdlist[CMD_FAIL]);
	free(data->errmess);
	free(data);
    }
    cat_popfilter(sess);
}


/*
 * Search for an exact match of a string in a buffer, starting
 * at the current buffer index.
 * Returns the buffer index where the string starts or -1 
 * if not found.
 * Does not modify the buffer index.
 */

static int
pattern_match(cat_buffer *b, unsigned char *string, int len) 
{
    static const char *F = DEBUG_MODULE "pattern_match";
    int idx, off, origidx;
  
    idx = origidx = catbuf_pos(b);

    while (1) {
	if ((off = catbuf_scan(b, string, 1)) < 0) {
	    idx = -1;
	    break;
	}
	idx += off;
	catbuf_index(b, idx);
	if (catbuf_match(b, string, len) == len) {
	    break;
	}
	idx++;
	if (idx < catbuf_len(b)) {
	    catbuf_index(b, idx);
	} else {
	    idx = -1;
	    break;
	}
    }
    
    catbuf_index(b, origidx);
    return idx;
}


/*
 * Append a variable number of strings to a buffer.
 */

static int
appendbuf(cat_buffer *b, ...)
{
    char *s;
    va_list ap;
    int pos, len;

    pos = catbuf_pos(b);
    va_start(ap, b);
    while ((s = va_arg(ap, char *)) != NULL) {
	len = strlen(s);
	catbuf_insert(b, pos, len, s);
	pos += len;
    }
    va_end(ap);

    return pos;
}


/*
 * This function will examine the telnet option passed from the
 * filter below (only 1 option at a time will arrive) and see if it
 * should be allowed or not. If the option is allowed and there is
 * a callback set, the callback will be invoked. This is useful if
 * it is desired to do any more advanced recording of the state, or
 * if data in a sub-negotiation is to be manipulated.
 */

static int
examine_option(cat_session *sess, cat_buffer *b, telnetdata *tndata, int fd_id)
{
    static const char *F = DEBUG_MODULE "examine_option";
    int orig_index, ret;
    unsigned char cmd, opt;
    cat_buffer *new;
    unsigned char reply[3] = { 0xff, 0, 0};

    ret = 0;
    orig_index = catbuf_pos(b);
    catbuf_index(b, 0);
    if (catbuf_ch(b) != TELNET_IAC) {
	/*
	 * It wasn't a telnet command
	 */
	goto done;
    }
    cmd = catbuf_ch(b);
    switch (cmd) {
      case TELNET_WONT:
      case TELNET_DONT:
	/*
	 * Always OK. We can't force the client or server to do
	 * anything they don't want to.
	 *
	 * Invoke callback anyway. Might be useful for state recording.
	 */
	opt = catbuf_ch(b);
	if (tndata->opt_cb[opt] != NULL) {
	    tndata->opt_cb[opt](sess, b, tndata, fd_id, NULL);
	}
	break;
      case TELNET_DO:
	opt = catbuf_ch(b);
	if ((fd_id == CAT_SERVER_RFD && tndata->optact_c[opt] == ACTN_DISALLOW) ||
	    (fd_id == CAT_CLIENT_RFD && tndata->optact_s[opt] == ACTN_DISALLOW)) 
	{
	    /*
	     * Don't let them negotiate this option
	     */
	    new = catbuf_new(sess, 0, NULL);
	    reply[1] = TELNET_WONT;
	    reply[2] = opt;
	    catbuf_insert(new, 0, sizeof(reply), reply);
	    CAT_DEBUG3((sess, F, "Denying TELNET option"));
	    /*
	     * If a callback is set for this option; invoke it.
	     */
	    if (tndata->opt_cb[opt] != NULL) {
		tndata->opt_cb[opt](sess, b, tndata, fd_id, NULL);
	    }
	    if (fd_id & CAT_SERVER_RFD) {
		cat_send(sess, CAT_SERVER_WFD, new);
	    } else {
		cat_send(sess, CAT_CLIENT_WFD, new);
	    }
	    catbuf_delete(b, 0, catbuf_len(b));
	} else {
	    /*
	     * If a callback is set for this option; invoke it.
	     */
	    if (tndata->opt_cb[opt] != NULL) {
		tndata->opt_cb[opt](sess, b, tndata, fd_id, NULL);
	    }
	}
	break;
      case TELNET_WILL:
	opt = catbuf_ch(b);
	if ((fd_id == CAT_SERVER_RFD && tndata->optact_s[opt] == ACTN_DISALLOW) ||
	    (fd_id == CAT_CLIENT_RFD && tndata->optact_c[opt] == ACTN_DISALLOW)) 
	{
	    /*
	     * Don't let them negotiate this option
	     */
	    new = catbuf_new(sess, 0, NULL);
	    reply[1] = TELNET_DONT;
	    reply[2] = opt;
	    catbuf_insert(new, 0, sizeof(reply), reply);
	    CAT_DEBUG3((sess, F, "Denying TELNET option"));
	    
	    /*
	     * If a callback is set for this option; invoke it.
	     */
	    if (tndata->opt_cb[opt] != NULL) {
		tndata->opt_cb[opt](sess, b, tndata, fd_id, NULL);
	    }
	    if (fd_id & CAT_SERVER_RFD) {
		cat_send(sess, CAT_SERVER_WFD, new);
	    } else {
		cat_send(sess, CAT_CLIENT_WFD, new);
	    }
	    catbuf_delete(b, 0, catbuf_len(b));
	} else {
	    /*
	     * If a callback is set for this option; invoke it.
	     */
	    if (tndata->opt_cb[opt] != NULL) {
		tndata->opt_cb[opt](sess, b, tndata, fd_id, NULL);
	    }
	}
	break;
      case TELNET_SB:
	/*
	 * Sub negotiation of allowed option. Invoke callback if any.
	 */
	opt = catbuf_ch(b);
	if (tndata->opt_cb[opt] != NULL) {
	    tndata->opt_cb[opt](sess, b, tndata, fd_id, NULL);
	}
	break;
	
      default:
	break;
    }

  done:
    catbuf_index(b, orig_index);
    return ret;
}
    
    
/*
 * Test option callback
 * 
 * Just send the telnet commands and output to the debug trace.
 */
static int
telnet_trace(cat_session *sess, cat_buffer *b, telnetdata *tnd, int fd_id, void *data)
{
    static const char *F = DEBUG_MODULE "telnet_trace";
    char message[1024];
    unsigned char cmd, opt;
    char srvstr[] = "server";
    char clistr[] = "client";
    char *str, *optstr;

    int orig_idx;
    char *option_strings[] = {
	"TELOPT_BINARY", 
	"TELOPT_ECHO", 
	"TELOPT_RCP", 
	"TELOPT_SGA", 
	"TELOPT_NAMS", 
	"TELOPT_STATUS", 
	"TELOPT_TM", 
	"TELOPT_RCTE", 
	"TELOPT_NAOL", 
	"TELOPT_NAOP", 
	"TELOPT_NAOCRD", 
	"TELOPT_NAOHTS", 
	"TELOPT_NAOHTD", 
	"TELOPT_NAOFFD", 
	"TELOPT_NAOVTS", 
	"TELOPT_NAOVTD", 
	"TELOPT_NAOLFD", 
	"TELOPT_XASCII", 
	"TELOPT_LOGOUT", 
	"TELOPT_BM", 
	"TELOPT_DET", 
	"TELOPT_SUPDUP", 
	"TELOPT_SUPDUPOUTPUT", 
	"TELOPT_SNDLOC", 
	"TELOPT_TTYPE", 
	"TELOPT_EOR", 
	"TELOPT_TUID", 
	"TELOPT_OUTMRK", 
	"TELOPT_TTYLOC", 
	"TELOPT_3270REGIME", 
	"TELOPT_X3PAD", 
	"TELOPT_NAWS", 
	"TELOPT_TSPEED", 
	"TELOPT_LFLOW", 
	"TELOPT_LINEMODE", 
	"TELOPT_XDISPLOC", 
	"TELOPT_OLD_ENVIRON", 
	"TELOPT_AUTHENTICATION", 
	"TELOPT_ENCRYPT", 
	"TELOPT_NEW_ENVIRON", 
	"TELOPT_EXOPL" };

    char * command_strings[] = {
	"TELNET_SE", 
	"TELNET_NOP", 
	"TELNET_DM", 
	"TELNET_BREAK", 
	"TELNET_IP", 
	"TELNET_AO", 
	"TELNET_AYT", 
	"TELNET_EC", 
	"TELNET_EL", 
	"TELNET_GA", 
	"TELNET_SB", 
	"TELNET_WILL", 
	"TELNET_WONT", 
	"TELNET_DO", 
	"TELNET_DONT", 
	"TELNET_IAC", 
    };

    orig_idx = catbuf_pos(b);
    catbuf_index(b, 0);
    
    if (fd_id & CAT_SERVER_RFD) {
	str = srvstr;
    } else {
	str = clistr;
    }
    /*
     * Skip iac
     */
    catbuf_ch(b);
    /*
     * Get command
     */
    cmd = catbuf_ch(b);
    switch (cmd) {
      case TELNET_WILL:
      case TELNET_WONT:
      case TELNET_DO:
      case TELNET_DONT:
      case TELNET_SB:
	opt = catbuf_ch(b);
	if (opt <= TELOPT_EXOPL) {
	    optstr = option_strings[opt];
	} else {
	    optstr = "Unknown option";
	}
	snprintf(message, sizeof(message), "%s: %s %s (%d)",
		 str,
		 command_strings[cmd - TELNET_SE], 
		 optstr, 
		 opt);
	break;
      default:
	snprintf(message, sizeof(message), "%s: %s ",
		 str,
		 command_strings[cmd - TELNET_SE]);
	break;
    }

    CAT_DEBUG3((sess, F, "%s", message));

    catbuf_index(b, orig_idx);
    return 0;
}
