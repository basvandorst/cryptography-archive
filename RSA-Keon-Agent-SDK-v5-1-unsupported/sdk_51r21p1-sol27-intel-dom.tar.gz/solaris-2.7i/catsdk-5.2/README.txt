============================================================
KEON Agent SDK 5.1	README		   27 January, 2000
============================================================
------------------------------------------------------------
                   CONTENTS OF THIS DOCUMENT
------------------------------------------------------------
o Copyright
o Introduction
o Supported platforms
o Main Features
o Installation notes
o Revision history

------------------------------------------------------------
                      COPYRIGHT
------------------------------------------------------------

Copyright (c) 2000 by Security Dynamics Technologies Inc.
All rights reserved.

------------------------------------------------------------
                      INTRODUCTION
------------------------------------------------------------

The Keon Agent SDK 5.1 is intended for creation appliction 
Agents that may provide authentication, encryption and single 
sign on to existing client/server based application protocols.

------------------------------------------------------------
                      SUPPORTED PLATFORMS
------------------------------------------------------------

* Windows NT, Service Pack 4

* Solaris 2.6

------------------------------------------------------------
                      MAIN FEATURES
------------------------------------------------------------

The Keon Agent SDK provides the possibility to create 
application Agents to secure applications by strong
authentication, line encryption and single sign-on in 
both the Keon 4.5 and Keon 5.0 environment.

* Supports ALLTAK/ALLTAAS and SSL3 protocols.

* Supports both Keon 4.5 logging and Keon 5.0 (ELS) logging.

* Introducing easy development of Agents.

* Contains full installation and configuration framwork.

------------------------------------------------------------
                       INSTALLATION NOTES
------------------------------------------------------------

* Run the install script found under the platform specific
  directory on the distribution. You will be prompted to 
  chose what to install. 

------------------------------------------------------------
                       REVISION HISTORY
------------------------------------------------------------

The following revisions have been made:

5.1

  * Initial release

