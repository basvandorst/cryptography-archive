/*
 * @(#)$Header: /srcroot/Lego-CVSROOT/catagent/example_telnet/telnetagent.c,v 1.4 2000/03/23 09:09:11 elias Exp $
 *
 * Copyright (c) 1998 Security Dynamics
 * This is unpublished proprietary source code.
 *
 * Description: Sample Agent for Unix login via TELNET.
 */


#include <stdio.h>
#include <string.h>
#include <cat/gen.h>

#include "telnet.h"
#include "version.h"

#define SVC_VER		SERVICE "-" VERSION

static int doit(cat_session *sess, const char *port, void *data);


/*
 * Standard agent.  Takes standard arguments for
 * agents on whatever platform it is compiled for.
 */

int
main(int argc, char **argv)
{
    /*
     * If this call returns, there is nothing more to do.
     *
     * There should normally be no extra code in the main
     * program when using catgen_server(), as it would get
     * executed at different points depending on how the
     * agents was started (As standalone daemon, from
     * inetd on unix, or as an NT service)
     */

    return catgen_server(SVC_VER, argc, argv, doit, NULL);
}


/*
 * Called for each new incoming client connection, directly
 * after the server connection has been established.
 */

static int
doit(cat_session *sess, const char *port, void *data)
{
    static const char *F = "doit";
    cat_filter f;
    int err;

    /*
     * Set up a secure channel.
     */

    if ((err = catgen_serverencryption(sess)) != 0) {
	return err;
    }

    /*
     * Handle the application protocol by pushing a filter to
     * take care of it.
     */
    cat_telnetfilter(&f);
     if ((err = cat_pushfilter(sess, &f)) < 0) {
	 return err;
     }
     
    /*
     * Tell toolkit to handle the session.
     */

    return CAT_CONTINUE;
}

