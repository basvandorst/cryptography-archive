----------------------------------------------------------------------
                  Native RSA Keon Support Example
----------------------------------------------------------------------

This is an example of how to implement native Keon support in 
an application.  The application server is a primitive, single-
threaded Web server that can respond to a GET request and demand HTTP 
authorization from the client for files stored in a specific 
'protected' folder. The Web server speaks only a subset of HTTP 1.0.
By the way, the username/password for the protected page is
roger/ramjet. But do not tell anyone.

The code is compiled conditionally; if the symbol USE_CAT is defined,
Keon Agent SDK is used to secure the transmission, perform
authorization checking, user mapping, and logging. If USE_CAT is
not defined, the Web server is built without RSA Keon support.
This text refers to the application with RSA Keon support as the 
Keon Web server and the application without RSA Keon support as 
the simple Web server.

This example uses only SSL as the encryption protocol, which means 
that logging is performed only through ELS.
The application uses its own log labels, which must be loaded
into the Keon Security Server (see Setup below and labels.txt).

This example does not require the creation of a distribution, so
you should not follow the instructions in examples/README.txt
(see Build the Application below).

NOTE:
-----
This example requires the use of RSA Keon Desktop v 5.2 to run 
correctly. If RSA Keon Desktop v 5.1 is used, Netscape Navigator must 
be used as the HTTP client when running the Keon Web server.


----------------------------------------------------------------------
			Contents
----------------------------------------------------------------------

This directory contains the following files:

main.c			- The main() of the Web server. This contains 
			  conditionally compiled code depending 
			  on whether or not Keon support is used.

request.c		- The functions used to read a request from the 
			  client. Conditionally compiled.

reply.c			- The function used to interpret the request 
			  and generate a reply. Conditionally compiled.

utils.c			- Miscellaneous helper functions, such as 
			  predicates used to decide whether or not a page 
			  is protected. Environment independent.

ws.h			- Miscellaneous definitions and prototypes for the
			  Keon-specific parts of the code.


wscat.c			- Code used to initialize the different 
			  subsystems of the Keon Agent SDK libraries.
			  Also contains functionality to set up and
			  secure the individual connections.
			  Keon Web server-specific.

wscat.h			- Definitions and prototypes specific to the 
			  Keon Web server.
	
wscat.cfg		- The default configuration file.
			  Used only by the Keon Web server.

labels.txt		- The log definition file for the Keon
			  Web server.

ca.cdb			- An empty template showing the format of the CA
			  file.

Makefile.pp		- A file that produces a makefile after 
			  processing with ppmk. The makefile is used
			  to build the Agent binary.

Makefile		- Created at install time by the installation 
			  framework. Used by make (nmake) to produce
			  the agent binaries.

ws.pp			- Application-specific symbols.

gap.txt
properties.txt		- ADF 'templates'. These become the 
			  real ADFs when the application is
			  built.

adf/			- The directory where the generated ADFs
			  are stored.


html/			- A directory containing some sample HTML pages.
			  This is the default root of the Web server.
			  Documents under the 'private' directory in
			  this folder requires HTTP authentication.

			 
----------------------------------------------------------------------
		Build the Application
----------------------------------------------------------------------
Copy the subdirectory for this example Agent to a working directory.

To build the simple Web server without Keon support (the 
default), use

     $ make

To build the simple Web server with Keon support, do as follows:

1. Remove the old object files:
   
     $ make clean

2. Edit Makefile.pp and set USE_CAT to 1 (@define(USE_CAT,1)).
3. Build a new Makefile:

     $ make Makefile

     or process it throug pp yourself. 

     $ <INSTALLDIR>/bin/ppmk -o Makefile

   where INSTALLDIR is the installation directory of the Agent SDK.

4. Build the application:

     $ make

This generates the Agent binary and ADFs.


----------------------------------------------------------------------
			Setup
----------------------------------------------------------------------

The following descriptions apply only to the Keon Web server. 


Keon Security Server 5.0
------------------------

Installation and setup on the Keon Security Server is almost identical to that 
of an Agent (see the examples/README.txt and the documentation).
The only difference is that the log labels for this application must 
be imported (see Logging below).


Credentials
-----------

Export the Agent Host Virtual Card from the Keon Security Server to your 
agent host and define the name of and path to the Virtual Card 
and enter the password in the configuration file (wscat.cfg).

Export the Root CA certificate from the Keon Security Server and insert it in
the ca.cdb template file. Define the name of and path to the CA file 
in the configuration file (wscat.cfg).


Logging
-------

If the application is to log to the ELS, you must enter the
ELS server(s) to be used in the configuration file and import the log
labels into the Keon Security Server 5.0.

You import the log labels into the Keon Security Server as follows:

  o Convert labels.txt to Unicode (UCS-2). Assume that
    the Unicode file is now called labels.uni.

  o On the Keon Security Server 

    1. 'Compile' the Unicode file by running
	 
	  sdelsmsg -i labels.uni -h dontcare.h -t transport.xxx
  
	This generates a header file that you do not need and a 
	'transport file' that you load into the server.

    2. Load the 'compiled' file into the server.

	 sdmsgimp -i transport.xxx -r report.log

    3. Read the report.log file and verify that all 11 messages
       were imported.


Miscellaneous
-------------

You can experiment with the values in the configuration file but you 
do not need to set more than those specified above.

The configuration file contains comments that describe the values.


----------------------------------------------------------------------
			Running
----------------------------------------------------------------------

Both the simple and the Keon Web server take two arguments:

     -v		Verbose. Print trace output.
     -p<port>	Use <port> as server port. Default is 4711.

Both the simple Web server and the Keon Web servers are invoked
on the command line:

    $ ./ws -p4712

If you use the simple Web server, connect to it using a Web browser 
(see NOTE above).

If you use the Keon Web server, you must connect to it using
a Web browser running on a machine that also runs the RSA Keon 
Desktop, where the port for the Web server is protected by SSL.

4
