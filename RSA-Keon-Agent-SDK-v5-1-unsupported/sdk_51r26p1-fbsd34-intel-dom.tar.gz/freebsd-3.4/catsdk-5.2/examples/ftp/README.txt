----------------------------------------------------------------------
                  FTP Example Agent
----------------------------------------------------------------------

This Agent is an example of how to secure FTP using the Keon Agent SDK.
The Agent can handle only passive mode FTP connections.

The operation of the FTP Agent is as follows:

1. When a connection is received from a client, the Agent connects to
   the FTP server, allowing the server greeting through to the client.
2. Intercept the 'USER <username>' from the client. Save the username and
   send a prompt for the required password.
3. Intercept the 'PASS <password>' from the client.
4. Map the username/password to a new username/password, retrieved
   from the PAC (or from the Keon Security Server using the Bridge protocol).
5. Log in the user with the user/password retrieved from the previous
   step. If successful, send a 'User <user> logged in' message; 
   otherwise, send a 'Login incorrect' message.
6. Interpret all commands from the client. If the Agent does not 
   understand a command, forward the command to the FTP server.
7. When a PASV command is intercepted, the Agent sets up the
   data connection, which requires the same authentication/encryption 
   as the control channel.

The following commands from the client are intercepted and never
reach the FTP server. All other commands are forwarded to the server.
      
      Command	Action
      -------	------
      USER	Store the username and prompt for the password.
      PASS	Map the username/password and try to log in the user.
      PORT	Reply 'Command not implemented'.
      PASV	Set up the data channel and start listening on a port.

Agent Design
-------------

This Agent has been built using the catgen layer. The Agent pushes 
the following filters during startup:

o An FTP protocol-specific filter that intercepts all commands
  from the client. The filter recognizes the commands in the preceding 
  list.
o A line filter. The filter makes sure that the FTP protocol filter
  receives only complete lines, that is, lines ending with \r\n.

Encryption filters and I/O handlers are pushed automatically.

Build and Setup
----------------
 
See the examples/README.txt for instructions on how to build and 
create distributions, and install Agents.

Contents
--------

This directory contains the following files:

ftp.c			- The main() for the Agent, together with calls to 
			  install the FTP filter and place the
			  Agent in server mode.

line.c			- A line filter that supplies the filters
			  above it in the filter stack with complete
			  lines.

Makefile.pp		- A file that will be processed to a makefile, 
			  which will build the executable Agent.

Makefile		- Created by the installation framework at install
			  time. The filename may differ some on depending
			  on platform.

ftp.pp		   	- Agent-specific symbol definitions.

ftp_sample.cfg		- A configuration file template for the Agent, 
			  which supplies some default values for the
			  configuration program.

port.cfg		- A port configuration template file. Contains
			  definitions for agent specific parameters.

custom.tcl		- A tcl script that calls tcl procedures
			  that allow you to insert Agent specific
			  configuration prompts into the configuration 
			  program.

ftp_sample.gap
ftp_sample.properties	- Agent definition and translation files for
			  the Agent, to be imported into the 
			  Keon Security Server 5.0.

dist.pp  		- A packing description file, used both when
			  creating the distribution and when
			  installing the Agent.

