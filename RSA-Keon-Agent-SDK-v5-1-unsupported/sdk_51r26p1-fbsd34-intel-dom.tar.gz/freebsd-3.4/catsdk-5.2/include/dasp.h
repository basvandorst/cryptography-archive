/*
 * @(#)$Id: dasp.h,v 1.3 1999/07/08 13:38:30 gosta Exp $
 *
 * Copyright � 1998 Security Dynamics
 * This is unpublished proprietary source code.
 *
 * Description:
 *
 *	DASP protocol support for the SecurSight Connect Agent Toolkit.
 *
 * Requires <cat/cat.h>
 *
 */

#ifndef _cat_dasp_h
#define _cat_dasp_h

#ifdef __cplusplus
extern "C" {
#endif

#define CATDASP_DESCFB_CIPHER	1
#define CATDASP_ND2_CIPHER	2
#define CATDASP_NULL_CIPHER	4

#define CATDASP_SERVER_SIDE	1
#define CATDASP_CLIENT_SIDE	2
#define CATDASP_ASTART_DATA	4

#define CATDASP_PROTOLEN	32
#define CATDASP_MAXFIELDS	32

typedef struct catdasp_info catdasp_info;
typedef struct catdasp_protocol catdasp_protocol;

typedef int catdasp_protohandler(cat_session  *session,
				 catdasp_protocol *protodata,
				 cat_data datafields[CATDASP_MAXFIELDS],
				 int      *nfields,
				 int       callreason);

#define CATDASP_PROTO_ALLOC  0
#define CATDASP_PROTO_FREE   1
#define CATDASP_PROTO_INIT   2
#define CATDASP_PROTO_DONE   3
#define CATDASP_PROTO_ASTART 4
#define CATDASP_PROTO_PSTART 5
#define CATDASP_PROTO_DATA   6
#define CATDASP_PROTO_AGAIN  7

#define CATDASP_HANDLER_CONT     0
#define CATDASP_HANDLER_AGAIN    1
#define CATDASP_HANDLER_DONE     2
#define CATDASP_HANDLER_IGNORED  3

struct catdasp_protocol {
    char name[CATDASP_PROTOLEN];
    catdasp_protohandler *handler;
    void *data;
    catdb_func *db_func;
    void *db_handle;
    int ciphermask;              
    int rfd;
    int wfd;
    int flags;
};

catdasp_info *catdasp_new_info(void);
void catdasp_free_info(catdasp_info *info);
int catdasp_setprotocols(catdasp_info *info,
		         const catdasp_protocol *protolist, int nprotos);
int catdasp_setciphers(catdasp_info *info,  int ciphermask);
int catdasp_setdb(catdasp_protocol *proto, catdb_func *func, void *handle);
int catdasp_initalltakclient(catdasp_protocol *proto, int version);
int catdasp_initalltakserver(catdasp_protocol *proto, int version);
int catdasp_initalltaasclient(catdasp_protocol *proto, int version);
int catdasp_initalltaasserver(catdasp_protocol *proto, int version);
int catdasp_handshake(cat_session *sess, catdasp_info *info, int fd_ids);

#ifdef __cplusplus
}
#endif

#endif /* !_cat_dasp_h */
