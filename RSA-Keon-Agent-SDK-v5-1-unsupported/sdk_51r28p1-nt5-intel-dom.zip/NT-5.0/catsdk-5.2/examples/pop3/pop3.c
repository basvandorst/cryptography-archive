/*
 * @(#)$Header: /srcroot/Lego-CVSROOT/catagent/prog/pop3.c,v 1.17 1999/09/24 14:56:31 elias Exp $
 *
 * Copyright (c) 1998 Security Dynamics
 *
 * Description:	Sample POP3-filter.
 *		Makes use of the line filter.
 *
 * MT-Level:    Safe
 */

#include <cat/gen.h>
#include "pop3.h"
#include <ctype.h>

#define DEBUG_MODULE "pop3."

/*
 * Filter private data
 */

struct popdata {
    int lastcmd;		/* State (last seen command) */
    char inuser[256];		/* User (from client) */
    char inpsw[256];		/* Psw (from client) */
    char *mapuser;		/* User from database */
    char *mappass;		/* Password from database */
};


/*
 * The commands we care about, and allow.
 */

#define SRV_GREETWAIT	-2
static char *cmdlist[] = {
#define CMD_UNKNOWN	-1
    "user",
#define CMD_USER	0
    "pass",
#define CMD_PASS	1
    "quit",
#define CMD_QUIT	2
    "capa",
#define CMD_CAPA	3
    NULL
};

static int pop3_init(cat_session *sess, cat_filter *me);
static void pop3_free(cat_session *sess, cat_filter *me);
static int pop3_rw(cat_session *sess, cat_filter *me, int fd_id);
static int appendbuf(cat_buffer *b, ...);
static int cmd_match(cat_session *sess, cat_buffer *b, char **v);


/*
 * cat_pop3filter() --
 *
 *   Initialize a filter that will do secure login of a POP3
 *   connection.  The client is assumed to be on CAT_CLIENT_xFD,
 *   the server on CAT_SERVER_xFD.
 *
 * Arguments:
 *   filter	IN/OUT: Pointer to the filter struct to initialize
 *
 * Returns a pointer to the supplied filter.
 */

cat_filter *
cat_pop3filter(cat_filter *filter)
{
    struct popdata *data;

    memset(filter, 0, sizeof(cat_filter));
    if ((data = malloc(sizeof(*data))) == NULL) {
	return NULL;
    }
    memset(data, 0, sizeof(*data));
    strncpy(filter->name, "pop3", sizeof(filter->name));
    filter->fd_ids = CAT_CLIENT_RFD | CAT_SERVER_RFD;
    filter->rw = pop3_rw;
    filter->free = pop3_free;
    filter->init = pop3_init;
    filter->filterdata = data;
    data->lastcmd = SRV_GREETWAIT;

    return filter;
}


/*
 * Sample pop3 filtering/authentication function.
 *
 *  0. Rewrite server greeting to hide APOP capability
 *  1. Catch "user <username>"
 *  2. Map username using authenticated data
 *     Close connection if this fails.
 *  3. Send mapped username to server
 *  4. Look for "pass <password>"
 *  5. Send mapped password (from [2] above) to server.
 *  6. Check server reply to [5]. If successful, remove
 *     filter from data stream
 *
 * XXX: This function has grown a bit long.  Split it up before
 *      adding more stuff to it.
 */

static int
pop3_rw(cat_session *sess, cat_filter *me, int fd_id)
{
    static const char *F = DEBUG_MODULE "pop3_rw";
    char tmpbuf[256];
    cat_buffer *b;
    struct popdata *data;
    int c, n, ret;

    ret = 0;
    data = me->filterdata;
    b = catbuf_get(sess, fd_id);

    if (fd_id == CAT_CLIENT_RFD) {

	/*
	 * Data from client.
	 *
	 * Parse commands.  The only ones we are interested in are
	 * "user" and "pass".  The "apop" cmd requires looking at
	 * the server greeting string, and to create an MD5 hash.
	 * Left as excercise for the reader...
	 */

	data->lastcmd = cmd_match(sess, b, cmdlist);
	switch (data->lastcmd) {
	  case CMD_USER:

	    /*
	     * Found "user..."
	     * The username is delimited by whitespace.
	     *
	     * Use this to map into the user to login as. 
	     */

	    n = 0;
	    while ((c = catbuf_ch(b)) != -1 && !isspace(c)) {
		data->inuser[n++] = c;
		if (n == sizeof(data->inuser)-1) {
		    CAT_DEBUG1((sess, F, "USER name too long"));
		    break;
		}
	    }
	    data->inuser[n] = 0;
	    CAT_DEBUG3((sess, F, "USER %s", data->inuser));


	    /*
	     * Authenticate user.
	     */

	    ret = catgen_checkauth(sess, data->inuser, NULL, NULL);
	    if (ret != 0) {
		return ret;
	    }


	    /*
	     * Get mapped authentication information.
	     * User must already have been authenticated.
	     */

	    ret = catgen_dbmap(sess, data->inuser, NULL, NULL,
			       &data->mapuser, &data->mappass, NULL);

	    if (ret != 0) {

		/*
		 * Mapping failed.  Send an error message to client
		 * and close connection by returning an error.
		 */
		
		catgen_log(sess, CATLOG_MAPFAIL);
		CAT_DEBUG2((sess, F,
			    "USER mapping failed for %s", data->inuser));
		catbuf_delete(b, 0, -1);
		appendbuf(b, "-ERR permission denied\r\n", NULL);
		cat_send(sess, CAT_CLIENT_WFD, b);
		b = NULL;
		ret = CAT_EACCES;
	    } else {
		
		/*
		 * Fill in the new username to send to server.
		 */

		catbuf_delete(b, 0, -1);
		appendbuf(b, "USER ", data->mapuser, "\r\n", NULL);
		CAT_DEBUG1((sess, F, "USER %s to server", data->mapuser));
	    }
	    break;
	    
	  case CMD_PASS:
	    
	    /*
	     * Found "pass ..."
	     * Scrap it and fill in the mapped password.
	     */
	    
	    if (data->mappass == NULL || data->mappass[0] == '\0') {
		/*
		 * The Application mapping didn't return a passsword.
		 * Try to map the client supplied passsword.
		 */
		n = 0;
		while ((c = catbuf_ch(b)) != -1 && !isspace(c)) {
		    data->inpsw[n++] = c;
		    if (n == sizeof(data->inpsw)-1) {
			CAT_DEBUG1((sess, F, "PASSword too long"));
			break;
		    }
		}
		if (data->mappass != NULL) {
		    free(data->mappass);
		}
		data->inpsw[n] = 0;
		CAT_DEBUG3((sess, F, "PSW len:%d", strlen(data->inpsw)));

		ret = catgen_dbmap(sess, data->inuser, data->inpsw, NULL,
				   NULL, &data->mappass, NULL);
		if (ret != 0) {
		    catgen_log(sess, CATLOG_MAPFAIL);
		    return ret;
		}
	    }
	    catgen_log(sess, CATLOG_AUTHUSEROK);

	    catbuf_delete(b, 0, -1);
	    appendbuf(b, "PASS ", data->mappass, "\r\n", NULL);
	    CAT_DEBUG3((sess, F, "PASS -> map & send to server"));
	    
	    /*
	     * Next, we want to look for the server reply.
	     */
	    
	    me->fd_ids |= CAT_SERVER_RFD;
	    break;
	    
	  case CMD_QUIT:
	    break;

	  case CMD_CAPA:
	    /* Add capabilty filtering here... */

	  default:

	    /*
	     * Not supported. Sorry.
	     */
	    
	    CAT_DEBUG2((sess, F, "%s attempted",
			data->lastcmd < 0 ? "<unsup>"
			: cmdlist[data->lastcmd]));
	    n = catbuf_extract(b, catbuf_pos(b), sizeof(tmpbuf)-1, tmpbuf);
	    tmpbuf[n] = 0;
	    for (n = 0; tmpbuf[n] != 0 && !isspace(tmpbuf[n]); n++)
		;
	    tmpbuf[n] = 0;
	    catbuf_delete(b, 0, -1);
	    appendbuf(b, "-ERR unknown command: \"", tmpbuf, "\"\r\n", NULL);
	    cat_send(sess, CAT_CLIENT_WFD, b);
	    b = NULL;
	    break;
	}
    } else {

	/*
	 * Data from server.  We are only interested in the
	 * server greeting, or the result of a password command.
	 */
	
	switch (data->lastcmd) {
	  case SRV_GREETWAIT:

	    /*
	     * Look for "<[^>]*>", and remove it.  It signals server
	     * APOP capability to the client.  By removing it we don't
	     * have to deal with APOP.
	     */

	    if ((n = catbuf_scan(b, "<", 1)) > -1) {
		catbuf_index(b, n);
		if ((n = catbuf_scan(b, ">", 1)) > -1) {
		    CAT_DEBUG3((sess, F, "server greeting modified"));
		    catbuf_delete(b, catbuf_pos(b), n+1);
		}
	    }
	    break;

	  case CMD_PASS:

	    /*
	     * If the reply indicates a success, we are now logged in
	     * and can pop this filter from the data stream.
	     *
	     * POP3 does not support re-authentication.
	     */

	    n = sizeof("+OK")-1;
	    if (catbuf_match(b, "+OK", n) == n) {
		ret = CAT_POP_FILTER;
		CAT_DEBUG3((sess, F, "password ok - requesting to be popped"));
	    } else {
		catgen_log(sess, CATLOG_SERVAUTHFAIL);
		CAT_DEBUG3((sess, F, "Server reply to PASS != +OK"));

		/*
		 * Close connection after sending this reply to client.
		 */

		ret = CAT_EOF;
	    }
	    break;

	  default:

	    /*
	     * What on earth happened here?  If it is repeatable,
	     * push a debug filter to peek on the traffic, then fix
	     * the problem.
	     *
	     * It might be a client sending commands before receiving
	     * a reply to the previous one.  M$ something, perhaps?
	     */

	    CAT_DEBUG1((sess, F, "This should not happen."));
	    break;
	}

	/*
	 * Now we do not care what the server says.
	 * This bit is set at initialization, and whenever a PASS
	 * command is intercepted.
	 */

	me->fd_ids &= ~CAT_SERVER_RFD;
    }


    /*
     * Return buffer to the data stream, if it still non-null.
     */

    if (b != NULL) {
	catbuf_put(sess, fd_id, b);
    }

    return ret;
}


/*
 * Called when the filter is pushed.  Push a line filter below this
 * one, so the pop3-filter will only have to deal with one line
 * at a time from the client.  A bit slow, but the data stream from
 * client consists of one-line commands only.  Don't do this for
 * the server side (assume the server is capable of sending a whole
 * line at a time), as more traffic will be generated from that end.
 * Of course, normally all filters are removed before any serious
 * traffic starts.
 */

static int
pop3_init(cat_session *sess, cat_filter *me)
{
    cat_filter f;
    int r;

    r = cat_pushfilter(sess, cat_linefilter(CAT_CLIENT_RFD, &f));

    return (r < 0) ? r : 0;
}


/*
 * Called when the filter is popped.
 * Deallocate the private data of the filer, and pop the line filter.
 */

static void
pop3_free(cat_session *sess, cat_filter *me)
{
    struct popdata *data;

    if ((data = me->filterdata) != NULL) {
	if (data->mapuser != NULL) {
	    free(data->mapuser);
	}
	if (data->mappass != NULL) {
	    free(data->mappass);
	}
	free(data);
    }
    cat_popfilter(sess);
}


/*
 * Scan forward in buffer, and see if the next whitespace-delimited token
 * matches any of the strings in "v".  Matching is case-insensitive.
 *
 * NOTE: For verbatim searching and matching, the functions
 *	 catbuf_scan() and catbuf_match() can be used, but
 *       the POP3 protocol is case-insensitive.
 *
 * If a match is found, return its index and leave the buffer index at
 * the next non-whitespace character (or at the end of the buffer).
 *
 * If no matches are found, return -1 and leave the buffer index
 * where the search started.
 */

static int
cmd_match(cat_session *sess, cat_buffer *b, char **v)
{
    static const char *F = DEBUG_MODULE "cmd_match";
    int match, c, pos;
    char *s;

    pos = catbuf_pos(b);
    for (match = 0; (s = *v) != NULL; match++, v++) {
	catbuf_index(b, pos);
	while ((c = catbuf_ch(b)) != -1 && isspace(c))
	    ;
	while (*s && c != -1 && toupper(*s) == toupper(c)) {
	    s++;
	    c = catbuf_ch(b);
	}
	if (*s == 0 && isspace(c)) {
	    while (isspace(c)) {
		c = catbuf_ch(b);
	    }
	    catbuf_index(b, catbuf_pos(b)-1);

	    CAT_DEBUG3((sess, F, "found %s", *v));
	    return match;
	}
    }
    catbuf_index(b, pos);

    return -1;
}


/*
 * Append a variable number of strings to a buffer.
 */

static int
appendbuf(cat_buffer *b, ...)
{
    char *s;
    va_list ap;
    int pos, len;

    pos = catbuf_pos(b);
    va_start(ap, b);
    while ((s = va_arg(ap, char *)) != NULL) {
	len = strlen(s);
	catbuf_insert(b, pos, len, s);
	pos += len;
    }
    va_end(ap);

    return pos;
}
