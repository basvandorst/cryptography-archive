----------------------------------------------------------------------
                  POP3 Example Agent
----------------------------------------------------------------------

This Agent is an example of how to secure the Post Office Protocol v 3 
using the Keon Agent SDK.

The operation of the POP3 Agent is as follows:

1. This Agent does not handle APOP and therefore rewrites the server
   greeting to hide APOP capability.
2. Intercept 'USER <username>' sent from the client.
3. Map the username using authenticated data. This involves 
   requesting the Bridge protocol to perform a lookup in the PAC. 
   If the lookup fails, close the  connection and send a log message.
4. Send the mapped username to the server
5. Look for 'PASS <password>' sent from the client.
6. Send the mapped password (from [3] above) to the server.
7. Check the server reply from [6]. If successful, remove the
   filter from the data stream and log a success message.



Agent Design
------------

This Agent has been built using the catgen layer. The Agent has 
two filters with the following functionality (from top to bottom of 
the filter stack):

o A POP3 protocol filter that perform steps 2 to 7 in the preceding 
  list.
o A line filter that assembles complete lines from the client and
  passes them to the POP3 filter.



Build and Setup
---------------

See the examples/README.txt for instructions on how to build and 
create distributions, and install Agents.



Contents
--------

This directory contains the following files:

popagent.c		- The main() for the Agent, together with calls to 
			  install the POP3 filter and place the
			  Agent in server mode.
pop3.h		
pop3.c			- The filter for POP3. This filter intercepts
			  the supplied username (USER) and password
			  (PASS) in the POP3 protocol and substitutes
			  them according to information in the client's
			  PAC.

line.c			- A line filter that supplies the filters
			  above it in the filter stack with complete
			  lines.

Makefile.pp		- A file that produces a makefile after 
			  processing with ppmk. The makefile is used
			  to build and package the Agent.

Makefile		- The files is created by the installation 
			  framework at install time. The name may
			  differ on different platforms.

pop3_sample.cfg		- A configuration file template for the Agent,
			  which supplies some default values for the
			  configuration program.

			  For this example, the file contains values that 
			  are relevant only on UNIX, so the file is used only
			  on UNIX.

pop3_sample.gap
pop3_sample.properties	- Agent definition and translation files for
			  the Agent, to be imported into the 
			  Keon Security Server 5.0.

dist.pp			- A packing description file, used both when
			  creating the distribution and when
			  installing the Agent.

pop3.pp			- A file containing pp symbols that is used when
			  building the agent.
