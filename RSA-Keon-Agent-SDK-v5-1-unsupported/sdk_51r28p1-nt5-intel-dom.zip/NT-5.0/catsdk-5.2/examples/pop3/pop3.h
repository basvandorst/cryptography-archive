/*
 * @(#)$Id: pop3.h,v 1.2 1999/09/08 16:02:36 mikko Exp $
 *
 * Copyright � 1998 Security Dynamics
 *
 * Description:
 *
 *	Setup functions for POP3 and line filters.
 *	Requires <cat/cat.h>
 */

#ifndef _cat_pop3_h
# define _cat_pop3_h

#ifdef __cplusplus
extern "C" {
#endif

cat_filter *cat_pop3filter(cat_filter *filter);
cat_filter *cat_linefilter(int fd_ids, cat_filter *filter);

#ifdef __cplusplus
}
#endif

#endif /* !_cat_pop3_h */
