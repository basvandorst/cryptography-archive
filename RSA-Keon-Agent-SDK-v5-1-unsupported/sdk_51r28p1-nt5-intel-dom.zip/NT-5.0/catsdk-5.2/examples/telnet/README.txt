----------------------------------------------------------------------
                  telnet Example Agent
----------------------------------------------------------------------

This Agent is an example of how to secure and add SSO login via telnet.

The operation of the telnet Agent is as follows:

1. Simple SSO. In this case, no role mapping is performed. Also, the 
   user is logged in with the first matching credentials from the 
   PAC (or from the Bridge).

2. Rolemap mode. This requires the telnet client to send a username
   and password to the telnet server. The user is logged in with
   the credentials that match the role name in the PAC (or from the
   Bridge).

The SSO or rolemap mode is toggled by the 'rolemap' configuration
parameter in telnet_sample-5.0.cfg.

The Agent scans the data sent between the client and the server, 
looking for login strings, and sends the appropriate reply. The 
strings used for matching are configurable in the configuration 
file (telnet_sample_5.0.cfg).

The SSO message flow is approximately as follows:

1. The client connects to the server
2. The server replies with a message, for example, 'SunOS 5.6', and 
   issues a prompt for login, for example, 'login'.
   The Agent recognizes this prompt and removes it from the data
   stream.
3. The Agent retrieves the user credentials (PAC or Bridge) and sends
   the mapped login name (if any) back to the server.
4. The server responds with a password prompt, for example, 
   'Password: ', which the Agent records.
5. The Agent replies with the mapped password.
6. If the login was successful, the server responds with a greeting
   string, such as 'Last login: ...'. If the login was not
   successful, the server replies with an error message, for example,
   'Login incorrect.
7. The Agent examines the outcome of the login procedure and
   if the procedure was successful, all filters are popped and the 
   connection remains open. Otherwise, the Agent sends an error 
   message to the client and closes the connection.
   
The rolemap message flow is as follows:

1. As for step [1] in the preceding list.
2. As for step [2] in the preceding list, but the prompt is forwarded 
   to the client.
3. The client types the role name at the prompt and the message is 
   sent to the server. Some clients can automate this.
4. The Agent intercepts the role name sent and performs an 
   authorization check and user mapping based on the role name (PAC or
   Bridge). The role name supplied by the client is removed from the 
   data stream and the mapped role name is inserted.
5. The server replies with the password prompt, which is sent via the
   Agent to the client.
6. The client or the automated client program sends the password
   to the server.
7. The Agent intercepts the password, removes it from the data stream
   and inserts the mapped password.
8. As for step [7]. in the preceding list.
   
Provisions have been made to allow/disallow/handle different telnet 
options. The Agent can
o refuse negotiation of the option for any side (client/server); this 
  is currently used in SSO mode to refuse client echo
o add a callback to handle or examine a specific option



Agent Design
------------

This Agent has been built using the catgen layer. The Agent has three 
filters, which have the following functionality (from top to bottom 
of the filter stack):

o Telnet login filter. This filter receives either telnet
  commands/options or login data. Depending on the configuration, it 
  either performs role mapping or SSO of the user. In this filter,
  the Agent can also examine individual telnet commands/options and 
  take appropriate action (such as denying certain options or printing 
  telnet option negotiation trace information).

o Line filter. This is a slightly modified version of the line filter
  in the POP3 example, which delivers one line at a time. 
  The main difference with this version is that it is mounted only on 
  CAT_CLIENT_RFD and that it examines any data received to see if that 
  data is a telnet command. If so, the filter just passes on the 
  command. A 'line' is considered to be any information terminated by 
  NL (ASCII 0x0a), CRNL or CR (0x0d). This is because different
  clients handle line termination in different ways.

o Telnet line filer. This filter assembles complete telnet commands
  and sends them one at a time.  



Build and Setup
---------------

See the examples/README.txt for instructions to on how to build and 
create distributions, and install Agents.



Tested Configurations
---------------------

Telnet servers:

Sun Solaris 2.6 native telnet server

Telnet clients:

Windows NT 4.0 native telnet client
Van Dyke Technologies, Inc. SecureCRT v. 2.3.2



Contents
--------

This directory contains the following files:

telnetagent.c		- The main() for the Agent, together with
			  calls to install the telnet filter and place 
			  the Agent in server mode.

telnet.h		
telnet.c		- The filter for login over telnet. 
			  This filter can work in role mapping
			  mode or simple SSO mode (see above for
			  details)

telnetline.c		- A filter that supplies the filters
			  above it with complete telnet commands (one
			  at a time) or any non-telnet data (usually
			  user data) sent by the telnet client.

line.c                  - A slightly modified version of the POP3 line
			  filter.

telnet_sample.cfg	- A configuration file template for the Agent,
			  which supplies some default values for the
			  configuration program.

port.cfg		- A port configuration template file. Contains
			  definitions for agent specific parameters.

custom.tcl		- A tcl script that calls tcl procedures
			  that allow you to insert Agent specific
			  configuration prompts into the configuration 
			  program.

telnet_sample.gap
telnet_sample.properties- A Agent definition and translation files for
			  the Agent, to be imported into the 
			  Keon Security Server 5.0.

Makefile.pp		- A file that produces a makefile after 
			  processing with ppmk. The makefile is used
			  to build and package the Agent.

Makefile		- Created by the installation framework at install
			  time. The filename may differ some on depending
			  on platform.

dist.pp			- A packing description file, used both when
			  creating the distribution and when
			  installing the Agent.

telnet.pp		- An Agent-specific symbol definition file.

