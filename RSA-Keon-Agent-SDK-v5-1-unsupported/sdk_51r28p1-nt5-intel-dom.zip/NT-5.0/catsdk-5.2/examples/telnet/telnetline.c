/*
 * @(#)$Header: /srcroot/Lego-CVSROOT/catagent/example_telnet/telnetline.c,v 1.6 2000/02/29 14:46:42 elias Exp $
 *
 * Copyright (c) 1998 Security Dynamics
 *
 * Description:	Telnet buffering filter.  If pushed on a read descriptor,
 *		it ensures that the filters above it will get exactly one
 *		telnet command per call. 
 *              
 *
 *
 * MT-Level:    Safe
 */

#include <cat/cat.h>
#include "telnet.h"

#define DEBUG_MODULE "telnetline."

struct filterdata {
    cat_buffer *keep;
};

static void telnetline_free(cat_session *sess, cat_filter *me);
static int telnetline_rw(cat_session *sess, cat_filter *me, int fd_id);
static int telnetline_len(cat_buffer *b);

/*
 * cat_telnetline() --
 *
 *   Initialize a filter that will split data into telnet
 *   options/commands or application data.
 *
 * Arguments:
 *   filter	IN/OUT: Pointer to the filter struct to initialize
 *
 * Returns a pointer to the supplied filter.
 */

cat_filter *
cat_telnetline(cat_filter *filter)
{
    struct filterdata *data;

    memset(filter, 0, sizeof(cat_filter));
    if ((data = malloc(sizeof(struct filterdata))) == NULL) {
	return NULL;
    }
    data->keep = NULL;

    strncpy(filter->name, "telnetline", sizeof(filter->name));
    filter->fd_ids = (CAT_CLIENT_RFD | CAT_SERVER_RFD);
    filter->rw = telnetline_rw;
    filter->free = telnetline_free;
    filter->filterdata = data;

    return filter;
}


/*
 * Filtering function.
 */

static int
telnetline_rw(cat_session *sess, cat_filter *me, int fd_id)
{
    static const char *F = DEBUG_MODULE "telnetline_rw";
    int idx = 0;
    int optlen;
    unsigned char iac[] = { TELNET_IAC };
    cat_buffer *b;
    struct filterdata *data;

    b = catbuf_get(sess, fd_id);
    data = me->filterdata;
    if (data->keep != NULL) {
	b = catbuf_join(data->keep, b);
	data->keep = NULL;
    } 
    
    catbuf_index(b, 0);

    idx = catbuf_scan(b, iac, 1);
    catbuf_index(b, idx);
    if (idx == 0) {
	/*
	 * Hook off the first telnet option and pass it along
	 */
	optlen = telnetline_len(b);
	if (optlen < 0) {
	    /*
	     * If CAT_ENOTFOUND; Unterminated telnet sub neg, more to come...
	     */
	    if (optlen == CAT_ENOTFOUND) {
		data->keep = b;
		b = NULL;
		goto done;
	    }
	    CAT_DEBUG1((sess, F, "Unknown telnet command, passing it on..."));
	    goto done;
	}
	if (optlen == 1 || optlen > catbuf_len(b)) {
	    /*
	     * If length of option is larger than buffer or we got a single IAC
	     * there must be more to come.
	     */
	    data->keep = b;
	    b = NULL;
	    goto done;
	}
	/*
	 * Got a complete telnet packet.
	 */
	CAT_DEBUG5((sess, F, "TELNET option of length %d found", optlen));
	data->keep = catbuf_split(b, optlen);
	if (catbuf_len(data->keep) == 0) {
	    catbuf_free(data->keep);
	    data->keep = NULL;
	}
	goto done;
    }
    if (idx > 0) {
	/*
	 * Hook off first and pass it. It is not telnet data but
	 * there is telnet data further in the buffer.
	 */
	data->keep = catbuf_split(b, idx);
	goto done;
    }
    if (idx == -1) {
	/*
	 * This is not telnet data. Pass whole buffer.
	 */
	goto done;
    }

  done:

    if (b != NULL) {
	catbuf_put(sess, fd_id, b);
    }

    if (data->keep != NULL) {
	if (catbuf_len(data->keep) == 0) {
	    catbuf_free(data->keep);
	    data->keep = NULL;
	} 
    }
	
    return (data->keep != NULL) ? CAT_MORE_DATA : CAT_OK;
}


/*
 * Free anything in this filter when it is popped
 */

static void
telnetline_free(cat_session *sess, cat_filter *me)
{
    struct filterdata *data;

    if ((data = me->filterdata) != NULL) {
	if (data->keep != NULL) {
	    catbuf_free(data->keep);
	}
	free(data);
    }
}


/*
 * Function to determine the length of a telnet option.
 * Modifies buffer index.
 *
 * Returns the length in bytes of the telnet option to which the 
 * buffer index is pointing to, or a negative code on error.
 *
 * Return values:
 * 1             : A single IAC. This probably means that we got a split
 *                 telnet command.
 * > 0           : OK
 * CAT_ENOTFOUND : An non-terminated sub-negotiation found
 * CAT_EINVAL    : The buffer index is not pointing on a telnet IAC byte
 * CAT_EFTYPE    : Cannot determine length
 */

static int
telnetline_len(cat_buffer *b)
{
    static const char *F = DEBUG_MODULE "telnetline_len";
    int ch;
    int ret;
    unsigned char se[] = { TELNET_SE };
    
    if ((ch = catbuf_ch(b)) != TELNET_IAC) {
	return CAT_EINVAL;
    }
    ch = catbuf_ch(b);

    if (ch == TELNET_SB) {
	/*
	 * Sub negotiation. This can have arbitrary length.
	 */
	if ((ret = catbuf_scan(b, se, 1)) < 0) {
	    CAT_DEBUG5((NULL, F, "No end of telnet sub neg. in current buffer"));
	    return CAT_ENOTFOUND;
	}
	return (ret + 3);
    }
    if (ch == TELNET_DO || ch == TELNET_DONT || 
	ch == TELNET_WILL || ch == TELNET_WONT) {
	/*
	 * Standard options negotiation is three characters;
	 * <IAC><CMD><OPTION>
	 */
	return 3;
    }
    if (ch >= TELNET_GA && ch <= TELNET_NOP) {
	/*
	 * <IAC><CMD>
	 */
	return 2;
    }
    if (ch == -1) {
	/*
	 * The buffer only contained IAC. Probably a split telnet command.
	 */
	return 1;
    }
    /*
     * Data preceded by IAC that we can't figure out what it is...
     */
    return CAT_EFTYPE;
}
