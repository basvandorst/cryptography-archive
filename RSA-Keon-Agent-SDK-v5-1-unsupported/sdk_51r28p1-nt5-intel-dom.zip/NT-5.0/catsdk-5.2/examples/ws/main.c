/*
 * @(#)$Header: /srcroot/Lego-CVSROOT/catagent/example_ws/main.c,v 1.8 2000/01/25 09:24:47 perre Exp $
 *
 * Copyright (c) 2000 RSA Security
 *
 * Description:	Example to show how to use the Keon Agent SDK to implement
 *              native Keon support in an application.
 *              
 *            
 */

#include "ws.h"
#if USE_CAT
#include "wscat.h"
#endif

int debuglvl = 0;

#ifdef USE_CAT
int
send_reply(cat_session *sess, char *header, int headerlen, char *body, int bodylen);
#else
int
send_reply(WS_SOCK connfd, char *header, int headerlen, char *body, int bodylen);
#endif

void
usage(char *name)
{
    fprintf(stderr, "%s [-p port] [-v]\n", name);
    fprintf(stderr, "\t-p port  Set server port number. Default is %d.\n", DEFPORT);
    fprintf(stderr, "\t-v       Enable trace output\n");

    return;
}


/*
 * Main
 */
int
main(int argc, char **argv)
{
#ifdef USE_CAT
    cat_session *sess;
#endif
    WS_SOCK listenfd, connfd;   
    int     ret, n;
    char    reqhdr[HDRBUFLEN];
    int     hbuflen;
    char    replyhdr[HDRBUFLEN];
    int     replyhdrlen;
    char   *body;
    int     bodylen;
    int     clilen;
    struct sockaddr_in cliaddr, servaddr;
    char   *s, **var;
    char   *portstr;
    int	    port;

    ret = 0;
    port = DEFPORT;
    portstr = NULL;

    /*
     * Portable argument parsing
     */
    for (n = 1; n < argc; n++) {
	if (*(s = argv[n]) != '-' || !*++s || (*s == '-' && ++n)) {
	    break;
	}
	for (var = NULL; var == NULL && *s; s++) {
	    switch (*s) {
	      case 'v': debuglvl++; break;
	      case 'p': var = &portstr; goto arg;
	      arg: {
		  if ((*var = *++s ? s : argv[++n]) != NULL) {
		      break;
		  }
	      }
	      default:
		usage(argv[0]);
		exit(2);
	    }
	}
    }
    if (portstr) {
	if ((port = atoi(portstr)) == 0) {
	    usage(argv[0]);
	    exit(2);
	}
    }
    
#ifdef USE_CAT
    /*
     * Initialize the library, point out the configuration file
     * and open the Virtual Card.
     * It is quite expensive to open the VC, so we do it here
     * and pass the handle to the open VC to any sessions subsequently
     * created.
     */
    if (cat_init(NULL) < 0) {
	WSERROR(("cat_init() failed\n"));
    }
    if (catinfo_init(0) < 0) {
	WSERROR(("catinfo_init() failed\n"));
    }
    if ((ret = catinfo_loadfrom(".wsconfig", CONFIGFILE, CATINFO_FILE)) < 0) {
	WSERROR(("catinfo_loadfrom() failed with: %s\n", caterr_str(ret)));
    }
    if (init_global() < 0) {
	WSERROR(("Failed to initialize.\n"));
    }
#endif

#ifdef WIN32
    {
	WSADATA wsa;
	WORD required_version;
	
	required_version = MAKEWORD( 2, 0 );
	if (WSAStartup(MAKEWORD(2, 0), &wsa) != 0) {
	    WSERROR(("Wrong winsock version \n"));
	}
    }
#endif
    
    listenfd = socket(AF_INET, SOCK_STREAM, 0);
    if (listenfd == BAD_SOCKET) {
	WSERROR(("socket() failed\n"));
    }
      
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons((u_short)port);
      
    ret = bind(listenfd, (struct sockaddr *)&servaddr, sizeof(servaddr));
    if (ret == SOCKERR) {
	WSERROR(("bind() failed\n"));
    }
      
    ret = listen(listenfd, LISTENQ);
    if (ret == SOCKERR) {
	WSERROR(("listen() failed\n"));
    }

    while(1) {
	clilen = sizeof(cliaddr);
	connfd = accept(listenfd, (struct sockaddr *)&cliaddr, &clilen);
	if (connfd == BAD_SOCKET) {
	    DEBUG(("accept() failed\n"));
	    continue;
	}
	hbuflen = HDRBUFLEN;
	body = NULL;
#ifdef USE_CAT
	/*
	 * Create a new session and insert the connected socket 
	 * in it.
	 * At this point we also perform the ssl-handshake with
	 * the client.
	 */
	if ((sess = create_session(connfd)) == NULL) {
	    Close(connfd);
	    continue;
	}
	if (init_sess(sess) < 0) {
	    DEBUG(("Failed to initialize session.\n"));
	    goto done;
	}
	DEBUG(("Session successfully initialized.\n"));
	ret = cat_poll(sess, CAT_CLIENT_RFD, 2000);
	if (ret <= 0) {
	    if (ret < 0) {
		DEBUG(("cat_poll() failed with %s\n", caterr_str(ret)));
	    } else {
		DEBUG(("No data present\n"));
	    }
	    cat_close(sess);
	    continue;
	}
	ret = read_request(sess, reqhdr, &hbuflen);
#else
	ret = read_request(connfd, reqhdr, &hbuflen);
#endif
	if (ret < 0) {
	    goto done;
	}
	replyhdrlen = HDRBUFLEN;
#ifdef USE_CAT
	ret = generate_reply(sess, reqhdr, replyhdr, &replyhdrlen, 
			     &body, &bodylen);
#else
	ret = generate_reply(NULL, reqhdr, replyhdr, &replyhdrlen, 
			     &body, &bodylen);
#endif
	if (ret < 0) {
	    goto done;
	}
#ifdef USE_CAT
	send_reply(sess, replyhdr, strlen(replyhdr), body, bodylen);
#else
	send_reply(connfd, replyhdr, strlen(replyhdr), body, bodylen);
#endif
	if (body) {
	    free(body);
	}
      done:
#ifdef USE_CAT
	cat_close(sess);
#else
	Close(connfd);
#endif
    }
}



#ifdef USE_CAT
/*
 * send_reply()
 * 
 * Descripiton:
 *    Send an http reply.
 *
 * Arguments:
 *    sess      IN: The session
 *    header    IN: Header to be sent
 *    headerlen IN: Length of header
 *    body      IN: Body to be sent. If NULL, no body is sent.
 *    bodylen   IN: Length of body
 *
 * Returns:
 *    Returns 0 if successful, negative code otherwise
 */
int
send_reply(cat_session *sess, char *header, int headerlen, char *body, int bodylen) 
{
    int ret;
    cat_buffer *buf;

    DEBUG(("Reply has header (len = %d):\n%s\n", headerlen, header));
    buf = catbuf_new(sess, 0, NULL);	
    catbuf_insert(buf, 0, headerlen, header);
    ret = cat_send(sess, CAT_CLIENT_WFD, buf);
    if (ret == 0) {
	if (body) {
	    DEBUG(("Body len = %d\n", bodylen));
	    buf = catbuf_new(sess, 0, NULL);
	    catbuf_insert(buf, 0, bodylen, body);
	    ret = cat_send(sess, CAT_CLIENT_WFD, buf);
	}
    }
    return ret;
}
#else
/*
 * send_reply()
 * 
 * Descripiton:
 *    Send an http reply.
 *
 * Arguments:
 *    connfd    IN: A connected socket.
 *    header    IN: Header to be sent
 *    headerlen IN: Length of header
 *    body      IN: Body to be sent. If NULL, no body is sent.
 *    bodylen   IN: Length of body
 *
 * Returns:
 *    Returns 0 if successful, negative code otherwise
 */
int
send_reply(WS_SOCK connfd, char *header, int headerlen, char *body, int bodylen) 
{
    DEBUG(("Reply has header (len = %d):\n%s\n", headerlen, header));
    send(connfd, header, headerlen, 0);
    if (body) {
	DEBUG(("Body len = %d\n", bodylen));
	send(connfd, body, bodylen, 0);
    }
    return 0;    
}

#endif
