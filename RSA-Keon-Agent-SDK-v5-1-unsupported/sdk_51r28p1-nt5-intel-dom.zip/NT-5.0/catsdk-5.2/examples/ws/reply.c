/*
 * @(#)$Header: /srcroot/Lego-CVSROOT/catagent/example_ws/reply.c,v 1.7 2000/01/26 09:28:59 elias Exp $
 *
 * Copyright (c) 2000 RSA Security
 *
 * Description:	Functions to generate an HTTP reply.
 *              
 *            
 */

#ifdef USE_CAT
#include "wscat.h"
#else
#include "ws.h"
#endif

/*
 * HTTP 1.0 reply status. Not all of these are actually used.
 */
static char *reply[] = {
    "HTTP/1.0 200 OK\r\n",
#define R200 0
    "HTTP/1.0 201 Created\r\n",
#define R201 1,
    "HTTP/1.0 202 Accepted\r\n",
#define R202 2
    "HTTP/1.0 204 No Content\r\n",
#define R204 3
    "HTTP/1.0 301 Moved Permamently\r\n",
#define R301 4
    "HTTP/1.0 302 Moved Temporarily\r\n",
#define R302 5
    "HTTP/1.0 304 Not Modified\r\n",
#define R304 6
    "HTTP/1.0 400 Bad Request\r\n",
#define R400 7
    "HTTP/1.0 401 Unauthorized\r\n",
#define R401 8
    "HTTP/1.0 403 Forbidden\r\n",
#define R403 9
    "HTTP/1.0 404 Not Found\r\n",
#define R404 10
    "HTTP/1.0 500 Internal Server Error\r\n",
#define R500 11
    "HTTP/1.0 501 Not Implemented\r\n",
#define R501 12
    "HTTP/1.0 502 Bad Gateway\r\n",
#define R502 13
    "HTTP/1.0 503 Service Unavaliable\r\n",
#define R503 14
    NULL
};



/*
 * generate_reply()
 *
 * Description:
 *    Generate a complete HTTP 1.0 reply given a request.
 *
 * Arguments:
 *    data      IN: Arbitrary data.
 *    request   IN: The request buffer as a string (0-terminated)
 *    header   OUT: buffer to store reply in, allocated by caller
 *    hlen  IN/OUT: Value/result pointer. Should contain size of 
 *                  header buffer on entry. Contains the size
 *                  of the actual header on exit
 *    body     OUT: The body of the reply if any. The body is
 *                  allocated and must be freed by caller.
 *    bodylen  OUT: the size of the body 
 *
 * Returns:
 *   Returns 0 is successful or a negative code on error.
 *
 * NOTE: 
 *   This function only returns an error when no reply at all can be 
 *   generated. If a requested page is not found (or similar) an HTTP
 *   error reply is created.
 */
int
generate_reply(void *data, char *request, char *header, int *hlen, 
	       char **body, int *bodylen)
{
    int nchars;
    char *repstatus, *repheader, *repbody;
    char *meth, *uri, *ver, *reqheader;
    char realmbuf[1024];
    char filepath[1024];
    char *mediatype;
    char *credentials, *user, *passwd;
    int  is_prot;
    int ret;
    int offset;
#ifdef USE_CAT
    cat_session *sess;
    char *logid = NULL;
    char *mapuser;
    char *mappass;

    sess = data;
#endif
      
    if (request == NULL || header == NULL || hlen == NULL || 
	body == NULL || bodylen == NULL)
    {
	return WS_EINVAL;
    }
        
    repstatus = NULL;
    repheader = NULL;
    repbody   = NULL;
    offset = 0;

    /*
     * We only recognize the GET Method
     */
    if ((ret = parse_req(request, &meth, &uri, &ver, &reqheader)) < 0) {
	offset = Snprintf(header, *hlen, "%s", reply[R400]);
	DEBUG(("parse_req() failed\n"));
	goto done;
    }
    switch(ret) {
      case GET:
	break;
      case HEAD:
      case POST:
	DEBUG(("Client requested unsupported method: \"%s\"", meth));
	nchars = Snprintf(header, *hlen, "%s", reply[R501]);
	offset += nchars;
	goto done;
      default:
	DEBUG(("Bad method in request.\n"));
	offset = Snprintf(header, *hlen, "%s", reply[R500]);
	goto done;
    }
    DEBUG(("Request OK. Replying to \"%s\", \"%s\", \"%s\"\n", meth, uri, ver));
    if (uri_to_file(uri, filepath, sizeof(filepath)) != 0) {
	offset = Snprintf(header, *hlen, "%s", reply[R400]);
	DEBUG(("uri_to_file() failed\n"));
	goto done; 
    }
    is_prot = is_protected(filepath, realmbuf, sizeof(realmbuf));
    if (is_prot < 0) {
	offset = Snprintf(header, *hlen, "%s", reply[R500]);
	DEBUG(("is_protected() failed\n"));
	goto done;
    }
    if (is_prot) {
	if (has_auth(reqheader, &credentials)) {
	    if (get_login_data(credentials, &user, &passwd) != 0) {
		DEBUG(("Could not get user login credentials"));
		offset = Snprintf(header, *hlen, "%s", reply[R400]);
		goto done;
	    }	    
#ifdef USE_CAT
	    /*
	     * Check authorization and map credentials unless
	     * configured to accept peer certificates that are
	     * not PACs. If non-PAC certificates are accepted,
	     * the credentials entered by the user will be used
	     * for login.
	     */
	    if (Info->require_pac) {
		DEBUG(("%s, %s, %s\n", APPSERVNAME, Info->method, user));
		fflush(stdout);
		if (earauth(sess, APPSERVNAME, Info->method, user, passwd,
			    &logid, &mapuser, &mappass) != 0) {
		    DEBUG(("User authentication failed\n"));
		    offset = Snprintf(header, *hlen, "%s", reply[R403]);
		    goto done;
		}
		DEBUG(("Got credentials user=%s, passwd=%s for %s\n", 
		       mapuser, mappass, logid));
		catlog_set(sess, CATLOG_LOGINNAME, logid);
		free(logid);
		free(user);
		free(passwd);
		user = mapuser;
		passwd = mappass;
	    }
#else
	    DEBUG(("Got login: \"%s\", password: \"%s\"\n", user, passwd));
#endif
	    /*
	     * Validate login here. Send error or continue to fetch file.
	     */
	    if (validate_login(realmbuf, filepath, user, passwd) != 0) {
		DEBUG(("validate_login() failed\n"));
#ifdef USE_CAT
		catlog_vevent(sess, wsloglbls[WS_SERVAUTHFAIL], 
			      APPSERVNAME, user, passwd, NULL);
#endif
		free(user);
		free(passwd);
		offset = Snprintf(header, *hlen, "%s", reply[R401]);
		goto done;
	    }
	    DEBUG(("Auth OK. User loggged in as %s:%s\n", user, passwd));
#ifdef USE_CAT
	    if (Info->log_success) {
		ret = catlog_vevent(sess, wsloglbls[WS_AUTHUSEROK], 
				    APPSERVNAME, mapuser, NULL);
		if (ret != 0) {
		    DEBUG(("Could not send log: %s. \n", caterr_str(ret)));
		}
	    }
#endif
	    free(user);
	    free(passwd);
	} else {
	    offset = Snprintf(&header[offset], 
			      *hlen,
			      "%s%s\"%s\"\r\n",
			      reply[R401],
			      "WWW-Authenticate: Basic realm=", 
			      realmbuf);
	    goto done;
	}
    }
    if ((*bodylen = readfile(filepath, &repbody, 0)) < 0) {
	/*
	 * Treat all possible errors as "Not Found"
	 */
	offset = Snprintf(header, *hlen, "%s", reply[R404]);
	DEBUG(("could not read file: %s\n", filepath));
	goto done; 
    }
    DEBUG(("File fetched succesfully\n"));
    offset = Snprintf(header, *hlen, "%s", reply[R200]);
    if (file_to_mediatype(filepath, &mediatype) != 0) {
	DEBUG(("could not determine media-type for: %s\n", filepath));
    } else {
	nchars = Snprintf(&header[offset], (*hlen - offset), "%s", mediatype);
	offset += nchars;
    }
    if (*bodylen > 0) {
	nchars = Snprintf(&header[offset], (*hlen - offset), 
			  "Content-Length:%d\r\n", *bodylen);
	offset += nchars;
    }
  done:
    Snprintf(&header[offset], (*hlen - offset), "%s", "\r\n");
    if (repbody) {
	*body = repbody;
    }
    return 0;
}
