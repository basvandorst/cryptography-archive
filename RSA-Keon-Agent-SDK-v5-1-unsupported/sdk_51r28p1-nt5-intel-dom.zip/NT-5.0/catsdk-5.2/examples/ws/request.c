/*
 * @(#)$Header: /srcroot/Lego-CVSROOT/catagent/example_ws/request.c,v 1.4 2000/01/31 17:21:17 elias Exp $
 *
 * Copyright (c) 2000 RSA Security
 *
 * Description:	Functions to read an HTTP request.
 *              
 *            
 */

#ifdef USE_CAT
#include "wscat.h"
#else
#include "ws.h"
#endif


#ifdef USE_CAT

/*
 * has_entire_header()
 *
 * Description:
 *    Check if a buffer contains a complete http request header.
 *    I. e. verify that there is a "\r\n\r\n".
 *    Any body in the request is discarded since we are only 
 *    interested in the GET request.
 *
 * Arguments:
 *    buf     IN: buffer containing the presumed header
 *
 * Returns:
 *    0 if buf contained a complete header,
 *    CAT_ENOTFOUND if the buffer did not contain complete header
 *    Other negative code on error.
 */
static int
has_entire_header(cat_buffer *buf) 
{
    int idx, ret;

    if (buf == NULL) {
	return WS_EINVAL;
    }
    idx = catbuf_pos(buf);
    while (1) {
	if ((ret = catbuf_scan(buf, "\r", 1)) < 0) {
	    ret = WS_ENOTFOUND;
	    break;
	}
	catbuf_index(buf, catbuf_pos(buf) + ret + 1);
	if (catbuf_match(buf, "\n\r\n", 3) == 3) {
	    break;
	}
    }
    catbuf_index(buf, idx);
    return 0;
}


/*
 * read_request()
 *
 * Description:
 *    Read an http request from the client. Try until the whole 
 *    request is read.
 *
 *    NOTE:
 *    A blocking read in a single thread of execution is indeed a 
 *    very bad thing in a server application. On the other hand, this 
 *    is an example where simplicity is desired.
 *
 * Arguments:
 *    sess         IN: session
 *    header      OUT: buffer to contain the received header
 *    hbuflen  IN/OUT: value-result should contain the 
 *                     size of header when called.
 *                     Will contain the size of the read header on 
 *                     exit. 
 *
 * Returns:
 *    0 if a complete header was read, < 0 otherwise.
 */
int
read_request(cat_session *sess, char *header, int *hbuflen)
{
    int ret = 0;
    cat_buffer *buf, *accbuf;
    
    accbuf = catbuf_new(sess, 0, NULL);
    while (1) {
	ret = cat_recv(sess, CAT_CLIENT_RFD, &buf);
	switch (ret) {
	  case 0:
	  case CAT_EAGAIN:
	    continue;
	    break;
	  case CAT_ETIMEDOUT:
	    DEBUG(("read_equest() timed out\n"));
	    catbuf_free(accbuf);
	    return WS_ETIMEOUT;
	  case CAT_EOF:
	    DEBUG(("connection closed by client\n"));
	    catbuf_free(accbuf);
	    return WS_EOF;
	  default:
	    if (ret < 0) {
		DEBUG(("cat_recv() failed with: %s\n", caterr_str(ret)));
		catbuf_free(accbuf);
		return WS_ERROR;
	    } else {
		if (catbuf_join(accbuf, buf) == NULL) {
		    DEBUG(("Could not join buffers\n"));
		    catbuf_free(accbuf);
		    catbuf_free(buf);
		    return WS_ERROR;
		}
		if (has_entire_header(accbuf) != 0) {
		    DEBUG(("Didn't get entire header. Reading more.\n"));
		    continue;
		} else {
		    if (catbuf_len(accbuf) >= *hbuflen) {
			DEBUG(("insufficient buffer space for request header\n"));
			catbuf_free(accbuf);
			return WS_EOVERFLOW;
		    }
		    *hbuflen = catbuf_len(accbuf);
		    catbuf_extract(accbuf, 0, *hbuflen, header);
		    header[*hbuflen] = 0;
		    DEBUG(("recvd:\n%s\n", header));
		    catbuf_free(accbuf);
		    return 0;
		}
	    }
	}
    }
}

#else

/*
 * has_entire_header()
 *
 * Description:
 *    Check if a buffer contains a complete http request header.
 *    I. e. verify that there is a "\r\n\r\n".
 *    Any body in the request is discarded since we are only 
 *    interested in the GET request.
 *
 * Arguments:
 *    buf     IN: buffer containing the presumed header
 *
 * Returns:
 *    1 if the buffer contained complete header
 *    0 otherwise
 */
static int
has_entire_header(char *buf) 
{
    int ret;
    char *s;

    ret = 0;
    s = buf;
 
    while ((s = strchr(s, '\r')) != NULL) {
	if (strncmp(s, "\r\n\r\n", 4) == 0) {
	    ret = 1;
	    break;
	}
	s++;
    }
    return ret;
}


/*
 * read_request()
 *
 * Description:
 *    Read an http request from the client. Try until the whole 
 *    request is read.
 *
 *    NOTE:
 *    A blocking read in a single thread of execution is indeed a 
 *    very bad thing in a server application. On the other hand, this 
 *    is an example where simplicity is desired.
 *
 * Arguments:
 *    sock_fd      IN: a connected socket
 *    header      OUT: buffer to contain the received header
 *    hbuflen  IN/OUT: value-result should contain the 
 *                     size of header when called.
 *                     Will contain the size of the read header on 
 *                     exit. 
 *
 * Returns:
 *    0 if a complete header was read, < 0 otherwise.
 */
int
read_request(WS_SOCK sockfd, char *header, int *hbuflen)
{
    int nread, idx;

    idx = 0;

    for (;;) {
	nread = recv(sockfd, &header[idx], *hbuflen, 0);
	if (nread == 0) {
	    DEBUG(("Client closed connection\n"));
	    return WS_ECONNCLOSED;
	}
	if (nread < 0) {
	    return WS_ERROR;
	}
	idx += nread;
	if (idx >= *hbuflen) {
	    return WS_EOVERFLOW;
	}
	header[idx] = 0;
	if (has_entire_header(header)) {
	    break;
	}
    }
    *hbuflen = idx;
    return 0;
}

#endif
