/*
 * @(#)$Header: /srcroot/Lego-CVSROOT/catagent/example_ws/wscat.c,v 1.6 2000/01/26 22:47:00 elias Exp $
 *
 * Copyright (c) 2000 RSA Security
 *
 * Description:	Functions using the Keon Agent SDK 
 *            
 *
 * MT-Level:    
 */

#include "wscat.h"

/*
 * The global information
 */

settings *Info = NULL;

/*
 * The log labels, as defined in "labels.txt"
 */

char *wsloglbls[] = {
    WS_FACILITYLBL ".CNOPAC",
    WS_FACILITYLBL ".CMISSLOGID",
    WS_FACILITYLBL ".AUTHFAIL",
    WS_FACILITYLBL ".CEXPIRED",
    WS_FACILITYLBL ".CINVALID",
    WS_FACILITYLBL ".CCRITICAL",
    WS_FACILITYLBL ".CREVOKED",
    WS_FACILITYLBL ".CISSRUNK",
    WS_FACILITYLBL ".CBADSIGN",
    WS_FACILITYLBL ".SVAUTHFAIL",
    WS_FACILITYLBL ".AUTHUSEROK",
};

static catlog_dispatcher *initlog(void);
static int initcache(const char *ttlpath, const char *filepath,
		     const char *limitpath, struct cache *cache);
static int info_getint(cat_session *sess, const char *name, int *value);
static const char *certerr_to_lbl(int err);
static int open_vc(const char *filecfg, const char *pwdcfg, cat_psd **psd);

/*
 * create_session()
 *
 * Description:
 *   Create a new session, install io-handler &c
 *
 * Arguments:
 *    fd     IN: A connected socket to be inserted in the session
 *
 * Returns:
 *    Pointer to the new session if successful, NULL otherwise.
 */

cat_session *
create_session(CATSOCK fd)
{
    int ret;
    cat_session *sess;

    if ((sess = cat_newsession()) == NULL) {
	DEBUG(("Failed to create new session\n"));
	return NULL;
    }

    if (cat_installiohandler(sess, catnet_iohandler(NULL), NULL) < 0) {
	DEBUG(("cat_installiohandler() failed\n"));
	cat_close(sess);
	return NULL;
    } 
   
    ret = catnet_setfd(sess, CAT_CLIENT_RFD | CAT_CLIENT_WFD, fd);
    if (ret < 0) {
	cat_close(sess);
	DEBUG(("catnet_setfd() failed with: %s\n", caterr_str(ret)));
	return NULL;
    }

    return sess;
}


/*
 * init_global()
 *
 * Description:
 *   Initialize global data used by the subsequent sessions.
 *
 * Arguments:
 *    None
 *
 * Returns:
 *    0 if successful, < 0 otherwise.
 */
int
init_global(void) 
{
    int ret;
    char *cafile;
    catlog_dispatcher *dp = NULL;

    ret = 0;
    /*
     * Allocate and initialize the global information structure
     */
    if ((Info = malloc(sizeof(settings))) == NULL) {
	return WS_ENOMEM;
    }
    memset(Info, 0, sizeof(settings));

    /*
     * Use full Keon support (and thereby demand a PAC)?
     */
    info_getint(NULL, ".wsconfig.require_pac", &(Info->require_pac));
    if (Info->require_pac) {
	DEBUG((".wsconfig.require_pac set. PACs demanded.\n"));
    }

    /*
     * Initialize logging
     */
    if ((dp = initlog()) == 0) {
	DEBUG(("Could not initialize logging\n"));
    } else {
	/*
	 * Save dispatcher for use when initializing sessions.
	 */
	Info->logdisp = dp;
    }

    /*
     * Should we log successful logins
     */
    info_getint(NULL, ".wsconfig.logok", &(Info->log_success));
    if (Info->log_success) {
	DEBUG((".wsconfig.logok set. Will log successful logins to ELS.\n"));
    }

    /*
     * Open PSD
     */
    ret = open_vc(".wsconfig.hostpsd.file", ".wsconfig.hostpsd.password", 
		  &(Info->psd));
    if (ret < 0) {
	DEBUG(("Failed to open Virtual Card.\n"));
	return ret;
    }

    /*
     * Set CA file
     */
    if (catinfo_get(NULL, ".wsconfig.ca.dbfile", &cafile) < 0) {
	DEBUG(("Could not find CA file.\n"));
	return WS_ENOTFOUND;
    } else {
	if ((ret = catcert_setcafile(cafile)) < 0) {
	    fprintf(stderr, "could set CA file\n");
	    free(cafile);
	    return WS_ERROR;
	}
	free(cafile);
    }

    /*
     * Create SSL session resumption cache
     */
    ret = initcache(".wsconfig.ssl.sessionttl", 
		    ".wsconfig.ssl.file",
		    ".wsconfig.ssl.maxcachesize",
		    &(Info->sslcache));
    if (ret < 0) {
	DEBUG(("Failed to initialize ssl cache\n"));
	ret = 0;
    }
    /*
     * Create verified certificate cache
     */
    ret = initcache(".wsconfig.cert.cachettl", 
		    ".wsconfig.cert.file",
		    ".wsconfig.cert.maxcachesize",
		    &(Info->certcache));
    if (ret < 0) {
	DEBUG(("Failed to initialize cert cache\n"));
	ret = 0;
    }

    /*
     * Get the method name from the config data
     */

    if (catinfo_get(NULL, ".wsconfig.method", &(Info->method)) < 0) {
	Info->method = malloc(strlen(DEFMETHOD) + 1);
	if (Info->method == NULL) {
	    return WS_ERROR;
	} else {
	    strcpy(Info->method, DEFMETHOD);
	}
	DEBUG(("Could not find method name, using \"%s\"\n", DEFMETHOD));
    }

    return ret;
}


/*
 * init_sess()
 *
 * Description:
 *   Initialize a session. Takes values from the global Info struct.
 *
 * Arguments:
 *    sess    IN: the session to initialize
 *
 * Returns:
 *    0 if successful, < 0 otherwise.
 */
int
init_sess(cat_session *sess)
{
    int ret;
    catssl_info *sslinfo;
    char buf[512];
    catnet_info netinfo;
    int old_timeout;
    const char *lbl;

    /*
     * Install the open PSD in the session
     */
    if ((ret = catpsd_setpsd(sess, Info->psd, 0)) != 0) {
	fprintf(stderr, "could not set psd: %s\n", caterr_str(ret));
	return WS_ERROR;
    }

    /*
     * Create a new ssl info structure and set the ciphers
     */
    if ((sslinfo = catssl_newinfo()) == NULL) {
	DEBUG(("Could create ssl-info\n"));
	return WS_ERROR;
    }
    if ((ret = catssl_setciphers(sslinfo, CAT_DEFAULT_CIPHERS)) != 0) {
        DEBUG(("Could not set ssl ciphers\n"));
	catssl_freeinfo(sslinfo);
	return WS_ERROR;
    }    

    /*
     * Set ssl session cache if possible
     */
    if (Info->sslcache.data) {
	ret = catssl_setdb(sslinfo, 
			   Info->sslcache.func, 
			   Info->sslcache.data);
	if (ret < 0) {
	    DEBUG(("Failed to install ssl session cache\n"));
	} else {
	    DEBUG(("Installing ssl session cache\n"));
	}
    }

    /*
     * Set certificate verification callback
     */
    if ((ret = catcert_setchecktype(sess, CATCERT_VERIFY_LOCAL)) < 0) {
	DEBUG(("catcert_setchecktype() failed: %s.\n", caterr_str(ret)));
	return WS_ERROR;
    }

    /*
     * Set verified certificate cache
     */
    if (Info->certcache.data) {
	ret = catcert_setdb(sess, 
			    Info->certcache.func, 
			    Info->certcache.data);
	if (ret != 0) {
	    DEBUG(("Failed to install certificate cache\n"));
	} else {
	    DEBUG(("Installing verified cert cache\n"));
	}
    }

    /*
     * Set up logging for the session
     */
    if (Info->logdisp) {
	if (catlog_setdispatcher(sess, Info->logdisp) != 0) {
	    DEBUG(("Failed to install ELS dispatcher\n"));
	    ret = WS_ERROR;
	}
	catlog_set(sess, CATLOG_HOSTNAME, cat_hostname(buf, sizeof(buf)));
	catlog_set(sess, CATLOG_FACILITY, WS_FACILITYLBL);
	catlog_set(sess, CATLOG_SERVICE, APPSERVNAME);
    } else {
	DEBUG(("Cannot set up session log dispatcher\n"));
    }

    /*
     * At this point we know the peer address and can set the
     * corresponding log-parameter.
     */

    if (catnet_getnetinfo(sess, CAT_CLIENT_RFD, &netinfo) == 0) {
	catlog_set(sess, CATLOG_CLIENTNAME, netinfo.peer_addr);
    }

    /*
     * Set time-out for this session to prevent malicious clients
     * from blocking our server.
     */
    
    old_timeout = catnet_settimeout(sess, SSLTIMEOUT * 1000);
    
    /*
     * Do server-side SSL
     */
    for (;;) {
	ret = catssl_serverhandshake(sess, sslinfo, CAT_CLIENT_RFD | CAT_CLIENT_WFD);
	if (ret == 0) {
	    break;
	} else {
	    if (ret != CAT_EAGAIN) {
		fprintf(stderr, "ssl handshake failed with: %s.\n",
			caterr_str(ret));
		if ((lbl = certerr_to_lbl(ret)) != NULL) {
		    catlog_vevent(sess, lbl, APPSERVNAME, NULL);
		}
		catssl_freeinfo(sslinfo);
		return WS_ERROR;
	    }
	}
    }

    /*
     * Restore time-out
     */ 
    catnet_settimeout(sess, old_timeout);

    return 0;
}


/*
 * earauth()
 *
 * Description:
 *   Do authentication of the user. I.e. verify that the
 *   user has Access Rights and do mapping of credentials.
 *   This function will also log errors to ELS.
 *
 * Arguments:
 *    sess     IN: the session
 *    svc      IN: the <service>-<version> string
 *    method   IN: the method name
 *    user     IN: given username (rolename)
 *    pass     IN: given password
 *    logid   OUT: the "Keon name" of the user
 *    mapuser OUT: the mapped username
 *    mappass OUT: the mapped password
 *
 * Returns:
 *    0 if successful, < 0 otherwise.
 *
 * Note:
 *    On a succesful call, logid, mapuser and mappass are 
 *    dynamically allocated and must be freed by caller.
 */
int
earauth(cat_session *sess, 
	char *svc,
	char *method,
	char *user, 
	char *pass, 
	char **logid, 
	char **mapuser, 
	char **mappass)
{
    int ret;
    catpac_ear *ep;
    char *svcver;
    char *version;

    if (!svc || !method || !user || !pass) {
	return WS_EINVAL;
    }

    if ((svcver = malloc(strlen(svc) + 1)) == NULL) {
	return WS_ENOMEM;
    }
    strcpy(svcver, svc);

    /*
     * Split the "<service>-<version>" string into
     * <service> and <version>
     */
    if ((version = strrchr(svcver, '-')) == NULL) {
	DEBUG(("No version found\n"));
    }
    version[0] = 0;
    version++;
    if (!isdigit(*version)) {
	DEBUG(("No version found\n"));
    }
    ret = catpac_openear(sess, &ep, svcver, version, method);
    if (ret < 0) {
	DEBUG(("no access rights found in pac"));
	if (ret != CAT_ECRYPT) {
	    catlog_vevent(sess, wsloglbls[WS_CNOPAC], 
			  APPSERVNAME, user, NULL); 
	}
	goto done;
    }
    if ((ret = catear_getlogid(ep, logid)) < 0) {
	DEBUG(("no log-id found in pac"));
	catlog_vevent(sess, wsloglbls[WS_MISSLOGID], 
		      APPSERVNAME, NULL);
	catpac_closeear(ep);
	goto done;
    }
    DEBUG(("Ear logid is %s\n", *logid));
  
    ret = catear_dbmap(ep, user, pass, NULL,
		       mapuser, mappass, NULL);
    if (ret != 0) {
	DEBUG(("authentication failed\n"));
	catlog_vevent(sess, wsloglbls[WS_AUTHFAIL], 
		      APPSERVNAME, user, NULL);
	free(*logid);
    }
    catpac_closeear(ep);
  done:
    free(svcver);
    return ret;
}


/*
 * ------------------- local helper functions -------------------
 */


/*
 * open_vc()
 *
 * Description:
 *   Load and open a Virtual Card. Reads the configuration params
 *   to determine file and password.
 *
 * Arguments:
 *    filecfg      IN: info path pointing out the VC file
 *    pwdcfg       IN: info path pointing out password
 *    psd         OUT: handle to the opened PSD
 *
 * Returns:
 *    0 if successful, < 0 otherwise.
 */
static int
open_vc(const char *filecfg, const char *pwdcfg, cat_psd **psd)
{
    int ret;
    char *psdfile, *psdpwd, *b64psd;

    psdfile = NULL;
    psdpwd  = NULL;
    b64psd  = NULL;
    ret = 0;
    if (catinfo_get(NULL, filecfg, &psdfile) != 0) {
	DEBUG(("No Virtual Card file found.\n"));
	return WS_ENOTFOUND;
    }
    if (catinfo_get(NULL, pwdcfg, &psdpwd) != 0) {
	DEBUG(("No Virual Card password found.\n"));
	ret = WS_ENOTFOUND;
	goto done;
    }  
    if (readfile(psdfile, &b64psd, 1) <= 0) {
	/*
	 * Treat all possible errors as "Not Found"
	 */
	DEBUG(("Could not read file: %s\n", psdfile));
	ret = WS_ENOTFOUND;
	goto done;
    }
    if (catpsd_openpsd(b64psd, psd, psdpwd, 0) < 0) {
	DEBUG(("Could not open Virtual Card\n"));
	ret = WS_EACCES;
    }

  done:
    cat_free(psdfile);
    cat_free(psdpwd);
    cat_free(b64psd);

    return ret;
}


/*
 * initcache()
 *
 * Description:
 *    Initialize a memory or file cache given configuration names
 *    of where to obtain them from the catinfo interface.
 *    It will either use a file or memory db as cache.
 *
 * Arguments:
 *    ttlpath    IN: Infopath to the time to live value.
 *                   If the value does not exist, entries
 *                   won't be removed from the cache.
 *    filepath   IN: Infopath to the a db-file. If present,
 *                   a file database is installed.
 *    limitpath  IN: Infopath to upper size limit of cache i Kb.
 *    cache     OUT: Initialized cache structure.
 *
 * Returns:
 *    0 if successful, < 0 otherwise.
 */
static int
initcache(const char *ttlpath, const char *filepath,
	  const char *limitpath, struct cache *cache)
{
    cat_filedb *fdb;
    cat_memdb *mdb;
    int ttl, ret, size;
    char *file;

    ret = 0;

    if (!cache->setup) {
	cache->setup++;
	ttl = -1;
	size = -1;
	info_getint(NULL, ttlpath, &ttl);
	if (ttl == 0) {
	    DEBUG(("%s == 0, disable cache\n", ttlpath));
	    cache->data = NULL;
	    goto done;
	}
	catinfo_get(NULL, filepath, &file);
	info_getint(NULL, limitpath, &size);
	if (file != NULL && *file) {
	    DEBUG(("%s: ttl == %d, use %s\n", filepath, ttl, file));
	    if ((ret = cat_newfiledb(file, -1, ttl, &fdb)) < 0) {
		DEBUG(("failed to create cache file %s\n", file));
	    } else {
		cache->func = cat_filedbfunc;
		cache->data = fdb;
	    }
	    goto done;
	}
	if ((ret = cat_newmemdb(-1, ttl, &mdb)) == 0) {
	    DEBUG(("%s: ttl == %d, in-memory\n", filepath, ttl));
	    cache->func = cat_memdbfunc;
	    cache->data = mdb;
	    if (size > 0) {
		DEBUG(("limit size to %d k\n", size));
		cat_memdbflags(mdb, CATMEMDB_MAXSIZE, size * 1024);
	    }
	}
    }
    
  done:

    return ret;
}


/*
 * info_getint()
 *
 * Description:
 *    Wrapper for catinfo_get(), to fetch an integer.
 *
 * Arguments:
 *    sess    IN: session
 *    name    IN: infopath to integer to be fetched
 *    value  OUT: resulting integer
 *
 * Returns:
 *    0 if successful, < 0 otherwise.
 */
static int
info_getint(cat_session *sess, const char *name, int *value)
{
    char *s;
    int ret;

    if ((ret = catinfo_get(sess, name, &s)) == 0) {
	if (!isdigit(*s) && *s != '-') {
	    ret = CAT_EINVAL;
	} else {
	    *value = atoi(s);
	}
	free(s);
    }
    return ret;
}


/*
 * initlog()
 *
 * Description:
 *    Read log definition file, set ELS server(s) file and obtain a 
 *    a log dispatcher
 *
 * Arguments:
 *    None.
 *
 * Returns:
 *    A log dispatcher if successful, NULL otherwise.
 */
static catlog_dispatcher *
initlog(void)
{
    int nservers;
    char *deffile;
    char *serv;
    char *s;
    const char *servers[MAX_ELS_SERVERS];
    catlog_dispatcher *dp;

    dp = NULL;
    serv = NULL;
    deffile = NULL;

    if (catinfo_get(NULL, ".wsconfig.els.deffile", &deffile) != 0) {
	DEBUG(("No log definition file set\n"));
	return NULL;
    }
    if (catlog_loadspecfile(deffile, catlog_mklabel) <= 0) {
	DEBUG(("Failed to load labels from log definition file %s", deffile));
	goto done;
    }

    if (catinfo_get(NULL, ".wsconfig.els.servers", &serv) != 0) {
	DEBUG(("Config param for ELS-Servers not found.\n"));
	goto done;
    }
    s = serv;
    nservers = 0;
    while (nservers < MAX_ELS_SERVERS-1) {
	while (isspace(*s)) {
	    ++s;
	}
	servers[nservers++] = s;
	if ((s = strchr(s, ',')) == NULL) {
	    break;
	}
	*s++ = 0;
    }
    servers[nservers] = NULL;
    if (nservers == 0) {
	DEBUG(("No ELS servers set\n"));
	goto done;
    }
    if (catels_loginit(NULL, servers, &dp) != 0) {
	DEBUG(("Failed to get ELS dispatcher\n"));
    }
    
  done:
    cat_free(deffile);
    cat_free(serv);

    return dp;
}


/*
 * certerr_to_lbl()
 *
 * Description:
 *    Helper to map CAT-certificate error codes to appropriate
 *    log labels.
 *
 * Arguments:
 *    err    IN: CAT error code
 *
 * Returns:
 *    Pointer to the appropriate log label in the global log label 
 *    array. If err is not an error code related to certificates, 
 *    NULL is returned.
 */
static const char *
certerr_to_lbl(int err)
{
    switch (err) {
      case CAT_ECERTEXPIRED:
	return wsloglbls[WS_CEXPIRED];
	
      case CAT_ECERTCRITICAL:
	return wsloglbls[WS_CCRITICAL];

      case CAT_ECERTREVOKED:
	return wsloglbls[WS_CREVOKED];

      case CAT_EISSUERUNKNOWN:
	return wsloglbls[WS_CISSUERUNKNOWN];

      case CAT_ECERTBADSIGNATURE:
	return wsloglbls[WS_CBADSIGNATURE];

      case CAT_ECRYPT:
      case CAT_ECERTINVALID:
	return wsloglbls[WS_CINVALID];
    }
    return NULL;
}

