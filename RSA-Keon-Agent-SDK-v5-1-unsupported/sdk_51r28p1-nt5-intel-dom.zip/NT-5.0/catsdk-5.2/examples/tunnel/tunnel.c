/*
 * $Id: tunnel.c,v 1.9 2000/02/21 11:07:46 perre Exp $
 *
 * (C) Copyright 1999, RSA Security
 *
 * Description:
 *    A Low level crypto tunnel capable of performing both
 *    server and client side SSL negotiation. Default is do
 *    the server side. 
 *
 * Note:
 *    The client side functions (DASP/ALLTAAS/ALLTAK or SSL) of
 *    this SDK is not supported.
 *   
 * Arguments:
 *    Standard Agent Arguments.
 *
 */

#include <stdlib.h>
#include <ctype.h>
#include <cat/cat.h>
#include <cat/gen.h>

typedef struct loglabel {
    char *label;        /* Label in definition file */
    char svty;          /* Severity of event. I/W/E/F. */
    char *descr;        /* Descriptive string / Format */
    int  code;          /* Log code in ELS. */
} loglabel;

#define TIMEOUT            10000
#define CACHE_DEFAULT_TTL  20
#define ELS_MAXSERVERS     16
#define AGENT_VERSION      "5.0"
#define AGENT_SERVICE      "tunnel_sample-" AGENT_VERSION
#define VC_LOADED          -1000
#define VC_LOAD_FAIL       -1001
#define NLABELS (sizeof(loglabels) / sizeof(loglabel))

/*
 * Global structure containing the ELS (Event Logging Subsystem) log 
 * messages. These will be used to generate log lables that can be 
 * sent to the ELS server.
 */
static loglabel loglabels[] = {
    { "CONNFAIL", 'E', "&1: ERROR failed to connect to &2", 1000 },
    { "CEXPIRED", 'W', "&1: REJECT &C: Certificate expired", 1008 },
    { "CINVALID", 'W', "&1: REJECT &C: Certificate invalid", 1009 },
    { "CCRITICAL",'W', "&1: REJECT &C: Certificate contains unsupported critical extension", 1010 },
    { "CREVOKED", 'W', "&1: REJECT &C: Certificate has been revoked", 1011 },
    { "CISSRUNK", 'W', "&1: REJECT &C: Certificate issuer unknown", 1012 },
    { "CBADSIGN", 'W', "&1: REJECT &C: Certificate invalid (bad signature)", 1013 },
    { "HOSTPSD",  'I', "&1: Loaded Host PSD: &2", 1016 },
    { "HOSTPSDERR",'W', "&1: Failed to load Host PSD", 1017 },
};

/*
 * Global variables. For a closer description of information stored
 * in the catgen_global_data structure, read the gen.h file.
 */
extern catgen_data catgen_global_data;
cat_memdb *cert_cache = NULL;
cat_memdb *ssl_cache = NULL;

/* Forward declarations. */
static int set_ca(void);
static int loadfile(char **psd, char **psw);
static int load_hostpsd(cat_session *sess);
static int listenfunc(cat_session *sess, int event, int *flags, void *data);
static int sessfunc(cat_session *sess, int event, int *flags, void *data);
static int init_cache(cat_memdb **mdb, char *ttlpath, char *limitpath);
static void log_els(cat_session *sess, int error, const char *host);
static int add_listeners(void);
static int init_els(void);
static int do_ssl(cat_session *sess, catssl_info *ssl, int (*fun)(), int fds);
static int setup_ssl(cat_session *sess, catssl_info **ssl);
static int ssl_server(cat_session *sess);
static int ssl_client(cat_session *sess);
static int run_sessions(void);
static void init_debug(void);

/*
 * main()
 *
 * Description:
 *    The main function sets everything up and calls catsock_run() which
 *    will run all sessions. It uses cat_info layer where most of the 
 *    information is stored when using the Agent Base System
 *    and its configuration program.
 *
 * Arguments:
 *    argc         IN: Number of arguments.
 *    argv         IN: Array of pointers to the arguments.
 *
 * Returns:
 *    Returns 0 if no errors occured and 1 otherwise.
 */
int 
main(int argc, char *argv[])
{
    char *F = "main";
    cat_session *sess = NULL;
    char **p;
    int ret = CAT_OK;

    /*
     * Parses *only* agent specific paramters and store
     * the information in the catgen_global_data struct.
     */
    if (catgen_parseargs(argc, argv) != 0) {
        return 1;
    }
    /*
     * Initialize the SDK Libraries and the cat_info layer.
     * Some of the parameters given as argument and parsed by
     * catgen_parseargs() will be automatically stored in the 
     * info tree.
     */
    if (catgen_init() < 0) {
        return 1;
    }
    
    /*
     * Read from the info tree if the code should generate debug output.
     */
    init_debug();

    if (init_els() < 0) {
	return 1;
    }
    if (set_ca() < 0) {
	return 1;
    }

    /*
     * Create the ssl session resumption cache and the certificate cache.
     * Uses the global cat_memdb pointers.
     */
    if (init_cache(&cert_cache, ".global.cert.cachettl", 
		     ".global.cert.maxcachesize") < 0) 
    {
	return 1;
    } 
    if (init_cache(&ssl_cache, "ssl.sessionttl", "ssl.maxcachesize") < 0) {
	return 1;
    } 

    if (load_hostpsd(NULL) < 0) {
	return 1;
    }
    if (add_listeners() < 0) {
	return 1;
    }
    if (run_sessions() < 0) {
	return 1;
    }
    return 0;
}

/*
 * init_debug()
 *
 * Description:
 *    Read the configuration and set any appropriate debug level and
 *    debug output file.
 *
 * Arguments:
 *    None.
 *
 * Returns:
 *    Nothing.
 */
static void
init_debug(void)
{
    char *sp = NULL;
    char *file = NULL;
    const char *path[4];
    int n = 0;
    char *s = NULL;;
    
    if (catgen_global_data.debugspec != NULL) {
	sp = catgen_global_data.debugspec;
    } else {
	path[n++] = ".gen.override";
	s = catgen_servicepath(AGENT_SERVICE);
	path[n++] = s;
	path[n++] = ".global";
	path[n] = NULL;
	if (catinfo_getbypath(path, "debug.spec", &sp) == 0) {
	    catgen_global_data.debugspec = sp;
	}
	catinfo_getbypath(path, "debug.file", &file);
	if (s)
	    free(s);
    }
    if (sp != NULL) {
	caterr_setdebug(sp);
    }
    if (file != NULL) {
	caterr_setfile(file);
	free(file);
    }
    return;    
}

/*
 * run_sessions()
 *
 * Description:
 *    Final configuration before letting the framework run the sessions.
 *    Register the callback function that takes care of communication
 *    with the parent process and update info tree automatically (if started
 *    by catd). Read idle and lifespan parameters and call catsock_run().
 *
 * Arguments:
 *    None.
 *
 * Returns:
 *    Returns 0 if no errors occured and negative value otherwise.
 */
static int
run_sessions(void)
{
    int ret = 0;
    char *path, buf[512];
    int idle, lifespan;

    idle = 0;
    lifespan = 0;
    
    /* 
     * If started by catd, the agent need to reread it's configuration
     * when catd tells it to do so (without having to restart it). 
     * This call will set a callback to take care of commands from catd.
     */
    if (catgen_global_data.has_parent != 0) {
	catgen_global_data.listenhandler = listenfunc;
        catsock_parent(catgen_parentcmd, catgen_global_data.parent_handle);
    }

    /*
     * Get the idle timeout and the lifespan of the agent.
     * If anyone of them times out the agent process will disappear
     */
    path = catgen_servicepath(AGENT_SERVICE);
    
    sprintf(buf, "%.*s.idle", (int)sizeof(buf)-16, path);
    catgen_getint(NULL, buf, &idle);
    
    sprintf(buf, "%.*s.lifespan", (int)sizeof(buf)-16, path);
    catgen_getint(NULL, buf, &lifespan);
    
    free(path); 

    ret = catsock_run(idle, lifespan);

    return ret;
}

/*
 * add_listeners()
 *
 * Description:
 *    Read the global information structure to find out what ports the
 *    agent should listen on for incoming connections. Create a session
 *    for each listening port and let the framework manage (take care
 *    of incoming connetions) the session by calling catsock_add().
 *
 * Arguments:
 *    None.
 *
 * Returns:
 *    Returns zero if no error and a negative value if errors where encountered
 */
static int
add_listeners(void)
{
    char *F = "add_listeners";
    cat_session *sess = NULL;
    char **p;
    int ret = CAT_ECONFIG;
    
    if (catgen_global_data.ports != NULL) {
	for (p = catgen_global_data.ports; *p != NULL; p++) {
	    if ((ret = catgen_newport(&sess, *p)) < 0) {
		break;
	    }
	    ret = catsock_add(sess, CATSOCK_LISTEN | CATSOCK_POLL, listenfunc);
            if (ret < 0) {
                cat_close(sess);
                break;
            }
	}
    }
    if (ret < 0) {
	caterr_error(NULL, F, CAT_ERROR, ret,
                     "failed to start up all listeners");
	return ret;
    }
    return CAT_OK;
}

/*
 * listenfunc()
 *
 * Description:
 *    Callback used by add_listeners() when adding a listening session to
 *    the framework. The function will get called by the framework for 
 *    the reason specified by the "event" parameter. It is very likely
 *    that the event will be an incoming connection. The connection will
 *    be handled in a new session which will be added to the framework.
 *
 * Arguments:
 *    sess          IN: A pointer to a cat_session.
 *    event         IN: The reason this callback got called.
 *    flags         IN/OUT: Flags applying to this session.
 *    data          IN: A pointer to the new session created by the
 *                      framework for the incoming connection.
 *
 * Returns:
 *    Returns zero if no error and a negative value if errors where encountered
 */
static int
listenfunc(cat_session *sess, int event, int *flags, void *data)
{
    char *F = "listen_func";
    int sessflags = 0;
    int error = CAT_OK;
    cat_session *new;
    
    if (event == CATSOCK_LISTEN) {
	new = (cat_session *)data;
	sessflags = CATSOCK_INIT | CATSOCK_FORK | CATSOCK_POLL;

	error = catsock_add(new, sessflags, sessfunc);
	if (error < 0) {
	    CAT_DEBUG1((new, F, "catsock_add failed (%s)", 
			caterr_name(error)));
	    cat_close(new);
	}
    }
    return error;
}

/*
 * sessfunc()
 *
 * Description:
 *    Callback used by listenfunc() when adding a traffic handling session to
 *    the framework. The function will get called by the framework for 
 *    the reason specified by "event" parameter. Will set the timeout, 
 *    connect to the server and perform the specified SSL negotiation type
 *    (client/server). Logs to ELS if the connection to the server failed or
 *    if the SSL negotiation failed.
 *
 * Arguments:
 *    sess          IN: A pointer to a cat_session.
 *    event         IN: The reason this callback got called.
 *    flags         IN/OUT: Flags applying to this session.
 *    data          IN: Not used.
 *
 * Returns:
 *    Returns zero if no error and a negative value if errors where encountered
 */
static int
sessfunc(cat_session *sess, int event, int *flags, void *data)
{
    char *F = "sessfunc";
    catnet_info net;
    int n, ret;
    char *s;
    int do_server;

    if (event == CATSOCK_PARENT) {
	return CAT_OK;
    }
    
    /* 
     * Set up the search path for the catinfo_ functions to include
     * the port specification. Needed to find which server to 
     * connect to etc
     */
    if (catnet_getnetinfo(sess, CAT_CLIENT_RFD, &net) != 0) {
        return CAT_EINVAL;
    }
    catgen_infopath(sess, NULL, net.my_port);
    catlog_set(sess, CATLOG_CLIENTNAME, net.peer_addr);

    n = CATGEN_SESSION_TIMEOUT;
    catgen_getint(sess, "timeout", &n);
    if (n != 0 && (ret = catnet_settimeout(sess, n * 1000)) < -1) {
        return ret;
    }

    /* Connect to server. If connection i refused, log to ELS. */
    if (catinfo_get(sess, "server", &s) == 0 && *s) {
        ret = catnet_connect(sess, s, 0);
        if (ret < 0) {
            CAT_DEBUG1((sess, F, "Failed to connect to %s", s));
	    log_els(sess, ret, s);
            free(s);
            return ret;
        }
        free(s);
    } else {
        CAT_DEBUG1((sess, F, "no server defined"));
	return CAT_ECONFIG;
    }
    catcert_setdb(sess, cat_memdbfunc, cert_cache);
    
    /* 
     * Determine what ssl negotiation (client/server) should be 
     * perfomed and do it. Try to log to ELS if any return value
     * is recognized as an erroneous cert.
     */
    do_server = 1;
    catgen_getint(sess, "tunnel.do_server", &do_server);
    if (do_server) {
	ret = ssl_server(sess);
    } else {
	ret = ssl_client(sess);
    }
    if (ret < 0) {
	log_els(sess, ret, NULL);
	return ret;
    }
    return CAT_OK;
}

/*
 * set_ca()
 *
 * Description:
 *    Will set the framework to use the specified file as the CA db-file.
 *    The specified file should contain certificates needed in BASE64 encoded
 *    format.
 *
 * Arguments:
 *    None.
 *
 * Returns:
 *    Returns zero if no error and a negative value if errors where encountered
 */
static int
set_ca(void)
{
    char *F   = "set_ca";
    int error = CAT_OK;
    char *ca  = NULL;

    if ((error = catinfo_get(NULL, ".global.ca.dbfile", &ca)) < 0) {
        goto done;
    }
    if ((error = catcert_setcafile(ca)) < 0) {
        CAT_DEBUG1((NULL, F, "Unable to set ca file"));
        goto done;
    }
    CAT_DEBUG3((NULL, F, "Setting ca path:%s", ca));

done:
    if (ca)
        free(ca); 

    return error;
}

/*
 * init_cache()
 *
 * Description:
 *    Will create an in memory data base that can be used when setting
 *    up various caches (eg SSL and certificate caches).
 *
 * Arguments:
 *    mdb          OUT: A pointer to a memory database pointer. Will
 *                      point to the newly created db if the
 *                      function was successful.
 *    ttlpath      IN: A path to the TTL (Time-To-Live) value in the 
 *                     information tree.
 *    limitpath    IN: A path to the size limit of the cache.
 *
 * Returns:
 *    Returns zero if no error and a negative value if errors where encountered
 */
static int
init_cache(cat_memdb **mdb, char *ttlpath, char *limitpath)
{
    char *F = "init_cache";
    int ttl, ret, size;

    ttl = CACHE_DEFAULT_TTL;
    ret = CAT_OK;
    size = 0;
    
    catgen_getint(NULL, limitpath, &size);
    catgen_getint(NULL, ttlpath, &ttl);
    
    if ((ret = cat_newmemdb(-1, ttl, mdb)) ==  0) {
	CAT_DEBUG2((NULL, F, "Created cache, ttl == %d, in-memory", ttl));
	if (size > 0) {
	    cat_memdbflags(*mdb, CATMEMDB_MAXSIZE, size * 1024);
	}
    }
    return ret;
}

/*
 * load_hostpsd()
 *
 * Description:
 *    Load the Host Virtual card (ie the Host PSD). If sess is a non-NULL
 *    value, the opened Virtual Card will be set to be used by the
 *    SSL negotiation. 
 *
 * Arguments:
 *    sess           IN: A pointer to a cat_session.
 *
 * Returns:
 *    Returns zero if no error and a negative value if errors where encountered
 */
static int
load_hostpsd(cat_session *sess)
{
    int error = CAT_OK;
    cat_psd *psd;
    char *data;
    char *psw;

    data = NULL;
    psw  = NULL;
    psd  = NULL;

    if (catinfo_get(sess, ".global.hostpsd.data", &data) < 0) {
	if ((error = loadfile(&data, &psw)) < 0) {
	    goto done;
	}
    } else {
	catinfo_get(sess, ".global.hostpsd.password", &psw); 
    }
    if (sess != NULL) {
	if ((error = catpsd_openpsd(data, &psd, psw, 0)) < 0) {
	    goto done;
	}
	catpsd_setpsd(sess, psd, CATPSD_CLOSE);
    } else {
	if ((error = catpsd_openpsd(data, NULL, psw, 0)) < 0) {
	    goto done;
	}
	log_els(sess, VC_LOADED, catlog_get(sess, CATLOG_HOSTNAME)); 
    }

done:
    if (error < 0)
	log_els(sess, VC_LOAD_FAIL, NULL);
    if (data)
	free(data);
    if (psw)
	free(psw);

    return error;
}

/*
 * loadfile()
 *
 * Description:
 *    A utility function that searches the info tree to find where
 *    the Host Virtual file is stored and reads it. If successful it will also
 *    locate the file with the password for the Virtual Card and read that 
 *    aswell.
 *
 * Arguments:
 *    psd           OUT: Will point to a buffer with the Virtual Card.
 *    psw           OUT: Will point to a buffer containing the password
 *                       For the above Virtual Card.
 *
 * Returns:
 *    Returns zero if no error and a negative value if errors where encountered
 */
static int
loadfile(char **psd, char **psw)
{
    char *F = "loadfile";
    char *file, *s;
    int error;

    file = NULL;
    *psd = NULL;
    *psw = NULL;
    error = CAT_ECONFIG;

    if (catinfo_get(NULL, ".global.hostpsd.file", &file) < 0) {
	CAT_DEBUG1((NULL, F, "No host Virtual Card set"));
	goto done;
    }
    if ((error = cat_getfile(file, psd)) < 0) {
	CAT_DEBUG1((NULL, F, "Unable to read file: %s", file));
	goto done;
    }
    catinfo_set(".global.hostpsd.data", *psd);

    if (catinfo_get(NULL, ".global.hostpsd.password", psw) < 0) {
        free(file);
        file = NULL;
        error = CAT_ECONFIG;
        if (catinfo_get(NULL, ".global.hostpsd.passwordfile", &file) < 0) {
            CAT_DEBUG1((NULL, F, "Host psd password not set"));
            goto done;
        }
        if ((error = cat_getfile(file, psw)) < 0) {
            CAT_DEBUG1((NULL, F, "Unable to read host password file"));
            goto done;
        }
        if ((s = strpbrk(*psw, "\n\r")) != NULL) {
            *s = 0;
        }
    }
    catinfo_set(".global.hostpsd.password", *psw);
    
done:
    if (file)
	free(file);

    if (*psw && error < 0) {
	free(*psw);
	*psw = NULL;
    }
    if (*psd && error < 0) {
	free(*psd);
	*psd = NULL;
    }
    return error;
}

/*
 * ssl_client()
 *
 * Description:
 *    Setup a SSL session and call do_ssl with the clienthanshake function.
 *    The client side SSL is not supported.
 *    
 * Arguments:
 *    sess         IN: A pointer to a cat_session.
 *
 * Returns:
 *    Returns zero if no error and a negative value if errors where encountered
 */
static int
ssl_client(cat_session *sess)
{
    char *F = "ssl_client";
    catssl_info *ssl = NULL;
    int n, flags;

    if ((n = setup_ssl(sess, &ssl)) < 0) {
        return n;
    }
    flags = CAT_SERVER_RFD | CAT_SERVER_WFD;
    n = do_ssl(sess, ssl, catssl_clienthandshake, flags);

    catssl_freeinfo(ssl);

    return n;
}

/*
 * ssl_client()
 *
 * Description:
 *    Setup a SSL session and call do_ssl with the serverhanshake function.
 *
 * Arguments:
 *    sess         IN: A pointer to a cat_session.
 *
 * Returns:
 *    Returns zero if no error and a negative value if errors where encountered
 */
static int
ssl_server(cat_session *sess)
{
    char *F = "ssl_server";
    catssl_info *ssl = NULL;
    int n, flags;

    if ((n = setup_ssl(sess, &ssl)) < 0) {
        return n;
    }
    flags = CAT_CLIENT_RFD | CAT_CLIENT_WFD;
    n = do_ssl(sess, ssl, catssl_serverhandshake, flags);

    catssl_freeinfo(ssl);

    return n;
}

/*
 * setup_ssl()
 *
 * Description:
 *    Setup the SSL session so any negotiation may take place. Create a ssl
 *    session (keep track of SSL states), set the host Virtual Card and
 *    set the authentication form for the peer certificate.
 *
 * Arguments:
 *    sess         IN: A pointer to a cat_session.
 *    ssl          OUT: A pointer to a ssl session struct.
 *     
 *
 * Returns:
 *    Returns zero if no error and a negative value if errors where encountered
 */
static int
setup_ssl(cat_session *sess, catssl_info **ssl)
{
    char *F = "setup_ssl";
    char *s;
    int n;

    if ((*ssl = catssl_newinfo()) == NULL) {
        CAT_DEBUG1((sess, F, "catssl_newinfo failed"));
        return CAT_EINTERNAL;
    }
    if ((n = load_hostpsd(sess)) < 0) {
        return n;
    }
    if ((n = catcert_setchecktype(sess, CATCERT_VERIFY_LOCAL)) < 0) {
        CAT_DEBUG1((sess, F, "setchecktype failed"));
        return n;
    }
    catssl_setdb(*ssl, cat_memdbfunc, ssl_cache);
    return 0;
}

/*
 * do_ssl()
 *
 * Description:
 *    While loop that calls the client_handshake or server_handshake functions
 *    until the negotiation is complete.
 *
 * Arguments:
 *    sess         IN: A pointer to a cat_session.
 *    ssl          IN: A pointer to a ssl session struct.
 *    fun          IN: Function pointer to negotiating function to call.
 *
 * Returns:
 *    Returns zero if no error and a negative value if errors where encountered
 */
static int
do_ssl(cat_session *sess, catssl_info *ssl, int (*fun)(), int fds)
{
    int n;

    while ((n = fun(sess, ssl, fds)) == CAT_EAGAIN) {
        n = cat_poll(sess, fds & (CAT_SERVER_RFD | CAT_CLIENT_RFD), TIMEOUT);
        if (n == 0) {
            n = CAT_ETIMEDOUT;
        }
        if (n < 0) {
            break;
        }
    }
    return n;
}

/*
 * init_els()
 *
 * Description:
 *    Initiate the Event Logging Subsystem. Generates the log labels, find
 *    and setup available ELS servers. Creates a log dispatcher with the
 *    catels_loginit() call and set the result as the global dispatcher.
 *
 * Arguments:
 *    None.
 *
 * Returns:
 *    Returns zero if no error and a negative value if errors where encountered
 */
static int
init_els(void)
{
    char buf[256], *F = "init_els";
    const char *servers[ELS_MAXSERVERS];
    int off, ret, i, nservers, dontverifyserver;
    char *facility, *s, *tmp, *spoolfile;
    unsigned code, facility_code;
    catlog_dispatcher *dispatcher;

    servers[0] = NULL;
    dispatcher = NULL;
    spoolfile  = NULL;
    tmp        = NULL;
    nservers   = 0;
    off = 0;
    ret = 0;
    facility = CATGEN_FACILITYLABEL;
    facility_code = CATGEN_FACILITYCODE;

    catlog_set(NULL, CATLOG_HOSTNAME, cat_hostname(buf, sizeof(buf)));
    catlog_set(NULL, CATLOG_FACILITY, facility);

    /*
     * Create loglables. Uses the global loglabel struct which contains
     * all data available.
     */
    for (i = 0; i < NLABELS; i++) {
	code = CATLOG_CODE(facility_code, loglabels[i].svty, loglabels[i].code);
	ret = catlog_mklabel(facility, loglabels[i].label, 
			     code, loglabels[i].descr);
	if (ret < 0) {
	    break;
	}
    }
    if (ret < 0) {
	CAT_DEBUG2((NULL, F, "Failed to set log labels, will not log"));
	goto done;
    }

    /* 
     * Setup ELS Servers. If no servers are found in the configuration
     * ELS setup (and logging) is skipped. If servers are found
     * create a log dispatcher with catels_loginit() and set
     * it as the global log dispatcher.
     */
    ret = 0;
    if (catinfo_get(NULL, ".global.els.servers", &tmp) == 0) {
	s = tmp;
        while (nservers < ELS_MAXSERVERS-1) {
            while (isspace(*s)) {
                ++s;
            }
            servers[nservers++] = s;
            if ((s = strchr(s, ',')) == NULL) {
                break;
            }
            *s++ = 0;
        }
        servers[nservers] = NULL;
    }
    if (nservers == 0) {
	CAT_DEBUG1((NULL, F, "No servers, skipping ELS"));
	goto done;
    } else {
	catinfo_get(NULL, ".global.els.logfile", &spoolfile);
        if (spoolfile && !*spoolfile) {
            free(spoolfile);
            spoolfile = NULL;
        }
        ret = catels_loginit(spoolfile, servers, &dispatcher);
        if (ret < 0) {
            caterr_error(NULL, F, CAT_ERROR, ret,
                         "ELS log init failed. Spoolfile not writable?");
	    goto done;
        } 
	catlog_setdispatcher(NULL, dispatcher);
    }
    CAT_DEBUG3((NULL, F, "ELS Setup done"));

done:
    if (tmp)
	free(tmp);
    if (spoolfile)
	free(spoolfile);

    return ret;
}

/*
 * log_els()
 *
 * Description:
 *    A wrapper function that logs to ELS via the catlog_event() call. 
 *    Translates an error code to a valid log label. Some log format strings
 *    require a host specification, hence the host inparameter.
 *
 * Arguments:
 *    sess        IN: A pointer to a cat_session.
 *    error       IN: Error code to translate.
 *    host        IN: Host specification. It's either the name of the localhost
 *                    or the name of the peer host.
 *
 * Returns:
 *    None.
 */
static void
log_els(cat_session *sess, int error, const char *host)
{
    char *F = "log_els";
    const char *arg[2];
    char *lbl, *tmp;
    catnet_info net;
    int ret;

    arg[0] = AGENT_SERVICE;
    lbl = NULL;
    tmp = NULL;
    if (host) {
	arg[1] = host;
    }

    if (catinfo_get(NULL, ".global.els.servers", &tmp) < 0) {
	CAT_DEBUG2((sess, F, "No servers defined. No logging"));
	goto done;
    }

    switch (error) {
      case CAT_ECERTEXPIRED:
	lbl = "CEXPIRED";
	break;
      case CAT_ECERTINVALID:
	lbl = "CINVALID";
	break;
      case CAT_ECERTCRITICAL:
	lbl = "CCRITICAL";
	break;
      case CAT_ECERTREVOKED:
	lbl = "CREVOKED";
	break;
      case CAT_EISSUERUNKNOWN:
	lbl = "CISSRUNK";
	break;
      case CAT_ECERTBADSIGNATURE:
	lbl = "CBADSIGN";
	break;
      case VC_LOADED:
	lbl = "HOSTPSD";
	break;
      case CAT_ECONNREFUSED:
	lbl = "CONNFAIL";
	break;
      case VC_LOAD_FAIL:
	lbl = "HOSTPSDERR";
	break;
      default:
	CAT_DEBUG1((sess, F, "Unable to determine log label"));	    
	return;
    }
    if ((ret = catlog_event(NULL, lbl, arg)) < 0) {
	CAT_DEBUG1((sess, F, "Failed to log event:%d", ret));
    }

done:
    if (tmp)
	free(tmp);

    return;
}


