----------------------------------------------------------------------
		Crypto Tunnel Example
----------------------------------------------------------------------

This is an example of a low-level, SSL protected cryptographic tunnel.
As this Agent neither checks the user's access rights nor performs 
user role mapping, it has no modules that need to be installed on the
Keon Security Server 5.0.

The operation of the Crypto Tunnel Agent is as follows:

1. Call all necessary initialization functions. This step is also 
   performed by all Agents, using the generic layer.
2. Add a listening session for each port on which the Agent listens.
3. Run the sessions and perform the SSL server or client handshake.

Agent Design
-------------

The Agent has no filters except the SSL crypto filter, which is
pushed after a successful SSL handshake.

Build and Setup
----------------

See the examples/README.txt for instructions on how to build and 
create distributions, and install Agents.

Contents
--------

This directory contains the following files:

tunnel.c		- The main() for the Agent, together with a number 
			  of low-level cat_ functions that carry out 
			  operations that range from parsing arguments to
			  performing the SSL handshake.

Makefile.pp		- A file that is processed to a makefile, which 
			  builds the executable Agent binary.

Makefile		- Created by the installation framework at install
			  time. The filename may differ some on depending
			  on platform.

tunnel.pp		- An Agent-specific symbol definition file.

tunnel_sample.cfg	- A configuration file template for the Agent,
			  which supplies some default values for the
			  configuration program.

port.cfg		- A port configuration template file. Contains
			  definitions for agent specific parameters.

custom.tcl		- A tcl script that calls tcl procedures
			  that allow you to insert Agent specific
			  configuration prompts into the configuration 
			  program.

dist.pp	        	- A packing description file, used both when
			  creating the distribution and when
			  installing the Agent.

