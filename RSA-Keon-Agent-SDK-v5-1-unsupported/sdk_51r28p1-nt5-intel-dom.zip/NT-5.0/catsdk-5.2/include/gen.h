/*
 * @(#)$Id: gen.h,v 1.28 2000/02/02 15:04:11 elias Exp $
 *
 * Copyright � 2000 RSA Security
 *
 * Description:
 *
 *   High-level utility library for the Connect Agent Toolkit.
 */

#ifndef _cat_gen_h
#define _cat_gen_h

#include <cat/cat.h>
#include <cat/log.h>
#include <cat/catutil.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef int catgen_sessfunc(cat_session *, const char *, void *);

typedef struct {
    int setup;
    catdb_func *func;
    void *data;
} catgen_cache;

typedef struct catgen_data catgen_data;
struct catgen_data {
    int has_parent:1;		/* -C: controlled by other process */
    int initialized:1;		/* catgen_init() called */
    int infosetup:1;		/* info tree initialized */
    int running:1;		/* in catgen_run() */
    int loginit:1;		/* logging initilaized */
    int idle;			/* idle time in catgen_run() */
    int lifespan;		/* agent lifespan, in catgen_run() */
    int certkey;		/* sessdata key for verification wrapper */
    char *parent_handle;	/* -C: argument from parent */
    char *root;			/* configuration data root directory */
    char *progname;		/* (base-)name of this program */
    char **ports;		/* -P arguments */
    char *server;		/* server to connect to, overrides config */
    char *debugspec;		/* debug specification, e.g. "3;>/tmp/log" */
    char **info_names;		/* -I arguments, first half */
    char **info_values;		/* -I arguments, seconds half */
    catgen_sessfunc *userhandler; /* user-supplied callback for catgen_run() */
    void *userdata;		/* data to callback */
    int addflags;		/* flags to catsock_add(), use with care! */
    catgen_cache daspcache;	/* DASP key cache */
    catgen_cache sslcache;	/* SSL session cache */
    catsock_eventfunc *listenhandler; /* callback for accepted connections */
    catsock_eventfunc *sesshandler; /* callback for new sessions */
    catlog_dispatcher *bokslogger; /* log dispatcher: destination BoKS */
    catlog_dispatcher *elslogger; /* log dispatcher: destination ELS */
    catlog_dispatcher *filelogger; /* log dispatcher: destination local file */
    catgen_cache certcache;     /* verified certificate cache */
};

/*
 * Global state information.  There is only one of these.
 * Touch it only if you know what you are doing.
 */

#ifdef CAT_UNIX
extern catgen_data catgen_global_data;
#endif


#ifdef CAT_WIN32
extern catgen_data *___catgen_global_data();
#define catgen_global_data (*(___catgen_global_data()))
#endif

#define CATGEN_ROOTDIR	CAT_UDIR_ETC
#define	CATGEN_ROOTREG	"HKEY_LOCAL_MACHINE\\" CAT_WREG_ROOT

/*
 * Argument parsing
 */

#define CATGEN_OPTS	"P:S:D:I:C:R:F:"
#ifdef CAT_UNIX
#define CATGEN_USAGE	"[-P portspec] [-S server] [-D debugspec]" \
			" [-R rootdir]" \
			" [-C fd]" \
			" [-I info.param=value]"
#endif
#ifdef CAT_WIN32
#define CATGEN_USAGE	"[-P portspec] [-S server]"\
 			" [-D debugspec] [-C handle] [-I info.param=value]"
#endif

extern char *catgen_opterrstring;
int catgen_getopt(int argc, char **argv, const char *opts);
int catgen_parseargs(int argc, char **argv);


/*
 * Exit codes, as expected by the control server
 */

#define CATGEN_EXIT_OK		0	/* Normal operation */
#define CATGEN_EXIT_ERROR	1	/* Failure */
#define CATGEN_EXIT_USAGE	2	/* User error */

/*
 * Misc. initialization functions.
 */

int catgen_init(void);
int catgen_initboks(void);
int catgen_initinfo(void);


/*
 * Protocol types
 */

#define CATGEN_PROTO_UNKNOWN	0	/* ? */
#define CATGEN_PROTO_DASP	1	/* DASP + BoKS */
#define CATGEN_PROTO_SSL	2	/* SSL + EAR + ELS */
#define CATGEN_PROTO_PLAIN	3	/* Plaintext, for testing */

int catgen_protocol(cat_session *sess);

/*
 * Give up protocol handshake after two minutes, regardless of what
 * the session timeout is set to.  This is an inter-packet timeout.
 */

#define CATGEN_PROTO_TIMEOUT	120

/*
 * Let all sessions time out, unless explicitly disabled (set to zero)
 * Default is two hours.
 */

#define CATGEN_SESSION_TIMEOUT	(60 * 60 * 2)

/*
 * Ports & Connections
 */

int catgen_run(void);
int catgen_listen(catgen_sessfunc *func, void *data);
int catgen_parentcmd(char *line);

int catgen_server(const char *service, int argc, char **argv,
		  catgen_sessfunc *newsession, void *data);

#ifdef CAT_WIN32
typedef int catinit_d_func(void *data);

int catgen_server_nt(const char *service, int argc, char **argv,
		     catgen_sessfunc *newsession, void *data,
		     catinit_d_func *func);

#ifdef BUILDING_CATLIBS
int
cat_init_d(catinit_info *data);
#endif
int catgen_init_nt(catinit_d_func *func);
#define catgen_server(service, argc, argv, newsession, data) \
         catgen_server_nt(service, argc, argv, newsession, data, cat_init_d)
#define catgen_init()	catgen_init_nt(cat_init_d)
#endif /* CAT_WIN32 */

/*
 * Logging
 */

#define CATGEN_LOGCODEOFFSET	1000
#define CATGEN_FACILITYCODE	800
#define CATGEN_FACILITYLABEL	"CONAGT"

#define CATLOG_CONNFAIL			(CATGEN_LOGCODEOFFSET +  0)
#define CATLOG_CERTUSERFAIL		(CATGEN_LOGCODEOFFSET +  1)
#define CATLOG_NOPAC			(CATGEN_LOGCODEOFFSET +  2)
#define CATLOG_MISSLOGID		(CATGEN_LOGCODEOFFSET +  3)
#define CATLOG_AUTHFAIL			(CATGEN_LOGCODEOFFSET +  4)
#define CATLOG_AUTHOK			(CATGEN_LOGCODEOFFSET +  5)
#define CATLOG_MAPFAIL			(CATGEN_LOGCODEOFFSET +  6)
#define CATLOG_MAPOK			(CATGEN_LOGCODEOFFSET +  7)
#define CATLOG_CERTEXPIRED		(CATGEN_LOGCODEOFFSET +  8)
#define CATLOG_CERTINVALID		(CATGEN_LOGCODEOFFSET +  9)
#define CATLOG_CERTCRITICAL		(CATGEN_LOGCODEOFFSET + 10)
#define CATLOG_CERTREVOKED		(CATGEN_LOGCODEOFFSET + 11)
#define CATLOG_CERTISSUERUNKNOWN 	(CATGEN_LOGCODEOFFSET + 12)
#define CATLOG_CERTBADSIGNATURE		(CATGEN_LOGCODEOFFSET + 13)
#define CATLOG_SERVAUTHFAIL		(CATGEN_LOGCODEOFFSET + 14)
#define CATLOG_AUTHUSEROK		(CATGEN_LOGCODEOFFSET + 15)
#define CATLOG_HOSTPSD			(CATGEN_LOGCODEOFFSET + 16)
#define CATLOG_HOSTPSDERR		(CATGEN_LOGCODEOFFSET + 17)

int catgen_log(cat_session *sess, int code);

/* @ifdef(UNSUPPORTED) */
int catgen_initlog(const char *service);
int catgen_loadloglabels(const char *facility, unsigned facility_code);
int catgen_certerrtologid(int err);
int catgen_initels(void);
int catgen_initlogfile(void);

/*
 * Tracing and reporting
 */

void catgen_warn(const char *func, int code, const char *fmt, ...);
void catgen_err(const char *func, int code, const char *fmt, ...);
int catgen_initdebug(const char *spec);


/*
 * Information
 */

int catgen_infopath(cat_session *sess, const char *service, int port);
int catgen_set(cat_session *sess, const char *name, const char *value);
int catgen_newnode(cat_session *sess, const char *name);
char *catgen_servicepath(const char *service);
int catgen_fixservice(char *service, char **version);
int catgen_getint(cat_session *sess, const char *name, int *value);

/* @endif */

/*
 * Encrypted channels, authentication, user data mapping
 */

int catgen_serverencryption(cat_session *sess);
int catgen_checkauth(cat_session *sess, const char *givenuser,
		     const char *givenpsw, const char *givendbid);
int catgen_dbmap(cat_session *sess,
		 const char *givenuser, const char *givenpsw,
		 const char *givendbid,
		 char **newuser, char **newpsw, char **newdbid);


/*
 * Misc. utilities
 */

char **catgen_vecapp(char **vec, char *str);
void catgen_vecfree(char **vec);
int catgen_mkpath(char *buf, int buflen, ...);
int catgen_newport(cat_session **sessp, const char *portspec);
int catgen_initcache(cat_session *sess, catgen_cache *cache,
		     const char *ttlpath, const char *filepath,
		     const char *limitpath);
int catgen_loadhostpsd(cat_session *sess, int defer);

#ifdef __cplusplus
}
#endif

#endif /* !_cat_gen_h */

/* Auto-generated during build. */

#ifdef _ds_build_lib_depend_
# ifndef _ds_lib_catgen
#  define _ds_lib_catgen
@@lib: catgen psd_gen bsl pac_agent nd2 md4 certlib ear_agent keypkg catinit pki_err pac_util sskc certmapkey ear_util cat ber dsc gen csf fake_ski
@@syslib: dbapi bsafe kernel32 net ber advapi32 gen pthreads
# endif
#endif
