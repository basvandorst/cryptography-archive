/*
 * @(#)$Id: platform.h,v 1.1.2.2 2000/06/06 08:28:30 elias Exp $
 *
 * Copyright � 2000 RSA Security
 *
 * Description:
 *	Platform-specific definitions.  Establishes the following
 *	macros for use within the toolkit:
 *
 *      These two are mutually exclusive:
 * 	CAT_UNIX		- Some kind of unix
 * 	CAT_WIN32		- Windows/NT (4.0 or higher)
 *
 *	Features:
 *	CAT_THREAD_SUPPORT	- Support for threads, mutexes and such
 *				  Always true on Win32.
 *	CAT_FORK_SUPPORT	- Support for forking processes.
 *				  Always true on Unix.
 *	CAT_ALWAYS_THREAD	- New sessions are always implemented as
 *				  new threads (Win32)
 *	CAT_DIRSEP		- '/' or '\\'
 */

#ifndef _cat_platform_h
#define _cat_platform_h

/*
 * Win NT
 */
#define CAT_WIN32
#undef  CAT_UNIX
#define CAT_DIRSEP	('\\')
#define CAT_THREAD_SUPPORT
#define CAT_ALWAYS_THREAD
#undef  CAT_FORK_SUPPORT



#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <winsock2.h>  
#include <time.h>
typedef SOCKET	CATSOCK;
#define cat_closesocket	closesocket

#endif
