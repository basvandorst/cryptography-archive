/*
 * @(#)$Id: version.h,v 1.7 1999/09/02 08:35:54 perre Exp $
 *
 * Copyright � 1998 Security Dynamics
 * This is unpublished proprietary source code.
 *
 * Description:
 *
 *	SecurSight Connect Agent Toolkit.
 *
 *	This file contains all version identifiers and configuration
 *	paths needed by connect agent developers.
 */

#ifndef _cat_version_h
# define _cat_version_h

/*
 * Version number of toolkit library and include files.
 */
#define CAT_VERSION_MAJOR	5
#define CAT_VERSION_MINOR	0

#define CAT_XWSL "\\"		/* Windows registry key separator */
#define	CAT_REG_COMPANY		"Security Dynamics"
#define	CAT_REG_PRODUCT		"Agents"

/*
 * Root path under HKEY_LOCAL_MACHINE where geninit() and friends
 * expects to find all configuration parameters.
 * CAT_WREG_* is to be used with Microsofts RegOpenKey() interface.
 */
#define	CAT_WREG_ROOT		"SOFTWARE" CAT_XWSL CAT_REG_COMPANY \
					CAT_XWSL CAT_REG_PRODUCT


/*
 * Various subkeys under CAT_REG_ROOT
 */
#define	CAT_WREG_BOKS		CAT_XWSL "Common" CAT_XWSL "BoKS"
#define	CAT_WREG_HOSTPSD	CAT_XWSL "Common" CAT_XWSL "HostPSD"
#define	CAT_WREG_GLOBAL		CAT_XWSL "Global"
#define	CAT_WREG_SERVICES	CAT_XWSL "Services"
#define	CAT_WREG_TCP		CAT_XWSL "Tcp"

/*
 * Default NT install directories
 */

#define CAT_WDIR_APP		"C:\\Program Files\\" CAT_REG_COMPANY \
				"\\" CAT_REG_PRODUCT
#define CAT_WDIR_BIN		CAT_WDIR_APP "\\bin"
#define CAT_WDIR_ETC		CAT_WDIR_APP "\\etc"
#define CAT_WDIR_VAR		CAT_WDIR_APP "\\var"

/*
 * Default unix directories
 */

#define CAT_UDIR_APP		"/opt/SDTI/Agents"
#define CAT_UDIR_BIN		CAT_UDIR_APP "/bin"
#define CAT_UDIR_ETC		"/etc" CAT_UDIR_APP
#define CAT_UDIR_VAR		"/var" CAT_UDIR_APP
#define CAT_UDIR_SOCK		"/tmp/.catsock"

#ifdef WIN32
# define CAT_DIR_APP		CAT_WDIR_APP
# define CAT_DIR_BIN		CAT_WDIR_BIN
# define CAT_DIR_ETC		CAT_WDIR_ETC
# define CAT_DIR_VAR		CAT_WDIR_VAR
# define SERVICE_NAME		"sdti_catd"
# define PIPE_NAME		"\\\\.\\pipe\\" SERVICE_NAME
# define SERVICE_NAME_LONG	"Keon Agent Port Manager"
#else
# define CAT_DIR_APP		CAT_UDIR_APP
# define CAT_DIR_BIN		CAT_UDIR_BIN
# define CAT_DIR_ETC		CAT_UDIR_ETC
# define CAT_DIR_VAR		CAT_UDIR_VAR
#endif

#endif /* _cat_version_h */
