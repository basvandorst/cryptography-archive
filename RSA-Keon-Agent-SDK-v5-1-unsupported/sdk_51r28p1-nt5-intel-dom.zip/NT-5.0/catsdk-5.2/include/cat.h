/*
 * @(#)$Id: cat.h,v 1.42 2000/02/07 09:37:49 elias Exp $
 *
 * Copyright � 1998 Security Dynamics
 * Copyright � 1999, 2000 RSA Security
 *
 * Description:
 *
 *  Agent Toolkit interface.
 */

#ifndef _cat_cat_h
#define _cat_cat_h

#ifndef _cat_platform_h
# include <cat/platform.h>
#endif

#ifndef _cat_version_h
# include <cat/version.h>
#endif

#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef FALSE
#  define FALSE	0
#endif
#ifndef TRUE
#  define TRUE	1
#endif

#define CAT_MAX_FILTERNAME	32
#define	CAT_DEFAULT_SIZE	-1

/* File descriptor bits */
#define CAT_CLIENT_RFD	      0x01
#define CAT_CLIENT_WFD	      0x02
#define CAT_SERVER_RFD	      0x04
#define CAT_SERVER_WFD	      0x08
#define CAT_NFDS		 4
#define CAT_CLOSED	      0x10
#define CAT_CONNECTED	      0x20
#define CAT_LISTEN	      0x40
#define CAT_PASSFD	      0x80

#define CAT_RFD		      (CAT_CLIENT_RFD | CAT_SERVER_RFD)
#define CAT_WFD		      (CAT_CLIENT_WFD | CAT_SERVER_WFD)

/* Error types */
#define	CAT_FATAL		1
#define CAT_ERROR		2
#define	CAT_WARNING		3
#define	CAT_DEBUG		4

/* Return codes */
#define	CAT_OK			0
#define	CAT_EINTERNAL		-1	/* Internal toolkit error */
#define	CAT_ENOMEM		-2	/* Out of memory */
#define	CAT_ENOMORE		-3	/* No more entries */
#define	CAT_ENOTFOUND		-4	/* Not found */
#define CAT_EAGAIN		-5	/* Retryable error */
#define CAT_EOF			-6	/* End of data stream */
#define CAT_EINVAL		-7	/* Invalid argument */
#define CAT_EBUSY		-8	/* Object in use */
#define CAT_ENOTSUPP		-9	/* Not supported by implementation */
#define CAT_EOVERFLOW	       -10	/* Value out of range */
#define CAT_ETIMEDOUT	       -11	/* Timeout */
#define CAT_ESYS	       -12	/* System error */
#define CAT_ECONNREFUSED       -13	/* Connection refused  */
#define CAT_EACCES	       -14	/* Permission denied */
#define CAT_EFTYPE	       -15	/* Invalid data type or file format */
#define CAT_ECRYPT	       -16	/* Cryptographic operation failed */
#define CAT_EPASSWD	       -17	/* Password incorrect */
#define CAT_ECERTEXPIRED       -18	/* Certificate expired */
#define CAT_ECERTINVALID       -19	/* Certificate invalid */
#define CAT_EINPROGRESS	       -20	/* Connection in progress */
#define CAT_EBADADDR	       -21	/* Invalid network address */
#define CAT_EPROTO  	       -22	/* Protocol error */
#define CAT_ENOTREADY	       -23	/* Not ready */
#define CAT_ECONFIG	       -24	/* Configuration error */
#define CAT_ECERTCRITICAL      -25	/* Critical extension not supported */
#define CAT_ECERTREVOKED       -26	/* Certificate revoked */
#define CAT_EISSUERUNKNOWN     -27	/* Certificate issuer not trusted */
#define CAT_ECERTBADSIGNATURE  -28	/* Invalid certificate signature */
#define CAT_ECERTBADKEYUSAGE   -29	/* Invalid certificate keyusage */
#define CAT_ENODE              -30      /* Tried to get value from a node */
#define CAT_ENOPARENT          -31      /* Has no parent */

#define CAT_POP_FILTER	      -100	/* Pop this filter */
#define CAT_MORE_DATA	      -101	/* Filter may have more data */
#define CAT_UNMANAGE	      -102	/* Unlink session from catsock_run() */
#define CAT_CONTINUE	      -103	/* Continue normal operation */

#define	CATSOCK_CLIENT_READ	CAT_CLIENT_RFD /* Data form client */
#define	CATSOCK_CLIENT_CONNECT	CAT_CLIENT_WFD /* Client connect ready */
#define	CATSOCK_SERVER_READ	CAT_SERVER_RFD /* Data from server */
#define	CATSOCK_SERVER_CONNECT	CAT_SERVER_WFD /* Server connect ready */
/* Only if added with CATSOCK_LISTEN: */
#define	CATSOCK_LISTEN		0x0010	/* In listener: new connection */
/* Only if added with CATSOCK_INIT: */
#define	CATSOCK_FORK		0x0020	/* In child: startup */
#define	CATSOCK_THREAD		0x0040	/* In thread: startup */
#define CATSOCK_INIT		0x0080	/* In polling session: startup */
#define CATSOCK_PARENT		0x0100	/* In parent: child created */
#define CATSOCK_POLL		0x0200	/* Explicitly request polled session */

#ifdef CAT_UNIX
# define CATSOCK_INVALID	(-1)
# define CATSOCK_ERROR		(-1)
#endif
#ifdef CAT_WIN32
# define CATSOCK_INVALID	INVALID_SOCKET
# define CATSOCK_ERROR		SOCKET_ERROR
#endif

typedef struct cat_buffer cat_buffer;
typedef struct _cat_bufblock _cat_bufblock;
typedef struct cat_filter cat_filter;
typedef struct cat_session cat_session;

typedef struct cat_iohandler cat_iohandler;
typedef void cat_freefunc(void *);
typedef void caterr_func(int major_code, int retval, const char *message);
typedef void cat_statusfunc(cat_session *session, cat_buffer *buffer);

struct cat_data {			/* Should be cat_datum, but people */
    int len;				/* seem to have a problem with that */
    char *data;
};
typedef struct cat_data cat_data;

struct _cat_bufblock {			/* Private - do not access! */
    _cat_bufblock *next;		/* Chain link */
    unsigned char *data;		/* Memory chunk */
    unsigned char *ptr;			/* Pointer to start of data in chunk */
    int total;				/* Total size of allocated chunk */
    int len;				/* Length of data in chunk */
    unsigned short flags;
};

struct cat_buffer {			/* Private - do not access! */
    _cat_bufblock *data;		/* Start of chain */
    _cat_bufblock *curr;		/* Current block */
    cat_session *sess;			/* Session it belongs to */
    int (*more)(struct cat_buffer *);	/* For catbuf_ch() */
    int off;				/* Current offset in current block */
    int len;				/* Total length of data in chain */
    int idx;				/* Current index */
};

struct cat_filter {
    char name[CAT_MAX_FILTERNAME];
    int fd_ids;
    int (*init)(cat_session *session, cat_filter *filter);
    int (*rw)(cat_session *session, cat_filter *filter, int fd);
    void (*free)(cat_session *session, cat_filter *filter);
    void *filterdata;
};

struct cat_iohandler {
    int (*init)(cat_session *sess, void **handle);
    int (*free)(cat_session *sess, void *handle);
    int (*read)(cat_session *sess, void *handle, int fd_id);
    int (*write)(cat_session *sess, void *handle, int fd_id);
    int (*setlen)(cat_session *sess, void *handle, int readlen);
    int (*poll)(cat_session *sess, void *handle, int fd_ids, int mseconds);
    int (*close)(cat_session *sess, void *handle, int fd_id);
};

#define CATINIT_MAJOR		CAT_VERSION_MAJOR
#define CATINIT_MINOR		CAT_VERSION_MINOR

#define CATINIT_NOSIGHANDLERS	0x01	/* Do not handle SIGPIPE, SIGPOLL */
#define CATINIT_NOLOCALE	0x02	/* Do not set locale to "C" */

typedef struct catinit_info {
    int size;
    int flags;
    int major;
    int minor;
} catinit_info;

#ifndef BUILDING_CATLIBS
# define cat_init  cat_init_d
#endif
int cat_init(catinit_info *info);


/* Utility functions */
void *cat_realloc(void *ptr, unsigned size, const char *func);
void *cat_alloc(unsigned size, const char *func);
void cat_free(void *ptr);


/* Sessions */
typedef void cat_closefunc(cat_session *, void *);

cat_session *cat_newsession(void);
int cat_onclose(cat_session *sess, cat_closefunc *func, void *data);
int cat_newdatakey(void);
int cat_setsessdata(cat_session *sess, int key,
		    void *data, cat_freefunc *freefun);
void *cat_getsessdata(cat_session *sess, int key);
int cat_close(cat_session *session);

/* Filter stacks & I/O */
int cat_peekfilter(cat_session *session, int level, cat_filter *filter);
int cat_runsingle(cat_session *session);
int cat_installiohandler(cat_session *session, const cat_iohandler *h,
			  void *handle);
int cat_queryiohandler(cat_session *sess, cat_iohandler **h, void **handle);
int cat_poll(cat_session *session, int fd_ids, int mseconds);
int cat_getsessid(cat_session *sess);
int cat_setreadlength(cat_session *sess, int len);
int cat_recv(cat_session *session, int fd_id, cat_buffer **bufferp);
int cat_send(cat_session *session, int fd_id, cat_buffer *buffer);
int cat_pushfilter(cat_session *session, const cat_filter *filter);
int cat_popfilter(cat_session *session);


/* Buffers */
#define catbuf_ch(b)		((b)->off < (b)->curr->len \
				 ? (b)->curr->ptr[(b)->idx++, (b)->off++] \
				 : (b)->more(b))
#define catbuf_len(b)		((b)->len)
#define catbuf_pos(b)		((b)->idx)
#define catbuf_delete(b, off, len) catbuf_extract((b), (off), (len), NULL)
#define catbuf_append(b, len, data) \
	catbuf_insert((b), catbuf_len(b), (len), (data))

cat_buffer *catbuf_get(cat_session *s, int fd);
int catbuf_put(cat_session *s, int fd, cat_buffer *b);
int catbuf_index(cat_buffer *b, int offset);
int catbuf_match(cat_buffer *b, const void *data, int datalen);
int catbuf_scan(cat_buffer *b, const void *matchbytes, int nbytes);
int catbuf_extract(cat_buffer *b, int offset, int length, void *outbuf);
int catbuf_insert(cat_buffer *b, int offset, int length, const void *indata);
int catbuf_overwrite(cat_buffer *b, int pos, int length, const void *data);
int catbuf_copy(cat_buffer *b, int pos, int length, void *outbuf);
cat_buffer *catbuf_new(cat_session *session, int length, void *data);
void catbuf_free(cat_buffer *b);
cat_buffer *catbuf_split(cat_buffer *b, int offset);
cat_buffer *catbuf_join(cat_buffer *b, cat_buffer *b2);
cat_buffer *catbuf_dup(cat_session *sess, cat_buffer *buf);
int catbuf_block(cat_buffer *b, unsigned char **block);


/* Network functions */
#define CATNET_LOOPBACKADDR	"127.0.0.1"
#define CATNET_ADDRLEN		16

typedef struct catnet_info {
    CATSOCK fd;
    int my_port;
    int peer_port;
    char my_addr[CATNET_ADDRLEN];
    char peer_addr[CATNET_ADDRLEN];
} catnet_info;

int catnet_getnetinfo(cat_session *session, int fd_id,
		      catnet_info *netinfo);

typedef int catsock_eventfunc(cat_session *sess, int event,
			      int *flagsp, void *data);
typedef int catnet_sessfunc(cat_session *sess, const char *port);

int catnet_setfd(cat_session *session, int fd_ids, CATSOCK sock);
int catnet_getfd(cat_session *session, int id, CATSOCK *sock);
int catnet_listener(const char *ports[], catnet_sessfunc *newsession);
int catnet_listen(cat_session *lsess, const char *port);
int catnet_accept(cat_session *lsess, cat_session **newsess, int fd_ids);
int catnet_connect(cat_session *session, const char *dest, int fd_ids);
int catnet_settimeout(cat_session *session, int mseconds);
int catnet_setdelay(cat_session *sess, int fd_ids, int nodelay_fds);
const cat_iohandler *catnet_iohandler(int *error);
CATSOCK catsock_fromstring(const char *str);

typedef int catsock_parentfunc(char *);

int catsock_run(int timeout, int lifespan);
int catsock_add(cat_session *sess, int flags, catsock_eventfunc *eventfn);
int catsock_enablefds(cat_session *sess, int fd_ids);
int catsock_disablefds(cat_session *sess, int fd_ids);
int catsock_parent(catsock_parentfunc *func, void *data);
int catsock_modes(void);

/* Error handling */
extern caterr_func *_CAT_DEFAULT_ERRFUNC;

#define CAT_DEFAULT_ERRFUNC	((caterr_func *)_CAT_DEFAULT_ERRFUNC)
#define CAT_GLOBAL_ERRFUNC	NULL
#define CAT_DEBUGPREFIX		"%p %n[%s] %f: "
#define CAT_DEBUGTIMEPREFIX	"%p %n[%s] +%t %f: "
#define CATERR_BUFSIZE		2048

caterr_func *caterr_setfunc(caterr_func *func);
void caterr_setprogname(const char *argv0);
void caterr_setprefix(const char *prefix);
void caterr_setdebug(const char *spec);
const char *caterr_str(int retval);
const char *caterr_name(int retval);
const char *caterr_typestr(int major);
void caterr_setfile(const char *filename);

#ifdef CAT_UNIX
extern int cat_debuglevel;
#endif

#ifdef CAT_WIN32
extern int *___cat_debuglevel();
# define cat_debuglevel (*(___cat_debuglevel()))
#endif

#ifdef CAT_NODEBUG
# define CAT_IFDBG(LVL, LABEL)	0
# define CAT_DODBG(LVL, LABEL, CODE)
# define CAT_DBG(LVL, CODE)
#else
# ifdef CAT_WIN32
#  define CAT_IFDBG(LVL, LABEL)	caterr_ifdebug((LVL), (LABEL))
# else
#  define CAT_IFDBG(LVL, LABEL)	\
	(cat_debuglevel >= (LVL) && caterr_ifdebug((LVL), (LABEL)))
# endif /* CAT_WIN32 */
# define CAT_DODBG(LVL, LABEL, CODE) \
	    do {if (CAT_IFDBG((LVL), (LABEL))) CODE ;} while (0)
# define CAT_DBG(LVL, CODE) \
	    do {if (cat_debuglevel >= (LVL)) CODE ;} while (0)
#endif

/*
 * Usage: DEBUG<N>((sess, function_name, fmt, ...))
 */

#define CAT_DEBUG1(ARGS)	  CAT_DBG(1, caterr_debug ARGS )
#define CAT_DEBUG2(ARGS)	  CAT_DBG(2, caterr_debug ARGS )
#define CAT_DEBUG3(ARGS)	  CAT_DBG(3, caterr_debug ARGS )
#define CAT_DEBUG4(ARGS)	  CAT_DBG(4, caterr_debug ARGS )
#define CAT_DEBUG5(ARGS)	  CAT_DBG(5, caterr_debug ARGS )

void caterr_verror(cat_session *sess, const char *function,
		   int major_code, int retval, const char *fmt, va_list ap);
void caterr_error(cat_session *sess, const char *function,
		  int major_code, int retval, const char *fmt, ...);
void caterr_debug(cat_session *sess,
		  const char *function, const char *fmt, ...);
int caterr_ifdebug(int level, const char *label);
int caterr_mapsys(int syserr);

/* Information retrieval */
#define CATINFO_FILE     0
#define CATINFO_DIR      1
#define CATINFO_REGISTRY 2

typedef int (*catinfo_fun)(char *, char *, void *);
int catinfo_init(int do_conf);
int catinfo_setpath(cat_session *sess, char **vec);
int catinfo_loadfrom(const char *node, const char *path, int type);
int catinfo_newnode(const char *node);
int catinfo_set(const char *name, const char *value);
int catinfo_get(cat_session *sess, const char *name, char **result);
int catinfo_getbypath(const char **path, const char *name, char **result);
int catinfo_foreach(char *name, catinfo_fun fun, void *data);
char *catinfo_name(char *name);

/* PAC and EAR utilities  */

#define CATEAR_MUST_MATCH	0
#define CATEAR_NEED_NOT_EXIST	1

typedef struct catpac_ear catpac_ear;
typedef struct catear_ear catear_ear;
typedef struct catear_finddata {
    char *name;
    char *val;
    int vallen;
    int flag;
} catear_finddata;

typedef int (*catear_iterfun)(catear_ear *ee, const char *var, void *data);

int catpac_openears(cat_session *sess, catpac_ear **ep, const char *service,
		    const char *version, const char *method);
int catpac_closeear(catpac_ear *ep);
int catear_findnext(catpac_ear *ep, catear_ear **ee, ...);
int catear_afindnext(catpac_ear *ep, catear_ear **ee,
		     const catear_finddata *vec, int veclen);
int catear_vfindnext(catpac_ear *ep, catear_ear **ee, va_list ap);
int catear_getdata(catear_ear *ee, const char *var, char **value);
int catear_iterate(catear_ear *ee, catear_iterfun fun, void *data);
int catear_rewind(catpac_ear *ep);
int catear_dbmap(catpac_ear *ep,
		 const char *givenuser, const char *givenpsw,
		 const char *givendbid,
		 char **newuser, char **newpsw, char **newdbid);
int catear_getlogid(catpac_ear *ep, char **logid);


/* PSDs */
typedef struct cat_psd cat_psd;

#define CATPSD_DEFEROPEN	0x01
#define CATPSD_BOKSPSD		0x02
#define CATPSD_CLOSE		0x04
#define CATPSD_ISOPEN	    0x010000	/* XXX -> Private! */
#define CATPSD_ANYPSD	    0x020000	/* XXX -> Private! */
#define CATPSD_NOCOPY	    0x040000	/* XXX -> Private! */

int catpsd_openpsd(const char *b64psd, cat_psd **psd,
		   const char *pin, int flags);
int catpsd_closepsd(cat_psd *psd);
int catpsd_getcert(cat_psd *psd, cat_data *certificate);
int catpsd_setpac(cat_psd *psd, const cat_data *pac);
int catpsd_setpsd(cat_session *sess, cat_psd *psd, int flags);
cat_psd *catpsd_getpsd(cat_session *sess);

/* Session resumption & key cache database calllback */

#define CATDB_PUT		1
#define CATDB_GET		2
#define CATDB_DEL		3
#define CATDB_CHECK		4

typedef struct catdb_data {
    cat_data key;
    cat_data value;
} catdb_data;

typedef int catdb_func(int, catdb_data *, void *);


/* SSL */

#define CAT_STRONG_CIPHERS	0x01
#define CAT_EXPORT_CIPHERS	0x02
#define	CAT_NULL_CIPHER	0x04
#define CAT_REQUIRE_CIPHERS	0x08
#define CAT_DEFAULT_CIPHERS	(CAT_STRONG_CIPHERS | CAT_EXPORT_CIPHERS)

/* Values for catssl_setattributes()  */

#define CATSSL_NO_CLIENTAUTH     0x01
#define CATSSL_IGNORE_SERVERAUTH 0x02
#define CATSSL_SKIP_CERTCHAIN    0x04

typedef struct catssl_info catssl_info;

catssl_info *catssl_newinfo(void);
void catssl_freeinfo(catssl_info *info);
int catssl_setciphers(catssl_info *info, int ciphermask);
int catssl_setattributes(catssl_info *info, int attributes);
int catssl_serverhandshake(cat_session *sess, catssl_info *info, int fd_ids);
int catssl_clienthandshake(cat_session *sess, catssl_info *info, int fd_ids);
int catssl_setdb(catssl_info *info, catdb_func *func, void *handle);


/* Certificates */
typedef struct cat_cert cat_cert;

/*
 * Key usage bit patterns
 */
#define CAT_DIGITALSIGNATURE_KEYUSAGE 0x01
#define CAT_KEYAGREEMENT_KEYUSAGE     0x02
#define CAT_KEYENCIPHERMENT_KEYUSAGE  0x04
#define CAT_KEYCERTSIGN_KEYUSAGE      0x08
#define CAT_IGNORE_KEYUSAGE           0xff

#define CATCERT_VERIFY_LOCAL		1
#define CATCERT_VERIFY_BOKS		2

typedef int cat_keylengthfunc(cat_session *sess);
typedef int cat_getcertfunc(cat_session *sess, cat_data *cert);
typedef int cat_checkcertfunc(cat_session *sess, int keyUsage);
typedef int cat_privkeyfunc(cat_session *sess,
			    const cat_data *in, cat_data *out);

int catcert_setchecktype(cat_session *sess, int type);
int catcert_setpeercert(cat_session *sess,
			const cat_data *certlist, int num_certs);

int catcert_getcert(cat_session *sess, cat_data *mycert);
int catcert_getpeercert(cat_session *sess, cat_data *certlist, int ncerts);
int catcert_setdb(cat_session *sess, catdb_func *func, void *handle);
int catcert_setcafile(const char *path);
void catcert_free(cat_cert *cert);
int catcert_parse(const cat_data *codedcert, cat_cert **cert);
int catcert_subjectname(const cat_cert *cert, char **subjName);
int catcert_issuername(const cat_cert *cert, char **issName);
int catcert_issuername_boks(const cat_cert *cert, char **issName);
int catcert_dumperror(cat_session *sess, char *file);
int catcert_publickey(const cat_cert *cert, cat_data *key);
int catcert_publickey_alg(const cat_cert *cert, cat_data *alg);

#ifdef __cplusplus
}
#endif

#endif /* !_cat_cat_h */

/* Auto-generated during build. */

#ifdef _ds_build_lib_depend_
# ifndef _ds_lib_cat
#  define _ds_lib_cat
@@lib: cat psd_gen bsl pac_agent nd2 certlib md4 ear_agent keypkg pki_err pac_util sskc certmapkey ear_util ber gen dsc csf fake_ski
@@syslib: dbapi bsafe kernel32 net ber advapi32 gen pthreads
# endif
#endif
