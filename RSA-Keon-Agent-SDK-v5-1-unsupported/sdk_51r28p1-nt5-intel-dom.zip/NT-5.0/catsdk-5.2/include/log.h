/*
 * @(#)$Id: log.h,v 1.6 1999/06/24 10:32:47 gosta Exp $
 *
 * Copyright � 1998 Security Dynamics
 * This is unpublished proprietary source code.
 *
 * Description:	Functions for logging.
 *
 *		Requires <cat/cat.h>
 */

#ifndef _cat_log_h
#define _cat_log_h

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Bake an ELS log code, given facility code, severity ('I', 'W', 'E' or 'F')
 * and a message number.
 */

#define CATLOG_SVTY(S)	\
	((S) < 'I' ? ((S) == 'F' ? 3 : 2) : ((S) == 'W' ? 1 : 0))
#define CATLOG_CODE(F, S, M) \
	(((F) << 20) | ((CATLOG_SVTY(S)) << 16) | (M))


/*
 * Commands to the log formatting functions
 */

#define CATLOG_INIT	1	/* Initialize new record */
#define CATLOG_STRING	2	/* Fixed string */
#define CATLOG_VALUE	3	/* Parameter */
#define CATLOG_END	4	/* End of record */
#define CATLOG_FAIL	5	/* Abort */

/*
 * Parameter constants.
 *
 * These have the same values as SD_ELS_<paramname>
 * from "ds_els.h"
 */

#define CATLOG_USERNAME		1001
#define CATLOG_LOGINNAME	1002
#define CATLOG_HOSTNAME		1003
#define CATLOG_CLIENTNAME	1004
#define CATLOG_TOKENSN		1005
#define CATLOG_GROUPNAME	1006
#define CATLOG_SITENAME		1007
#define CATLOG_REALMNAME	1008
#define CATLOG_VENDORNAME	1009

#define CATLOG_PARAM1	        1011
#define CATLOG_PARAM2	        1012
#define CATLOG_PARAM3	        1013
#define CATLOG_PARAM4	        1014
#define CATLOG_PARAM5	        1015
#define CATLOG_PARAM6	        1016
#define CATLOG_PARAM7	        1017
#define CATLOG_PARAM8	        1018
#define CATLOG_PARAM9	        1019

/*
 * More parameter constants, CAT specific (for use with
 * catlog_{set,get}() only.
 */

#define CATLOG_FACILITY		   0
#define CATLOG_SERVICE		   1

typedef struct catels_arg {
    int tag;
    char *value;
} catels_arg;

typedef struct catlog_dispatcher catlog_dispatcher;

typedef int catlog_sendfunc(catlog_dispatcher *, cat_buffer *);

typedef int catlog_func(cat_session *sess, int op,
			const char *str, unsigned len,
			const char *value, catlog_dispatcher *dp, void *data);

typedef int catlog_mklabelfunc(const char *facility, const char *lbl,
			       unsigned code, const char *description);


#define CATLOG_FLUSH	1	/* Process queue once, then return */
#define CATLOG_DONTSTOP	2	/* Be very persistent */
#define CATLOG_PURGE	4	/* Weed out null entries (use with care!) */
#define CATLOG_DONTTHREAD 8	/* If possible, start a subprocess */
#define CATLOG_DONTVERIFYSERVER 16 /* Dont verify server certificate */

#define CATLOG_MAXARGS	16

struct catlog_dispatcher {
    int flags;			/* See above */
    char *argv[CATLOG_MAXARGS];	/* Additional arguments to program */
    int type;			/* 0, 'E' or 'B' */
    char *filename;		/* Queue file */
    catlog_sendfunc *sendfunc;	/* Queue -> Network */
    catlog_func *formatfunc;	/* Logger function */
    void *data;			/* sendfunc private data */
    time_t started;
    cat_session *sess;
    int (*free)(catlog_dispatcher *);
};

#define catlog_setflush(D, ON)	 ((ON) ? ((D)->flags |= CATLOG_FLUSH) \
				      : ((D)->flags &= ~CATLOG_FLUSH))
#define catlog_setsleep(D, P, F) ((D)->pollsleep=(P), (D)->failsleep=(F))

void catlog_freedispatcher(catlog_dispatcher *dp);
int catlog_mklabel(const char *facility, const char *lbl,
		   unsigned code, const char *description);
int catlog_set(cat_session *sess, int what, const char *value);
int catlog_setdispatcher(cat_session *sess, catlog_dispatcher *dp);
const char *catlog_get(cat_session *sess, int what);
int catlog_vevent(cat_session *sess, const char *label, ...);
int catlog_event(cat_session *sess, const char *label, const char **params);

int catboks_loginit(char *filename, catlog_dispatcher **dp);
int catels_loginit(const char *filename,
		   const char **servers, catlog_dispatcher **dp);
int catlog_initlocalfile(char *filename, catlog_dispatcher **dp);

int catels_param(int c);
int catlog_queue(cat_buffer *buf, catlog_dispatcher *dp);
int catlog_loadspecfile(const char *filename, catlog_mklabelfunc *func);
int catlog_sendlogfile(catlog_dispatcher *dp,
		       int pollsleep, int failsleep, int maxidle);

FILE *catlog_fopen(const char *name);
int catlog_fclose(FILE *f);
int catlog_flock(FILE *f, int setlock);

cat_buffer *catels_startpacket(unsigned long id,
			       int nargs, const catels_arg *args);
int catels_completepacket(cat_buffer *buf, unsigned seqno);

#ifdef __cplusplus
}
#endif

#endif /* !_cat_log_h */
