/*
 * @(#)$Id: catmutex.h,v 1.3 2000/01/13 16:29:02 mikko Exp $
 *
 * Copyright � 1998 Security Dynamics
 * This is unpublished proprietary source code.
 *
 * Description: Basic portable thread synchronization primitives.
 *		Supplies mutexes and condition variables, with
 *		a subset of pthreads semantics (no return values, and
 *		all arguments are sent as addresses).
 *
 */

#ifndef _cat_catmutex_h
# define _cat_catmutex_h

#ifdef CAT_UNIX
# ifdef CAT_THREAD_SUPPORT
#  include <pthread.h>

typedef pthread_mutex_t			CATMUTEX;
typedef pthread_cond_t  		CATCOND;
typedef pthread_t			CATTHREAD;

#  define catmutex_native(m)		(m)
#  define catmutex_cond_native(C)	(C)
#  define _catmutex_init(m)		(void)pthread_mutex_init((m), NULL)
#  define _catmutex_free(m)		(void)pthread_mutex_destroy(m)
#  define _catmutex_lock(m)		(void)pthread_mutex_lock(m)
#  define _catmutex_unlock(m)		(void)pthread_mutex_unlock(m)
#  define _catmutex_cond_init(C)	(void)pthread_cond_init((C), NULL)
#  define _catmutex_cond_free(C)	(void)pthread_cond_destroy(C)
#  define _catmutex_cond_signal(C)	(void)pthread_cond_broadcast(C)
#  define _catmutex_cond_wait(C, M)	(void)pthread_cond_wait(C, M)

#  define catthread_equal(T0, T1)	pthread_equal((T0), (T1))
#  define catthread_self()		pthread_self()
# endif /* CAT_THREAD_SUPPORT */
#endif /* CAT_UNIX */

#ifdef CAT_WIN32
/* Implies thread support */

typedef CRITICAL_SECTION		CATMUTEX;
typedef HANDLE				CATCOND;
typedef DWORD				CATTHREAD;

# define catmutex_native(m)		(m)
# define catmutex_cond_native(C)	(C)
# define _catmutex_init(m)		InitializeCriticalSection(m)
# define _catmutex_free(m)		DeleteCriticalSection(m)
# define _catmutex_cond_init(C)		do {\
    *(C) = CreateEvent(NULL, TRUE, FALSE, NULL); \
} while (0)
# define _catmutex_cond_free(C)		(void)CloseHandle(*(C))
# define _catmutex_lock(m)		EnterCriticalSection(m)
# define _catmutex_unlock(m)		LeaveCriticalSection(m)
# define _catmutex_cond_signal(C)	(void)SetEvent(*(C))
# define _catmutex_cond_wait(C, M) do { 		\
    CATCOND *__c = (C);				\
    CATMUTEX *__m = (M);			\
						\
    ResetEvent(*__c); 				\
    LeaveCriticalSection(__m);			\
    WaitForSingleObject(*__c, INFINITE);	\
    EnterCriticalSection(__m);			\
} while (0)

# define catthread_equal(T0, T1)	((T0) == (T1))
# define catthread_self()		GetCurrentThreadId()
#endif /* CAT_WIN32 */

#ifdef CAT_THREAD_SUPPORT

/*
 * Debugging is only supported for mutexes used inside the library
 * itself.
 */

# if defined(CAT_MUTEX_DEBUG) && defined(DS_DEBUG)

#  define catmutex_init(m)	\
    catmutex_debug_init((m), #m, __LINE__, __FILE__)
#  define catmutex_free(m)	\
    catmutex_debug_free((m), #m, __LINE__, __FILE__)
#  define catmutex_lock(m)	\
    catmutex_debug_lock((m), #m, __LINE__, __FILE__)
#  define catmutex_unlock(m)	 \
    catmutex_debug_unlock((m), #m, __LINE__, __FILE__)
#  define catmutex_cond_init(C)	 \
    catmutex_debug_cond_init((C), #C, __LINE__, __FILE__)
#  define catmutex_cond_free(C)	 \
    catmutex_debug_cond_free((C), #C, __LINE__, __FILE__)
#  define catmutex_cond_signal(C)\
    catmutex_debug_cond_signal((C), #C, __LINE__, __FILE__)
#  define catmutex_cond_wait(C, M)\
    catmutex_debug_cond_wait((C), (M), #M, __LINE__, __FILE__)

void catmutex_debug_init(CATMUTEX *m, const char *, int, const char *);
void catmutex_debug_free(CATMUTEX *m, const char *, int, const char *);
void catmutex_debug_lock(CATMUTEX *m, const char *, int, const char *);
void catmutex_debug_unlock(CATMUTEX *m, const char *, int, const char *);
void catmutex_debug_cond_init(CATCOND *c, const char *, int, const char *);
void catmutex_debug_cond_free(CATCOND *c, const char *, int, const char *);
void catmutex_debug_cond_signal(CATCOND *c, const char *, int, const char *);
void catmutex_debug_cond_wait(CATCOND *c, CATMUTEX *m,
			      const char *, int, const char *);

# else

#  define catmutex_init(m)		 _catmutex_init(m)
#  define catmutex_free(m)		 _catmutex_free(m)
#  define catmutex_lock(m)		 _catmutex_lock(m)
#  define catmutex_unlock(m)	 	 _catmutex_unlock(m)
#  define catmutex_cond_init(C)	 	 _catmutex_cond_init(C)
#  define catmutex_cond_free(C)	 	 _catmutex_cond_free(C)
#  define catmutex_cond_signal(C)	 _catmutex_cond_signal(C)
#  define catmutex_cond_wait(C, M)	 _catmutex_cond_wait((C), (M))

# endif /* CAT_MUTEX_DEBUG && DS_DEBUG */

#else

typedef char CATMUTEX;
typedef char CATCOND;
typedef char CATTHREAD;

# define catmutex_native(m)		(m)
# define catmutex_cond_native(C)	(C)
# define catmutex_init(m)
# define catmutex_free(m)
# define catmutex_lock(m)
# define catmutex_unlock(m)
# define catmutex_cond_init(c)
# define catmutex_cond_free(c)
# define catmutex_cond_wait(c, m)
# define catmutex_cond_signal(c)

# define catthread_equal(a, b)		1
# define catthread_self()		0

#endif /* CAT_THREAD_SUPPORT */

typedef void catthread_func(void *);

int catthread_start(catthread_func *func, void *arg);
void catthread_setconcurrency(int nlwps);

#endif /* !_cat_catmutex_h */
