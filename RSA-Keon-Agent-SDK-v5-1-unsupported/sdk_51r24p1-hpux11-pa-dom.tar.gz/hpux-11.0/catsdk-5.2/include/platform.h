/*
 * @(#)$Id: platform.h,v 1.13 2000/03/16 14:45:20 mikko Exp $
 *
 * Copyright � 2000 RSA Security
 *
 * Description:
 *	Platform-specific definitions.  Establishes the following
 *	macros for use within the toolkit:
 *
 *      These two are mutually exclusive:
 * 	CAT_UNIX		- Some kind of unix
 * 	CAT_WIN32		- Windows/NT (4.0sp3)
 *
 *	Features:
 *	CAT_THREAD_SUPPORT	- Support for threads, mutexes and such
 *				  Always true on Win32.
 *	CAT_FORK_SUPPORT	- Support for forking processes.
 *				  Always true on Unix.
 *	CAT_ALWAYS_THREAD	- New sessions are always implemented as
 *				  new threads (Win32)
 *	CAT_DIRSEP		- '/' or '\\'
 */

#ifndef _cat_platform_h
# define _cat_platform_h

/*
 * Figure out what system this is.  Only works with supported
 * platforms, and even then some additional define may be needed.
 */

#undef CAT_UNIX_DEFINES

/*
 * Sun Solaris 2.6
 */

#if defined(sun) && defined(__SVR4)
# define CAT_UNIX_DEFINES
# define CAT_THREAD_SUPPORT

/*
 * AIX 4.3
 */

#elif defined(_AIX43)
# define CAT_UNIX_DEFINES
# define CAT_THREAD_SUPPORT

#elif defined(__hpux) /* __hppa,__hp9000s700,__hp9000s800 *//* HP-UX 11 */
# define CAT_UNIX_DEFINES
# define CAT_THREAD_SUPPORT

#elif defined(__FreeBSD__)	/* FreeBSD 2, 3 or 4 */
# define CAT_UNIX_DEFINES

#elif defined(__linux__)	/* Linux something (Tested on RH 6.0) */
# define CAT_UNIX_DEFINES
# define CAT_THREAD_SUPPORT

#elif defined(WIN32) || defined(_WIN32)   /* Something/Windows/NT 4.0 */
# define CAT_WIN32
# undef  CAT_UNIX
# define CAT_THREAD_SUPPORT
# define CAT_ALWAYS_THREAD
# undef  CAT_FORK_SUPPORT
# define CAT_DIRSEP	('\\')

#else
	Unsupported platform, sorry
#endif

#ifdef CAT_UNIX_DEFINES
# undef	 CAT_UNIX_DEFINES
# define CAT_UNIX
# undef  CAT_WIN32
# define CAT_FORK_SUPPORT
# undef  CAT_ALWAYS_THREAD
# define CAT_DIRSEP	('/')
#endif

#ifdef CAT_ALWAYS_THREAD
# define CAT_THREAD_SUPPORT
#endif

/*
 * Basic UNIX includes & defines
 */

#ifdef CAT_UNIX
# ifdef CAT_THREAD_SUPPORT
#  include <pthread.h>
# endif
# include <sys/types.h>
# include <errno.h>
# include <unistd.h>
# include <string.h>

typedef int	CATSOCK;
# define cat_closesocket	close

#endif /* CAT_UNIX */


/*
 * Win32 includes & defines
 */

#ifdef CAT_WIN32
#define WIN32_LEAN_AND_MEAN
# include <windows.h>
# include <winsock2.h>  
# include <time.h>

typedef SOCKET	CATSOCK;
# define cat_closesocket	closesocket

#endif /* CAT_WIN32 */

#endif /* !_cat_platform_h */
