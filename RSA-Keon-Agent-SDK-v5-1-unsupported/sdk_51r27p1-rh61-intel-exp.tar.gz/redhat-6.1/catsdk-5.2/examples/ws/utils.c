/*
 * @(#)$Header: /srcroot/Lego-CVSROOT/catagent/example_ws/utils.c,v 1.7 2000/01/24 12:34:00 elias Exp $
 *
 * Copyright (c) 2000 RSA Security
 *
 * Description:	Misc helper functions for the ws-example.
 *            
 *
 * MT-Level:    Safe
 */

#include "ws.h"

/*
 * media types with associated file extensions that we know about
 */

struct {
    char *sfx;
    char *type;
} types[] = {
    { ".html", "Content-Type:text/html\r\n" },
    { ".htm", "Content-Type:text/html\r\n" },
    { ".gif", "Content-Type:image/gif\r\n" },
    { ".jpeg", "Content-Type:image/jpeg\r\n" },
    { ".jpg", "Content-Type:image/jpeg\r\n" },
    { NULL, NULL }
};


/*
 * parse_req()
 *
 * Description:
 *    Descructively parse a request. Each out-pointer will 
 *    point to a NULL-terminated string inside the supplied 
 *    req buffer.
 *
 * Arguments:
 *    req      IN: request buffer
 *    meth    OUT: pointer to 0-terminated HTTP method
 *    uri     OUT: pointer to 0-terminated URI
 *    ver     OUT: pointer to 0-terminated HTTP version
 *    header  OUT: Pointer to the HTTP header
 *
 * Returns:
 *    HTTP Method code or < 0 on error.
 */
int
parse_req(char *req, char **meth, char **uri, char **ver, char **header)
{
    int ret;
    
    ret = WS_EBADREQ;
    *meth = req;
    if ((req = strchr(req, ' ')) == NULL) {
	return WS_EBADREQ;
    }
    *req = 0;
    *uri = ++req;
    if ((req = strchr(req, ' ')) == NULL) {
	return WS_EBADREQ;
    }
    *req = 0;
    *ver = ++req;
    if ((req = strchr(req, '\r')) == NULL) {
	return WS_EBADREQ;
    } else {
	if (*(req+1) != '\n') {
	    return WS_EBADREQ;
	}
    }
    *req = 0;
    *header = req+2;

    if (strcmp(*meth, "GET") == 0) {
	ret = GET;
    }
    if (strcmp(*meth, "HEAD") == 0) {
	ret = HEAD;
    }
    if (strcmp(*meth, "POST") == 0) {
	ret = POST;
    }
    
    return ret;
}


/*
 * uri_to_file()
 *
 * Description: 
 *    Takes the URI from the request and tries to derive a 
 *    path to a local file out of it.  This includes prepending 
 *    the local html root. The resulting path is 0-terminated.
 *
 * Arguments:
 *    uri       IN: URI
 *    pathbuf  OUT: Buffer where resulting file-path is stored. 
 *                  Must be suficiently large.
 *    bufsize  INT: Size of pathbuf
 *
 * Returns:
 *    0   OK
 *    < 0 error
 */
int
uri_to_file(char *uri, char *pathbuf, int bufsize)
{
    if (uri[0] != '/') {
	return -1;
    }
    if (uri[1] == 0) {
	Snprintf(pathbuf, bufsize, "%s%cindex.html", HTMLDIR, DIRSEP);
    } else {
	Snprintf(pathbuf, bufsize, "%s%s", HTMLDIR, uri);
    }
    return 0;
}


/*
 * file_to_mediatype()
 * 
 * Descripiton:
 *    Use the file suffix to get the media type.
 *
 * Arguments:
 *    filename  IN: the filename of the local file to fetch
 *    mediabuf OUT: pointer to an appropriate media type
 *                  header field for the file. This is a 
 *                  0 terminated string.
 *
 * Returns:
 *    Returns 0 if successful, negative code otherwise
 *
 * Note:
 *    The pointer to the media type will point into
 *    the global types array. Hence, the string must not be 
 *    freed nor modified.
 */
int
file_to_mediatype(char *filename, char **mediabuf)
{
    char *suffix;
    int i = 0;
  
    if ((suffix = strrchr(filename, '.')) == NULL) {
	return WS_EUNKNOWN;
    }
    while (types[i].sfx != NULL) {
	if (strcmp(suffix, types[i].sfx) == 0) {
#if 0
	    strncpy(mediabuf, types[i].type, buflen);
	    mediabuf[strlen(types[i].type)] = 0;
#endif
	    *mediabuf = types[i].type;
	    return 0;
	}
	i++;
    }
#if 0
    mediabuf[0] = 0;
#endif
    *mediabuf = NULL;
    return WS_ENOTFOUND;
}


/*
 * get_login_data()
 * 
 * Descripiton:
 *    Obtain the plain text versions of the user credentials
 *    sent in a request containing the "Authorization" 
 *    header field.
 *
 * Arguments:
 *    creds    IN: pointer to an Authorization header field. 
 *                 I.e. a string looking something like;
 *                 "Authorization: Basic QWxhZGRHNlc2FtZQ=="
 *    user    OUT: The allocated username. Must be freed by caller.
 *    passwd  OUT: The allocated password. Must be freed by caller.
 *
 * Returns:
 *    Returns 0 if successful, negative code otherwise
 */
int
get_login_data(char creds[], char **user, char **passwd) {
    char *type;
    char *b64;
    char *binbuf;
    char *idx;
    int binlen, passwdlen;

    if (creds == NULL || user == NULL || passwd ==NULL) {
	return WS_EINVAL;
    }
    if ((type = strchr(creds, 'B')) == NULL) {
	return -1;
    }
    if (strncmp(type, "Basic", strlen("Basic")) != 0) {
	return -1;
    }
    if ((b64 = strchr(type, ' ')) == NULL) {
	return -1;
    }
    b64++;
    if ((idx = strchr(b64, '\r')) == NULL) {
	return WS_ERROR;
    }
    *idx = 0;
    binbuf = malloc(strlen(b64));
    if ((binlen = base642bin(b64, binbuf)) <= 0) {
	free(binbuf);
	return WS_ERROR;
    }
    if ((idx = strchr(binbuf, ':')) == NULL) {
	free(binbuf);
	return WS_ERROR;
    }
    *idx = 0;
    idx++;
    *user = malloc(strlen(binbuf) + 1);
    strcpy(*user, binbuf);
    passwdlen = binlen - strlen(binbuf) - 1;
    *passwd = malloc(passwdlen + 1);
    strncpy(*passwd, idx, passwdlen);
    (*passwd)[passwdlen] = 0;
    
    free(binbuf);
    return 0;
}


/*
 * validate_login()
 * 
 * Descripiton:
 *    Validate the authorization credentials against the 
 *    "hard-wired" account (see "ws.h").
 *
 * Arguments:
 *    realm    IN: the protection realm (not used)
 *    file     IN: the requested file
 *    user     IN: Username
 *    passwd   IN: Password
 *
 * Returns:
 *    Returns 0 if successful, negative code otherwise
 */
int
validate_login(char *realm, char* file, char *user, char *passwd) 
{
    if (strcmp(user, USER) != 0) {
	return WS_EPERM;
    }
    if (strcmp(passwd, PASS) != 0) {
	return WS_EPERM;
    }
    
    return 0;
}


/*
 * is_protected()
 * 
 * Descripiton:
 *    Determine if a file is protected and return realm in 
 *    supplied buffer.
 *    The path stored in filepath is assumed to be a path 
 *    relative to the current working directory. 
 *
 * Arguments:
 *    filepath      IN: path to the file to check
 *    realm        OUT: the realm as a string
 *    realmbufsize  IN: size of supplied buffer
 *
 * Returns:
 *    0   Page is not protected
 *    1   Page is protected
 *    < 0 Error
 */
int
is_protected(char *filepath, char *realm, int realmbufsize)
{
    char *path;
    char private[] = PROTDIR;
    int  privlen, idx;
    
    idx = strlen(HTMLDIR);
    if (strncmp(filepath, HTMLDIR, idx) != 0) {
	DEBUG(("File \"%s\" not under the html root dir\n", filepath));
	return WS_ERROR;
    }
    path = &(filepath[idx]);
    if (*path != '/') {
	return 0;
    }
    path++;   
    privlen = strlen(private);
    if (strncmp(path, private, privlen) == 0 &&
	path[privlen] == '/') 
    {
	strncpy(realm, PROTREALM, realmbufsize);
	return 1;
    } else {
	return 0;
    }
}


/*
 * has_auth()
 * 
 * Descripiton:
 *    Determine if a request contains the "Authorization:"
 *    header-field and get the base64 encoded credentials.
 *
 * Arguments:
 *    buf          IN: The http header
 *    credentials OUT: Credentails from the header. 
 *                     Points inside buf.
 *
 * Returns:
 *    1 if "Authorization" was found, 0 otherwise.
 */
int
has_auth(char *buf, char **credentials)
{
    char *idx;
    char auth[] = "Authorization:";

    idx = buf;
    while((idx = strchr(idx, '\r')) != NULL) {
	if (*(++idx) != '\n') {
	    continue;
	}
	if (*(++idx) == 0) {
	    break;
	}
	if (strncmp(auth, idx, strlen(auth)) == 0) {
	    *credentials = strchr(idx, ':') + 1;
	    return 1;
	}
    }
    return 0;
}


/*
 * Below are constructors and descructors for a
 * convenience type datum.
 */
datum *
new_datum()
{
    datum *d;

    if ((d = malloc(sizeof(datum))) != NULL) {
	memset(d, 0, sizeof(datum));
    }
    return d;
}

void
free_datum(datum *d)
{
    if (d->value != NULL && d->is_dyn != 0) {
	free(d->value);
    }
    free(d);
    return;
}


/*
 * Debug function.
 */
void
debug(const char *fmt, ...) 
{
    char buf[1024];
    va_list ap;
    
    va_start(ap, fmt);
    Vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    buf[sizeof(buf)-1] = 0;
    fprintf(stderr, "%s", buf);
    
    return;
}


/*
 * readfile()
 * 
 * Descripiton:
 *    Read a file and optionally 0-terminate the result. If
 *    the file has size 0, a block of MEMBLOCKSIZE is still 
 *    allocated and must be freed by caller.
 *
 * Arguments:
 *    name       IN: The filename
 *    data      OUT: Resulting allocated data. Must be freed 
 *                   by caller
 *    zero_term  IN: Convenience flag that determines if the
 *                   read data should be 0-terminated (string) 
 *                   or not. 0 -> no zero-term, <> 0 -> zero-term
 *
 * Returns:
 *    The length of the read data or a negative code on
 *    error.
 */
int
readfile(char *name, char **data, int zero_term) {
    int ret;
    FILE *f;
    char *b, *b0;
    int nread, nreadtot;
    int size;

    ret = 0;
    nreadtot = 0;
    if ((f = fopen(name, "rb")) == NULL) {
	return WS_EACCES;
    }
    if ((b = (char *)malloc(MEMBLOCKSIZE * sizeof(char))) == NULL) {
	fclose(f);
	return WS_ENOMEM;
    }
    b0 = b;
    size = MEMBLOCKSIZE;
    
    for(;;) {
	nread = fread(&(b[nreadtot]), sizeof(char), MEMBLOCKSIZE, f);
	if (nread == 0) {
	    if (feof(f)) {
		break;
	    }
	    ret = WS_ERROR;
	    goto done;
	}
	nreadtot += nread;
	if (nread >= MEMBLOCKSIZE) {
	    size += MEMBLOCKSIZE;
	    if ((b = (char *)realloc(b, size)) == NULL) {
		ret = WS_ENOMEM;
		goto done;
	    }
	    continue;
	}
	break;
    }
    if (zero_term) {
	b[nreadtot] = 0;
    }

  done:
    fclose(f);
    if (ret < 0) {
	free(b0);
	return ret;
    }
    *data = b;
    return nreadtot;
}



static const char bin2b64tab[64] =
"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    
static const int b642bintab[128] = {
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63,
    52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1,
    -1,  0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14,
    15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1,
    -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
    41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1,
};


/*
 * base642bin()
 * 
 * Descripiton:
 *    Convert from base64 to binary.
 *
 * Arguments:
 *    in64      IN: String to convert
 *    bin      OUT: Result. Must be large enough to hold the result, 
 *                  which is shorter than the input.
 *
 * Returns:
 *    Returns the length of the result, or a negative code on 
 *    error.
 */
int
base642bin(char *in64, void *bin)
{
    unsigned char byte1, byte2, byte3, byte4;
    unsigned char *out, *b64;

    if ((bin == NULL) || (in64 == NULL)) {
        return -1;
    }

    out = bin;
    b64 = (unsigned char *)in64;
    while (b642bintab[*b64 & 0x7f] != -1) {
	byte1 = b642bintab[*b64++ & 0x7f];
	if (b642bintab[*b64 & 0x7f] == -1) {
	    return WS_EINVAL;
	}
	byte2 = b642bintab[*b64++ & 0x7f];
	if (b642bintab[*b64 & 0x7f] == -1) {
	    *out++ = (unsigned char)((byte1 << 2) + ((byte2 & 48) >> 4));
	    break;
	}
	byte3 = b642bintab[*b64++ & 0x7f];
	if (b642bintab[*b64 & 0x7f] == -1) {
	    *out++ = (unsigned char)((byte1 << 2) + ((byte2 & 48) >> 4));
            *out++ = (unsigned char)((byte2 << 4) + (byte3 >> 2));
	    break;
	}
	byte4 = b642bintab[*b64++ & 0x7f];
        *out++ = (unsigned char)((byte1 << 2) + ((byte2 & 48) >> 4));
        *out++ = (unsigned char)((byte2 << 4) + (byte3 >> 2));
        *out++ = (unsigned char)((byte3 << 6) + (byte4 & 63));
    }
    return (out - (unsigned char *)bin);
}
