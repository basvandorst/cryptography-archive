/*
 * @(#)$Id: telnet.h,v 1.5 2000/01/25 09:24:44 perre Exp $
 *
 * Copyright � 1998 Security Dynamics
 *
 * Description:
 *
 *	Setup function for telnet filter.
 *	Requires <cat/cat.h>
 */

#ifndef _cat_telnet_h
# define _cat_telnet_h

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Platform specific stuff
 */
#ifdef WIN32
#define snprintf _snprintf
#endif

/*
 * Default expect strings if non  are configured
 */

#define DEFLOGIN  "login: "
#define DEFPWD    "Password: "
#define DEFDONE   "Last login "
#define DEFINCORR "Login incorrect"
#define DEFERRMSG "Login failed (config error?).\r\nTerminating connection.\r\n"


/*
 * The telnet option negotiation command codes and
 * internal symbols for them
 */

/* telnet commands */

#define TELNET_IAC     255
#define TELNET_DONT    254
#define TELNET_DO      253
#define TELNET_WONT    252
#define TELNET_WILL    251
#define TELNET_SB      250
#define TELNET_GA      249
#define TELNET_EL      248
#define TELNET_EC      247
#define TELNET_AYT     246
#define TELNET_AO      245
#define TELNET_IP      244
#define TELNET_BREAK   243
#define TELNET_DM      242
#define TELNET_NOP     241
#define TELNET_SE      240

/* 
   #define TELNET_EOR
   #define TELNET_ABORT
   #define TELNET_SUSP
   #define TELNET_EOF
   #define TELNET_SYNCH
   */

/* telnet options */

#define TELOPT_BINARY          0
#define TELOPT_ECHO            1
#define TELOPT_RCP             2
#define TELOPT_SGA             3
#define TELOPT_NAMS            4
#define TELOPT_STATUS          5
#define TELOPT_TM              6
#define TELOPT_RCTE            7
#define TELOPT_NAOL            8
#define TELOPT_NAOP            9
#define TELOPT_NAOCRD         10
#define TELOPT_NAOHTS         11
#define TELOPT_NAOHTD         12
#define TELOPT_NAOFFD         13
#define TELOPT_NAOVTS         14
#define TELOPT_NAOVTD         15
#define TELOPT_NAOLFD         16
#define TELOPT_XASCII         17
#define TELOPT_LOGOUT         18
#define TELOPT_BM             19
#define TELOPT_DET            20
#define TELOPT_SUPDUP         21
#define TELOPT_SUPDUPOUTPUT   22
#define TELOPT_SNDLOC         23
#define TELOPT_TTYPE          24
#define TELOPT_EOR            25
#define TELOPT_TUID           26
#define TELOPT_OUTMRK         27
#define TELOPT_TTYLOC         28
#define TELOPT_3270REGIME     29
#define TELOPT_X3PAD          30
#define TELOPT_NAWS           31
#define TELOPT_TSPEED         32
#define TELOPT_LFLOW          33
#define TELOPT_LINEMODE       34
#define TELOPT_XDISPLOC       35
#define TELOPT_OLD_ENVIRON    36
#define TELOPT_AUTHENTICATION 37
#define TELOPT_ENCRYPT        38
#define TELOPT_NEW_ENVIRON    39
#define TELOPT_EXOPL          40

#define SYMWILL 0x01
#define SYMWONT 0x02
#define SYMDO   0x04
#define SYMDONT 0x08
#define SYMFIN  0x20


cat_filter *cat_telnetfilter(cat_filter *filter);
cat_filter *cat_debugfilter(cat_filter *filter);
cat_filter *cat_telnetline(cat_filter *filter);
cat_filter *cat_linefilter(cat_filter *filter);

#ifdef __cplusplus
}
#endif

#endif /* !_cat_telnet_h */

