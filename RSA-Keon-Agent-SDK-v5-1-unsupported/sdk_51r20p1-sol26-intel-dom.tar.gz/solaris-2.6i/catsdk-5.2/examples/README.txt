----------------------------------------------------------------------
		Sample Agents instructions
----------------------------------------------------------------------

The Agents in this directory are samples of how to make Agents using  
the the Keon Agent SDK. This file contains instructions that applies 
entirely to the ftp, pop3 and telnet examples. The tunnel and ws
examples are a little different; the tunnel example is an Agent but
does not require installation on a Security Server, the ws example is
not an Agent (hence no distribution needs to be created) but requires
installation on a Security Server.

In each subdirectory You find READMEs that describes the specific
contents of each example.


Building an Agent
-----------------

1. Unless you have already done so, copy this entire directory
   to a working directory.  Do not build anything in the examples
   directory of the SDK installation.

2. Compile the program by running "make".  Normal C development tools
   (make, cc) must be installed and available.
   This will get you an Agent binary.


A note on the .pp files.
------------------------

PP is an abbreviation that stands for "Pre Processor" and
it is a tool that allows preprocessing of plain text file
with variable substitution. The Makefile.pp is processed by the
framework and generates a Makefile.
The Makefile should be generated automatically when you install 
the SDK. Please see the manual pages for pp and ppmk for a closer
description of how it works.

Makefiles can be created by running:

	$ <INSTALLATION_DIR>/bin/ppmk -o Makefile Makefile.pp 

The above operation is already done in the different examples.
If You wish to rebuild a Makefile, simply do:

	$ make Makefile

This will give you a new Makefile from the *.pp files.


Create a distribution
---------------------

1. Create a target directory for the distribution somewhere.  The
   target directory will get the same contents as an agent
   distribution CD would have.

   Edit the Makefile and set the TARGETDIR variable to the target
   directory.

2. Create the distribution by running "make dist".
   TARGETDIR can also be specified on the command line;
	"make dist TARGETDIR=<dir>" 
   This obviates the need for editing the Makefile.

3. The target directory should now contain an installable agent,
   as well as a complete Base Module and the necessary files
   to install the Agent on a Keon Security Server.


Installing
----------

Now a complete distribution, including the Agent, is ready in the
target directory.
The Agent distributions in the target directory can be installed into
the current installation of the Base System, or the whole distribution
in the target directory can be moved to another host to make a fresh
install of both Base System and Agents.

To make an Agent cooperate with the Keon Security Server 5.0, the Agent
definition and translation files must be installed at the Keon Security Server.

This is made by;

1. Make sure the Agent distribution is accessible on the Keon Security Server.

2. On the Keon Security Server, run the "Keon Agent Installation" program from
   the Start menu.

	Start -> Keon Security Server -> Keon Agent Installation

3. Browse to the adf/ directory in your distribution. And choose
   "Next".

4. The Agent installation program will present you with all Agents
   whose definition and translation files are present in the 
   adf/ directory. Choose to install the appropriate ones.

Now You should be able to administer the installed sample Agents 
from the Keon Security Server Management Console.
