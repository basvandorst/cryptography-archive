#
# $Id: env.sh,v 1.3 2000/01/19 10:51:03 mikko Exp $
#
# Envinronment variables for use with the Agent Toolkit.
# This file should be usable by any "sh" compatible shell,
# i.e. anything but csh (and tcsh?).
#
dir="<<INSTALL:APPDIR>>"
CATCONFDIR="<<INSTALL:ETCDIR>>"
PATH="$dir/bin:$PATH"
LD_LIBRARY_PATH="$dir/lib${LD_LIBRARY_PATH:+:}$LD_LIBRARY_PATH"
MANPATH="$MANPATH${MANPATH:+:}$dir/doc/man"

export PATH MANPATH LD_LIBRARY_PATH CATCONFDIR
