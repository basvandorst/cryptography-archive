#include "usuals.h"

#ifndef AMIGA     /* RKNOP 941029 -- also defined in idea.h, causing problems
                     in random.c */
struct IdeaCfbContext;
#endif
int cryptRandOpen(struct IdeaCfbContext *);
byte cryptRandByte(void);
void cryptRandInit(struct IdeaCfbContext *);
int cryptRandWriteFile(char const *, struct IdeaCfbContext *, unsigned);
void cryptRandSave(struct IdeaCfbContext *);

unsigned trueRandEvent(int event);
void trueRandFlush(void);
void trueRandConsume(unsigned count);
void trueRandAccumLater(unsigned bitcount);
void trueRandAccum(unsigned count);
int trueRandByte(void);

int getstring(char *strbuf, unsigned maxlen, int echo);
