The makefiles in the directories below

UNIX    - Unix GCC/CC type compiler makefile(s)
WIN32   - Win32 Watcom compiler makefile
MSDOS   - MS-DOS system type compiler makefile(s)

This has been tested using the following compilers

Watcom 10.5 Win32 and Extended DOS
Borland 3.1+, 4.5
DJGPP
GCC For HP-UX, SunOS 4.xx, Linux
CC for HP-UX, SunOS 4.xx
Microsoft Visual C++ 4.x
