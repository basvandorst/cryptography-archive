/*
 * Definitions needed to turn sp1bit.c into the SP64 coder.
 */

#define SP64
#undef SP85
#define INIT_FUNC_NAME sp64_init
#define ENCODE_FUNC_NAME sp64_encode
#define DECODE_FUNC_NAME sp64_decode

#include "sp1bit.c"
