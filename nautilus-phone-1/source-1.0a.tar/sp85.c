/*
 * Definitions needed to turn sp1bit.c into the SP85 coder.
 */

#undef SP64
#define SP85
#define INIT_FUNC_NAME sp85_init
#define ENCODE_FUNC_NAME sp85_encode
#define DECODE_FUNC_NAME sp85_decode
#define LOWPASS_FILTER

#include "sp1bit.c"
