#ifndef UNIX	/* avoid conflict with stdlib.h */
int pgp_getopt(int argc, char * const argv[], const char *opts);
#endif

