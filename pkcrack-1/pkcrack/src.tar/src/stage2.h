/* pkcrack - stage2.h
 *
 * (C) by Peter Conrad <conrad@unix-ag.uni-kl.de>
 *
 * $Id: stage2.h,v 1.3 1996/08/13 13:24:18 conrad Release1_2 $
 *
 * $Log: stage2.h,v $
 * Revision 1.3  1996/08/13 13:24:18  conrad
 * expanded arg list for buildKey2Lists()
 *
 * Revision 1.2  1996/06/12 09:47:26  conrad
 * Release version
 *
 * Revision 1.1  1996/06/10 18:07:33  conrad
 * Initial revision
 *
 */

extern void buildKey2Lists( uword aKey2_13, int testBytes, int minOffset );
extern void initMulTab( );

extern uword	loesung0, loesung1, loesung2;

