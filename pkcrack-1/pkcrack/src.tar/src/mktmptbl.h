/* pkcrack - mktmptbl.h
 *
 * (C) by Peter Conrad <conrad@unix-ag.uni-kl.de>
 *
 * $Id: mktmptbl.h,v 1.4 1996/08/13 13:19:48 conrad Release1_2 $
 *
 * $Log: mktmptbl.h,v $
 * Revision 1.4  1996/08/13 13:19:48  conrad
 * Changed name to support OS with short filenames... :-/
 *
 * Revision 1.3  1996/06/23 12:34:20  lucifer
 * #defined ushort for DJGPP
 *
 */

#include <sys/types.h>

#ifdef __DJGPP__
#define	ushort	unsigned short
#endif	/* __DJGPP__ */

extern ushort tempTable[256][64];
extern void   preCompTemp( void );

