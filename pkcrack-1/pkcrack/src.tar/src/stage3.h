/* pkcrack - stage3.h
 *
 * (C) by Peter Conrad <conrad@unix-ag.uni-kl.de>
 *
 * $Id: stage3.h,v 1.3 1996/06/23 10:40:49 lucifer Release1_2 $
 *
 * $Log: stage3.h,v $
 * Revision 1.3  1996/06/23 10:40:49  lucifer
 * Added support for restarting search
 * ,
 *
 * Revision 1.2  1996/06/12 09:47:29  conrad
 * Release version
 *
 * Revision 1.1  1996/06/10 18:08:59  conrad
 * Initial revision
 *
 */

extern void findPwd( uword key0, uword key1, uword key2 );
extern void findLongPwd( uword key0, uword key1, uword key2, int pwdLen, uword initBytes );
extern void initStage3Tab( );

