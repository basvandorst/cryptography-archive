/* pkcrack - keystuff.h
 *
 * (C) by Peter Conrad <conrad@unix-ag.uni-kl.de>
 *
 * $Id: keystuff.h,v 1.4 1996/08/13 13:15:39 conrad Release1_2 $
 *
 * $Log: keystuff.h,v $
 * Revision 1.4  1996/08/13 13:15:39  conrad
 * added #include <sys/types> for ushort
 *
 * Revision 1.3  1996/06/12 09:47:06  conrad
 * Release version
 *
 * Revision 1.2  1996/06/11 10:28:15  conrad
 * added function cUpdateKeys() for decrypting stuff
 *
 * Revision 1.1  1996/06/10 17:47:22  conrad
 * Initial revision
 *
 */

#include <sys/types.h>

extern uword 	key0, key1, key2;
extern ushort	temp;
extern byte	key3;

extern void initkeys();
extern void updateKeys( byte plainbyte );
extern byte cUpdateKeys( byte cipherbyte );

