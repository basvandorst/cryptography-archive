#!/djgpp/bin/perl
#
#This could probably be sed, but I'm feeling lazy.
#

$LONG_LANG_NAME = "language50.txt";
$SHORT_LANG_NAME = "lang50.txt";
# $LANGUAGE_FILE will be one of these two

$HEADER_FILE = "lib/ttyui/language.h";

#In the future, this should call the routine to add the pgpErr.h strings to
#the bottom of the language50.txt file, here.

$LANG_FILE_FOUND = 0;
if(open(INF, $LONG_LANG_NAME))
{
    $LANG_FILE_FOUND = 1;
    $LANGUAGE_FILE = $LONG_LANG_NAME;
}
elsif(open(INF, $SHORT_LANG_NAME))
{
    $LANG_FILE_FOUND = 1;
    $LANGUAGE_FILE = $SHORT_LANG_NAME;
}
else
{
    die "Unable to open $LANGUAGE_FILE for reading!\n";
}

#Now, we want to turn the language50.txt file into lib/ttyui/language.h file.

if(open(OUF, ">$HEADER_FILE"))
{
	print OUF "/*Automatic translation of $LANGUAGE_FILE.\n";
	print OUF " *This file is created by mklang.pl.  DO NOT EDIT!\n";
	print OUF " */\n\n";
	print OUF "static const char *lang = \"\\\n";

	while(<INF>)
	{
	    chop;

	    #Escape any single backslashes:
	    s/\\/\\\\/g;

	    #Escape any quotes:
	    s/"/\\"/g;

	    print OUF "$_\\n\\" . "\n";
	}
	print OUF "\";\n";
	close(OUF);
}
else
{
    print STDERR "Unable to open $HEADER_FILE for reading!\n";
}
close(INF);
