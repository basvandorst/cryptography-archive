int addRecipientToRingSet(struct PgpEnv *env,
			  struct RingPool *ringpool,
			  struct RingSet const *src,
			  struct RingSet *dest,
			  char *recipient);
