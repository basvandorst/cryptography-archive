/*
 * pass.h -- Information about PGP passphrases
 *
 * Copyright (C) 1997 Pretty Good Privacy, Inc.  All rights reserved.
 *
 * Brett A. Thomas (quark@baz.com, bat@pgp.com)
 *
 * $Id: pass.h,v 1.1.2.2 1997/06/07 09:49:10 mhw Exp $
 */

#define PASSLEN 256
