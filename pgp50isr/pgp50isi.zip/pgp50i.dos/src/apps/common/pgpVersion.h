/* Version information.  This file may be modified by scripts.
 *
 * $Id: pgpVersion.h,v 1.1.2.14 1997/10/08 21:59:22 quark Exp $
 *
 */

#define VERSION_OS    "msdos"
#define VERSION_MAJOR "5"
#define VERSION_MINOR "0i"
#define VERSION_SUB   "1b"

