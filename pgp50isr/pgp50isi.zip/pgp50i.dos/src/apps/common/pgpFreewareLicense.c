#include "config.h"
#if (LICENSE == 1)
#include <stdio.h>
#include "pgpLicense.h"

static const char *license = "\
PGP International Freeware, Version 5.0i\n\
(Executable Object Code Version)\n\
Copyright � 1990-1997 Pretty Good Privacy, Inc.  All Rights Reserved.\n\
\n\
For Non-Commercial Distribution and Use Only\n\
Terms and Conditions\n\
\n\
\n\
This special freeware version of PGP 5.0i, including the software and\n\
its related user documentation, (\"Software Product\") is owned by\n\
Pretty Good Privacy, Inc. (or \"PGP\") and is protected by copyright\n\
laws and international copyright treaties, as well as other\n\
intellectual property laws and treaties.\n\
\n\
The makers of PGP, however, are committed to making freely available\n\
to individuals around the world a trusted means to secure their\n\
personal information and communications from unwanted invasions of\n\
privacy. To that end, it is important that this Software Product be\n\
distributed from as many Internet sites as possible. Accordingly,\n\
Pretty Good Privacy, Inc. (or \"PGP\") has agreed that it will not\n\
assert any copyright claims against the non-commercial use and\n\
non-commercial distribution of this Software Product (i.e., this\n\
special international, freeware version 5.0i), provided that all of\n\
the terms and conditions set forth below are complied with. The rights\n\
granted in this license apply only to software that was compiled from\n\
source code that was obtained directly from a printed book or other\n\
printed materials published by Pretty Good Privacy, Inc.\n\
\n\
1) Non-Commercial Licenses\n\
\n\
a. Non-Commercial Use. You may use this Software Product solely for\n\
non-commercial purposes. The term \"non-commercial\" means that the\n\
product (a) has been distributed or otherwise made available at no\n\
charge (direct or indirect) and (b) is not used for any commercial\n\
purpose, which includes, but is not limited to, any activity engaged\n\
for the purpose of generating revenues (directly or indirectly).  For\n\
example, a commercial purpose includes the use of the product within a\n\
commercial business or facility or the use of the product to provide a\n\
service, or in support of service, for which you charge. Commercial\n\
purpose also includes use by any government agency or organization.\n\
Examples of non-commercial purposes include use at home for personal\n\
correspondence, use by students for academic activities, or use by\n\
human rights organizations. The software is in \"use\" when it is loaded\n\
into the temporary memory (i.e., RAM) or installed into the permanent\n\
memory (e.g., hard disk, CD ROM, or other storage device) of a\n\
computer for the purpose of being accessible in client-mode by an end\n\
user.\n\
\n\
b. Non-Commercial Distribution.  You may make exact, unmodified\n\
copies of this Software Product and distribute such copies solely by\n\
electronic means (for example, posting on Internet sites for others to\n\
download), subject to the following (a) that such distribution is\n\
solely for non-commercial purposes (see above definition), (b) that\n\
the Software Product is distributed unmodified and in its entirety\n\
(with its complete user documentation, its readme files, its\n\
copyright, trademark, other intellectual property notices, including\n\
these terms and conditions, and all of its other components), and (c)\n\
that such distribution may occur anywhere in the world, except that\n\
Pretty Good Privacy, Inc. expressly forbids the export of this\n\
Software Product to any countries embargoed by the U.S. government\n\
(currently including, Cuba, Iran, Iraq, Libya, North Korea, Syria and\n\
Sudan) or to the United States to the extent the practice in the U.S.\n\
of any of the inventions covered by U.S. patent no. 4,405,829 (the\n\
\"RSA\" patent) would require payment to the patent rights holder.\n\
\n\
2. Other Uses. All right, title and interest in this Software Product,\n\
including its accompanying user documentation, and all copyrights\n\
therein and related trademarks, trade names and other intellectual\n\
property rights, are owned by Pretty Good Privacy, Inc. or its\n\
suppliers. All license rights not granted herein are reserved by PGP.\n\
Should you wish to use or distribute this Software Product for\n\
commercial purposes (or should you wish to modify, port, or translate\n\
the software or its documentation, or use it in server-mode), please\n\
refer to the International pages of the PGP web site located at\n\
http://www.pgp.com for further information.\n\
\n\
3. Technical Support. This Software Product is user-supported, meaning\n\
that assistance in its installation and use may be limited to help\n\
available from friends, family, and other users on the Internet.\n\
Though PGP does not offer technical support for this Software Product,\n\
we welcome your feedback. Technical support is available from PGP or\n\
its resellers for those who have purchased copies of the commercial\n\
version of this product. For further information, please refer to\n\
http://www.pgp.com.\n\
\n\
4. No Warranty. THIS SOFTWARE PRODUCT IS PROVIDED FOR NON-COMMERCIAL\n\
USE AND DISTRIBUTION ONLY, COMES WITH NO WARRANTY, AND IS PROVIDED ON\n\
AN \"AS IS\" BASIS.  YOU ASSUME THE ENTIRE COST OF ANY DAMAGE RESULTING\n\
FROM THE INFORMATION CONTAINED IN OR PRODUCED BY THIS SOFTWARE\n\
PRODUCT. YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THIS\n\
SOFTWARE PRODUCT TO ACHIEVE YOUR INTENDED RESULTS, AND FOR THE\n\
INSTALLATION OF, USE OF, AND RESULTS OBTAINED FROM IT. TO THE MAXIMUM\n\
EXTENT PERMITTED BY APPLICABLE LAW, PGP, ITS SUPPLIERS AND OTHERS WHO\n\
MAY DISTRIBUTE THIS SOFTWARE PRODUCT DISCLAIM ALL WARRANTIES, EITHER\n\
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES OF\n\
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, CONFORMANCE WITH\n\
DESCRIPTION, AND NON-INFRINGEMENT, WITH RESPECT TO THIS SOFTWARE\n\
PRODUCT.\n\
\n\
5. Limitation of Liability. THE CUMULATIVE LIABILITY OF PGP, ITS\n\
SUPPLIERS OR OTHERS WHO MAY DISTRIBUTE THIS SOFTWARE PRODUCT, TO YOU\n\
OR ANY OTHER PARTY FOR ANY LOSS OR DAMAGES RESULTING FROM ANY CLAIMS,\n\
DEMANDS OR ACTIONS ARISING OUT OF OR RELATING TO THESE TERMS AND\n\
CONDITIONS SHALL NOT EXCEED ONE U.S. DOLLAR.  IN NO EVENT SHALL PGP,\n\
ITS SUPPLIERS OR OTHERS WHO MAY DISTRIBUTE THIS SOFTWARE PRODUCT BE\n\
LIABLE FOR ANY INDIRECT, INCIDENTAL, CONSEQUENTIAL, SPECIAL OR\n\
EXEMPLARY DAMAGES OR LOST PROFITS WHATSOEVER (INCLUDING,WITHOUT\n\
LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS\n\
INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIAR LOSS)\n\
ARISING OUT OF THE USE OR INABILITY TO USE THIS SOFTWARE PRODUCT, EVEN\n\
IF PGP, ITS SUPPLIERS OR OTHERS WHO MAY DISTRIBUTE THIS SOFTWARE\n\
PRODUCT HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.\n\
\n\
BECAUSE SOME JURISDICTIONS DO NOT ALLOW THE LIMITATIONS ON IMPLIED\n\
WARRANTIES OR THE EXCLUSION OR LIMITATION OF LIABILITY FOR\n\
CONSEQUENTIAL OR INCIDENTAL DAMAGES, THE ABOVE LIMITATIONS MAY NOT\n\
APPLY TO YOU.\n\
\n\
6. General. These terms and conditions may not be modified, amended,\n\
canceled or in any way altered, nor may they be modified by custom and\n\
usage of trade or course of dealing, except by an instrument in\n\
writing and signed by a duly authorized officer of PGP. These terms\n\
and conditions shall be construed and enforced in accordance with the\n\
laws of the State of California, United States of America. Any action\n\
or proceeding brought by anyone arising out of or related to these\n\
terms and conditions shall be brought only in a state or federal court\n\
of competent jurisdiction located in the county of San Francisco,\n\
California, and the parties hereby consent to the jurisdiction and\n\
venue of said courts. Should any term of these terms and conditions be\n\
declared void or unenforceable by any court of competent jurisdiction,\n\
such declaration shall have no effect on the remaining terms hereof.\n\
These terms and conditions are in the English language, and only the\n\
English language version hereof, regardless of the existence of other\n\
language translations of these terms and conditions, shall be\n\
controlling in all respects. The failure of either party to enforce\n\
any rights granted hereunder or to take action against the other party\n\
in the event of any breach hereunder shall not be deemed a waiver by\n\
that party as to subsequent enforcement of rights or subsequent\n\
actions in the event of future breaches. PGP reserves the right at any\n\
time without liability or prior notice to change the features or\n\
characteristics of this Software Product, or its documentation and\n\
related materials, or future versions thereof. These terms and\n\
conditions constitute the complete and exclusive statement of the\n\
agreement between us which supersedes any proposal or prior agreement,\n\
oral or written, and any other communication between us relating to\n\
the subject matter of these terms and conditions.\n\
\n\
Copyright � 1990-1997 Pretty Good Privacy, Inc. All rights reserved.\n\
PGP, Pretty Good and Pretty Good Privacy are registered trademarks of\n\
Pretty Good Privacy, Inc. The Software Product may use public key\n\
algorithms described in U.S. patent numbers 4,200,770, 4,218,582, and\n\
4,424,414, and their international equivalents, licensed by Cylink\n\
Corporation, and number 4,405,829 licensed by Public Key Partners; the\n\
IDEA� cryptographic cipher described in U.S. patent number 5,214,703,\n\
licensed from Ascom Tech AG; and the Northern Telecom Ltd., CAST\n\
Encryption Algorithm, licensed from Northern Telecom, Ltd.  IDEA is a\n\
trademark of Ascom Tech AG. The compression code in PGP is by Mark\n\
Adler and Jean-loup Gailly, used with permission from the free\n\
Info-ZIP implementation. LDAP software provided courtesy University of\n\
Michigan at Ann Arbor, Copyright � 1992-1996 Regents of the University\n\
of Michigan. All rights reserved. Richard Outerbridge is the author of\n\
the Triple-DES code used in this product.  Pretty Good Privacy, Inc.\n\
may have patents and/or pending patent applications covering subject\n\
matter in this software or its documentation; the furnishing of this\n\
software or documentation does not give you any license to these\n\
patents. Note: Some countries have laws and regulations regarding the\n\
use and export of cryptography products; please consult your local\n\
government authority for details.\n\
\n\
Should you have any questions concerning these terms and conditions,\n\
or if you desire to contact Pretty Good Privacy, Inc. for any reason,\n\
please write: Pretty Good Privacy, Inc. Customer Service, 2121 S. El\n\
Camino Real, Suite 902, San Mateo, CA 94403. http://www.pgp.com.\n\
\n";

void display_license(void)
{
    fprintf(stdout, license);
}
#endif
