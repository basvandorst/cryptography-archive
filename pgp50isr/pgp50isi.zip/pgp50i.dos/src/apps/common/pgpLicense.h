void display_license(void);
