/*Automatic translation of language50.txt.
 *This file is created by mklang.pl.  DO NOT EDIT!
 */

static const char *lang = "\
#This file contains the strings used by PGP 5.0i for MSDOS.\n\
\n\
[DIFFERENT_EXES]\n\
us=\\\n\
PGP is now invoked from different executables/modes for different operations:\\n\\n\\\n\
pgpe  (or pgp -e ...)  Encrypt (including Encrypt/Sign)\\n\\\n\
pgps  (or pgp -s ...)  Sign\\n\\\n\
pgpv  (or pgp -v ...)  Verify/Decrypt\\n\\\n\
pgpo  (or pgp -o ...)  Old-style PGP 2.6.3 command-line emulation.\\n\\\n\
To get one of them, either rename pgp.exe to its name or use the above first\\n\\\n\
argument -e, -s, -v, or -o with the unrenamed pgp.exe.\\n\\n\\\n\
pgpk  Key generation and management;\\n\\\n\
pgpk.exe is a separate executable and can not be created out of pgp.exe.\\n\\n\\\n\
See each application's respective man page or the general PGP documentation\\n\\\n\
for more information.\\n\n\
\n\
[CREATING_OUTPUT_FILE]\n\
us=Creating output file %s\\n\n\
\n\
#Untested\n\
[COPYING_KEYFILE_AND_RUNNING_PGPK]\n\
us=Copying key file to \\\"%s\\\", running pgpk to process it...\\n\\n\n\
\n\
#Untested\n\
[NEED_PASSPHRASE]\n\
us=You need a passphrase to encrypt the file\\n\n\
\n\
[MUST_SPECIFY_A_RECIPIENT]\n\
us=You must specify at least one recipient for encryption!\\n\n\
\n\
#Untested\n\
[NEED_PASSPHRASE_AGAIN]\n\
us=Enter same passphrase again\\n\n\
\n\
#Untested\n\
[PASSPHRASES_DIFFERENT]\n\
us=Error: Passphrases were different.  Try again.\\n\n\
\n\
#Untested\n\
[ZERO_LEN_PASSPHRASE]\n\
us=Encryption error\\n\n\
\n\
#Untested\n\
[TREAT_AS_PGP]\n\
us=This is a PGP File.  Treat it as such? [y/N]\\n\n\
\n\
#Untested\n\
[PRIVATE_KEY_MISSING]\n\
us=Cannot find a private key for signing: %s\\n\n\
\n\
#Untested\n\
[CANNOT_CONVERT_TO_PRIVATE_KEY]\n\
us=Cannot convert to private key\\n\n\
\n\
#Untested\n\
[PRIVATE_KEY_CANNOT_SIGN]\n\
us=Private Key cannot sign\\n\n\
\n\
#Untested\n\
[CANNOT_UNLOCK_PRIVATE_KEY]\n\
us=Cannot unlock private key\\n\n\
\n\
#Untested\n\
[NO_KEYRINGS]\n\
us=No keyrings to use\n\
\n\
#Untested\n\
[NO_ENCRYPTION_KEYS_FOUND_FOR]\n\
us=No encryption keys found for: %s\\n\n\
\n\
#Untested\n\
[CANNOT_FIND_KEY]\n\
us=Cannot find key: %s\\n\n\
\n\
#Untested\n\
[CANNOT_ADD_MY_KEY]\n\
us=Cannot add my key to set\\n\n\
\n\
#Untested\n\
[NO_VALID_RECIPIENTS]\n\
us=No valid keys found for any recipients, exiting...\\n\n\
\n\
#Untested\n\
[USING_STDIN]\n\
us=No files specified.  Using stdin.\\n\\n\n\
\n\
#Untested\n\
[CANNOT_OPEN_INPUT_FILE]\n\
us=Cannot open input file %s\\n\n\
\n\
#Untested\n\
[CANNOT_SETUP_PROCESSING_PIPELINE]\n\
us=Cannot Setup Processing Pipeline\\n\n\
\n\
#Untested\n\
[UNRECOGNIZED_OPTION_STRING]\n\
us=Unrecognized option %s\\n\n\
\n\
#Untested\n\
[UNRECOGNIZED_OPTION_STRING_DASH]\n\
us=Unrecognized option -%s\\n\n\
\n\
#Untested\n\
[UNRECOGNIZED_OPTION_CHAR]\n\
us=Unrecognized option -%c\\n\n\
\n\
#Untested\n\
[ARGS_INCOMPATABLE]\n\
us=\"Cannot use -%c and -%c together\\n\"\n\
\n\
#Untested\n\
[ONLY_ONE_OUTPUT_FILE]\n\
us=\"Only one -o option allowed\\n\"\n\
\n\
#Untested\n\
[ONLY_ONE_USERNAME]\n\
us=\"Only one -u option allowed\\n\"\n\
\n\
#Untested\n\
[NO_OUTPUT_FILENAME]\n\
us=-o option requires an output file name argument\\n\n\
\n\
[NO_RECIPIENT_SPECIFIED]\n\
us=-r option requires a recipient name argument\\n\n\
\n\
#Untested\n\
[NO_USERID_SPECIFIED]\n\
us=-u option requires a userid argument\\n\n\
\n\
#Untested, and probably going away\n\
[NO_PASSPHRASE_SPECIFIED_IN_BATCHMODE]\n\
us=-z option requires a passphrase argument\\n\n\
\n\
#Untested\n\
[CANNOT_COMBINE_CONVENTIONAL_AND_PK]\n\
us=Cannot combine -c and -r arguments\\n\n\
\n\
#Untested\n\
[PGPK_IS_SEPERATE]\n\
us=PGPK is a separate program; pgp.exe may not be renamed to pgpk.exe!\\n\n\
\n\
#Untested\n\
[UNKNOWN_SYMLINK]\n\
us=You must invoke PGP with -e, -s, -v, or -o as the first argument!\\n\n\
\n\
#Untested\n\
[PRIVATE_KEY_NEEDED_FOR_SIGNATURE]\n\
us=A private key is required to make a signature.\\n\n\
\n\
[ENTER_Y_OR_N]\n\
us=\"Invalid response.  Please enter Y or N [default %c]: \\n\"\n\
\n\
#Untested\n\
[GENERIC_KEYRING_ERROR]\n\
us=\"Error on keyring \\\"%s\\\":  \"\n\
\n\
#Untested\n\
[UNABLE_TO_OPEN_DEFAULT_KEYRINGS]\n\
us=\"Unable to open default keyrings:  \"\n\
\n\
#Untested\n\
[UNABLE_TO_OPEN_KEYRING]\n\
us=\"Unable to open keyring:  \"\n\
\n\
#Untested\n\
[KEY_CORRUPTED]\n\
us=\"Key Corrupted (%s):  \"\n\
\n\
#Untested\n\
[NEED_SIG_FILE]\n\
us=\"File to check signature against [%s]: \"\n\
\n\
#untested\n\
[GOOD_SIGNATURE]\n\
us=\"Good signature made %s by key:\\n\"\n\
\n\
#untested\n\
[BAD_SIGNATURE]\n\
us=\"BAD signature made %s by key:\\n\"\n\
\n\
#untested\n\
[ERROR_SIGNATURE]\n\
us=\"Error %s checking signature:  %s\\n\"\n\
\n\
#Untested\n\
[UNKNOWN_SIGNATURE]\n\
us=\"Signature by unknown keyid: \"\n\
\n\
#untested\n\
[ENTER_PASSPHRASE]\n\
us=\"Enter pass phrase: \"\n\
\n\
#Untested\n\
[RANDOM_BITS_FROM_DEVICE]\n\
us=\"\\n\\\n\
We need to generate %u random bits.  This is done by reading\\n\\\n\
%s.  Depending on your system, you may be able\\n\\\n\
to speed this process by typing on your keyboard and/or moving your mouse.\\n\"\n\
\n\
#Untested\n\
[RANDOM_BITS_FROM_DEVICE_OLD_KERNEL]\n\
us=\"\\n\\\n\
/dev/random detected; however, on Linux kernel versions < 1.3.33, it is not\\n\\\n\
cryptographically usable.  If you wish to use /dev/random as an entropy\\n\\\n\
source, it is recommended that you upgrade your kernel version.  If you feel\\n\\\n\
that you received this message in error, add ForceRandomDevice=1 to your\\n\\\n\
pgp.cfg file, but be warned that by doing so without know what you are\\n\\\n\
doing, you could compromise the security of your key.\\n\"\n\
\n\
#Untested\n\
[RANDOM_BITS_FROM_KEYBOARD]\n\
us=\"\\n\\\n\
We need to generate %u random bits.  This is done by measuring the\\n\\\n\
time intervals between your keystrokes.  Please enter some random text\\n\\\n\
on your keyboard until you hear the beep:\\n\"\n\
\n\
#Untested\n\
[NO_INPUT_FILE_IN_BATCHMODE]\n\
us=\"Cannot request input file in batchmode\\n\"\n\
\n\
#Untested\n\
[UNABLE_TO_OPEN_FILE]\n\
us=\"Unable to open file \\\"%s\\\"\\n\"\n\
\n\
#Untested\n\
[UNABLE_TO_CREATE_READ_MODULE]\n\
us=\"Unable to create file read module.\\n\"\n\
\n\
#Untested\n\
[UNKNOWN_FILE_TYPE]\n\
us=\"Unknown file type (clearsigned?).  Assuming text\\n\"\n\
\n\
#Untested\n\
[OPENING_FILE_WITH_TYPE]\n\
us=\"Opening file \\\"%s\\\" type %s.\\n\"\n\
\n\
#Untested\n\
[ERROR_CLOSING_OLD_FILE]\n\
us=\"Error closing old file: %d\\n\"\n\
\n\
#Untested\n\
[NEED_PASSPHRASE_TO_DECRYPT_KEY]\n\
us=\"Need a pass phrase to decrypt private key:\\n\"\n\
\n\
#Untested\n\
[GOOD_PASSPHRASE]\n\
us=\"Pass phrase is good.\\n\"\n\
\n\
#Untested\n\
[BAD_PASSPHRASE]\n\
us=\"Error: Bad pass phrase.\\n\\n\"\n\
\n\
#Untested\n\
[PASSPHRASE_INCORRECT]\n\
us=\"Password Incorrect.\"\n\
\n\
#Untested\n\
[TRY_AGAIN]\n\
us=\"  Try Again.\"\n\
\n\
#Untested\n\
[UNKNOWN_ESK]\n\
us=\"Unknown ESK type: %d\\n\"\n\
\n\
#Untested\n\
[CANNOT_DECRYPT]\n\
us=\"Cannot decrypt message.  It can only be decrypted by:\\n\"\n\
\n\
#Untested\n\
[A_PASSPHRASE]\n\
us=\"  A Pass Phrase\\n\"\n\
\n\
#Untested\n\
[KEY_ID]\n\
us=\"  Key ID \"\n\
\n\
#Untested\n\
[FORCE_OVERWRITE]\n\
us=\"File \\\"%s\\\" already exists. Overwrite? [y/N] \"\n\
\n\
#Untested\n\
[UNABLE_TO_OVERWRITE_FILE]\n\
us=\"Unable to overwrite file \\\"%s\\\"\\n\"\n\
\n\
#Untested\n\
[RANDOM_DEVICE_NOT_DEFAULT]\n\
us=\"Warning!  Random device is something other than %s!\\n\\\n\
This MAY be a security hole.\\n\"\n\
\n\
#Untested\n\
[RANDOM_DEVICE_WRITABLE]\n\
us=\"Warning!  %s is writable by users other than root!\\n\\\n\
This is probably OK, but you should have your sysadmin fix it.\\n\\\n\
Proceeding.\\n\"\n\
\n\
#Untested\n\
[RANDOM_DEVICE_UNREADABLE]\n\
us=\"\\\n\
Warning!  Random device %s found, but you can't read it!\\n\"\n\
\n\
#Untested\n\
[BITS_AND_KEYID]\n\
us=\"%6u bits, Key ID \"\n\
\n\
#Untested\n\
[KEY_NOT_FOUND]\n\
us=Key not found: \\\"%s\\\"\\n\n\
\n\
#Untested\n\
[PGPERR_TROUBLE_BADTRUST_LONG]\n\
us=\"Trust packet too long: %lu bytes long\"\n\
\n\
#Untested\n\
[PGPERR_TROUBLE_UNKPKTBYTE_LONG]\n\
us=\"Unknown packet byte: %02X\"\n\
\n\
#Untested\n\
[PGPERR_TROUBLE_KEY2BIG_LONG]\n\
us=\"Key grossly oversized: %lu bytes long\"\n\
\n\
#Untested\n\
[PGPERR_TROUBLE_NAME2BIG_LONG]\n\
us=\"User ID too long: %lu bytes long\"\n\
\n\
#Untested\n\
[PGPERR_TROUBLE_SIG2BIG_LONG]\n\
us=\"Signature grossly oversized: %lu bytes long\"\n\
\n\
#Untested\n\
[PGPERR_TROUBLE_DUPKEYID_LONG]\n\
us=\"Duplicate keyID found.  Two keys have the same keyID,\\n\\\n\
but they are different.  This is highly suspicious.  The first key\n\
is:\"\n\
\n\
#Untested\n\
[PGPERR_TROUBLE_DUPKEY_LONG]:\n\
us=\"A key was found twice in one keyring file.  It is a duplicate of:\\n\"\n\
\n\
#Untested\n\
[PGPERR_TROUBLE_DUPNAME_LONG]\n\
us=\"A name was found twice in one keyring file.  It is a duplicate of:\\n\"\n\
\n\
#Untested\n\
[PGPERR_TROUBLE_BAREKEY_LONG]\n\
us=\"A key was found twice in one keyring file.  It is a duplicate of:  \"\n\
\n\
#Untested\n\
[PGPERR_TROUBLE_VERSION_BUG_CUR_LONG]\n\
us=\"This private key's version number appears to be incorrect.\\n\\\n\
PGP version 2.6 had a bug wherein it would improperly change the\\n\\\n\
version number of a private key generated by older versions of PGP\\n\\\n\
when it was edited.  The private key in this key file has a version\\n\\\n\
byte that is different from a copy in another key file, and appears\\n\\\n\
to be improper.  PGP will fix this by changing the version byte in\\n\\\n\
the private key to the previous value.  The key with the problem\n\
is:\\n\"\n\
\n\
#Untested\n\
[PGPERR_TROUBLE_VERSION_BUG_PREV_LONG]\n\
us=\"A previously seen private key's version number appears to be\\n\\\n\
incorrect.  PGP version 2.6 had a bug wherein it would improperly\\n\\\n\
change the version byte of a private key generated by older versions\\n\\\n\
of PGP when it was edited.  The public key in this key file has\\n\\\n\
a version byte that is different from a private key elsewhere,\\n\\\n\
which appears to be improper.  PGP will fix this by changing the\\n\\\n\
version byte in the private key to the previous value.  The key\\n\\\n\
with the problem is:\\n\"\n\
\n\
#Untested\n\
[PGPERR_KEYIO_READING_LONG]\n\
us=\"I/O error reading file: %s\"\n\
\n\
#Untested\n\
[PGPERR_KEYIO_FTELL_LONG]\n\
us=\"I/O error during call to ftell(): %s\"\n\
\n\
#Untested\n\
[PGPERR_PRECEDING_ASSOCIATED_WITH]\n\
us=\"The preceeding error was associated with:  \"\n\
\n\
#Untested\n\
[NOT_PGP_KEYFILE]\n\
us=\"File is not a PGP key file.  Aborting.\\n\"\n\
\n\
#Untested\n\
[FOLLOWING_KEYRING_PROBLEMS]\n\
us=\"The following problems were encountered while reading the keyring:\\n\"\n\
\n\
#Untested\n\
[OFFSET_DESCRIPTION]\n\
us=\"Offset   Description\\n\"\n\
\n\
#Untested\n\
[UNKNOWN_SIGNATOR]\n\
us=\"   (Unknown signator, can't be checked)\\n\"\n\
\n\
#Untested\n\
[OPEN_PAREN_KEYID]\n\
us=\"         (KeyID:\"\n\
\n\
#Untested\n\
[REVOKED]\n\
us=\"*REVOKED*\"\n\
\n\
#Untested\n\
[ABOVE_KEY_REVOKED]\n\
us=\"\\\n\
WARNING: The above key has been revoked by its owner,\\n\\\n\
possibly because the private key was compromised.\\n\\\n\
You cannot use a revoked key for encryption.\\n\"\n\
\n\
#Untested\n\
[ABOVE_KEY_DISABLED]\n\
us=\"\\\n\
WARNING:  The above key has been disabled on your keyring.  If you\\n\\\n\
wish to use it, use \\\"pgpk -d\\\" to reenable it.\\n\"\n\
\n\
[ABOVE_KEY_EXPIRED]\n\
us=\"\\\n\
WARNING:  The above key is not valid for use after %s.\\n\"\n\
\n\
#Untested\n\
[STILL_USE_EXPIRED_KEY]\n\
us=\"\\\n\
WARNING:  This key is not valid for use after %s.\\n\\\n\
Do you still want to use it? [y/N] \"\n\
\n\
#Untested\n\
[PGP_NAMETRUST_UNKNOWN]\n\
us=\"\\\n\
WARNING: Because the following name has not been certified\\n\\\n\
by a trusted signature, it is not known with a high\\n\\\n\
degree of confidence that the above key belongs to:\\n\"\n\
\n\
#Untested\n\
[PGP_NAMETRUST_UNTRUSTED]\n\
us=\"WARNING: The above key is not trusted to belong to:\\n\"\n\
\n\
#Untested\n\
[PGP_NAMETRUST_MARGINAL]\n\
us=\"\\\n\
WARNING: Because the following name is not certified with sufficient\\n\\\n\
trusted signatures, it is not known with high confidence that the\\n\\\n\
above key actually belongs to:\\n\"\n\
\n\
#Untested\n\
[PGP_NEWTRUST_NOT_TRUSTED]\n\
us=\"\\n\\\n\
WARNING: The above key is not trusted to belong to:\\n\"\n\
\n\
#Untested\n\
[PGP_NEWTRUST_PARTIAL_TRUST]\n\
us=\"\\n\\\n\
WARNING: Because the following name is not certified with sufficient\\n\\\n\
trusted signatures, there is an estimated 1/%-ld probability that\\n\\\n\
the above key may not belong to:\\n\"\n\
\n\
#Untested\n\
[PGP_NEWTRUST_NOT_TRUSTED_SIGNING_KET]\n\
us=\"\\n\\\n\
WARNING: The signing key is not trusted to belong to:\\n\"\n\
\n\
#Untested\n\
[PREVIOUSLY_APPROVED_KEY]\n\
us=\"\\nBut you previously approved using the key with this name.\\n\"\n\
\n\
#Untested\n\
[DO_YOU_WISH_TO_USE_UNTRUSTED_KEY]\n\
us=\"\\nDo you want to use the key with this name? [y/N] \"\n\
\n\
#Untested\n\
[DONT_TRUST_SIGS_FROM_REVOKED_KEYS]\n\
us=\"\\\n\
WARNING: The signing key has been revoked by its owner,\\n\\\n\
possibly because the private key was compromised.\\n\\\n\
A signature made by this key should not be trusted.\\n\"\n\
\n\
#Untested\n\
[YOU_HAVE_DISABLED_SIGNING_KEY]\n\
us=\"WARNING: You have disabled the signing key\\n\"\n\
\n\
#Untested\n\
[KEY_HAS_EXPIRED]\n\
us=\"WARNING: This key is not valid for use after %s.\\n\"\n\
\n\
#Untested\n\
[PGP_NAMETRUST_UNTRUSTED_SIGNING_KEY]\n\
us=\"\\nWARNING: The signing key is not trusted to belong to:\\n\"\n\
\n\
[MESSAGE_IS_ENCRYPTED]\n\
us=\"Message is encrypted.\\n\"\n\
\n\
[GETTING_KEY_FOR]\n\
us=\"Getting key for %s.\\n\"\n\
\n\
[LOOKING_UP_HOST]\n\
us=\"Looking up host %s\\n\"\n\
\n\
[ESTABLISHING_CONNECTION]\n\
us=\"Establishing connection\\n\"\n\
\n\
[SENDING_REQUEST]\n\
us=\"Sending request\\n\"\n\
\n\
[RECEIVING_DATA]\n\
us=\"Receiving data\\n\"\n\
\n\
[CLEANING_UP]\n\
us=\"Cleaning up\\n\"\n\
\n\
[COMPLETE]\n\
us=\"Complete.\\n\"\n\
\n\
[ONE_KEY_RECEIVED]\n\
us=\"One key received.  Adding it to your keyring...\\n\"\n\
\n\
[MANY_KEYS_RECEIVED]\n\
us=\"%li keys received.  Adding them to your keyring...\\n\"\n\
\n\
[UNKNOWN_PROTOCOL]\n\
us=\"Unknown protocol %s.\\n\"\n\
\n\
[SENDING_KEY]\n\
us=\"Sending key                               \\r\"\n\
\n\
[RECEIVING_RESPONSE]\n\
us=\"Receiving response                       \\r\"\n\
\n\
#Untested\n\
[NO_KEYFILE_SPECIFIED]\n\
us=\"-a argument requires a key file or URL to add to your keyring.\"\n\
\n\
#Untested\n\
[UNABLE_TO_IMPORT_KEYFILE]\n\
us=\"Unable to import keyfile \\\"%s\\\".\\n\"\n\
\n\
#Untested\n\
[ADDING_KEYS]\n\
us=\"Adding keys:\\n\\n\"\n\
\n\
#Untested\n\
[UNABLE_TO_CREATE_KEYLIST]\n\
us=\"Unable to create keylist\\n\"\n\
\n\
#Untested\n\
[NO_KEYS_TO_ADD]\n\
us=\"No keys to add                           \\n\"\n\
\n\
#Untested\n\
[KEYS_ADDED_SUCCESSFULLY]\n\
us=\"Keys added successfully.\\n\"\n\
\n\
#Untested\n\
[INVALID_SELECTION]\n\
us=\"Invalid Selection.  Please try again.\\n\"\n\
\n\
[TOO_MANY_MATCHES]\n\
us=\"Too many matches; aborting!\\n\"\n\
\n\
[CHOOSE_ONE_ABOVE]\n\
us=\"Choose one of the above:  \"\n\
\n\
[PLEASE_SELECT_A_USER_ID]\n\
us=\"Please select a user ID %s:\\n\"\n\
\n\
[PLEASE_SELECT_A_USER_ID_WITH_SIG]\n\
us=\"Please select a user ID with a signature %s:\\n\"\n\
\n\
[PLEASE_SELECT_A_KEY_WITH_USERID]\n\
us=\"Please select a key with a userid %s:\"\n\
\n\
[PLEASE_SELECT_A_KEY_WITH_SIG]\n\
us=\"Please select a key with a signature %s:\"\n\
\n\
[NO_USER_IDS_SELECTED]\n\
us=\"No user IDs selected %s.\\n\"\n\
\n\
[PLEASE_SELECT_A_SIGNATURE]\n\
us=\"Please select a signature %s:\"\n\
\n\
[NO_SIGNATURES_SELECTED]\n\
us=\"No signatures selected %s.\\n\"\n\
\n\
[NO_KEYS_SELECTED]\n\
us=\"No keys selected %s.\\n\"\n\
\n\
[A_USERID_IS_REQUIRED]\n\
us=\"A user ID is required to select the key you want %s.\\n\\\n\
Enter the key's user ID: \"\n\
\n\
[UNABLE_TO_ORDER_KEYSET]\n\
us=\"Unable to order keyset\\n\"\n\
\n\
[PLEASE_SELECT_A_KEY]\n\
us=\"Please select a key %s:\"\n\
\n\
[UNABLE_TO_CREATE_ITER]\n\
us=\"Unable to create key iterator\\n\"\n\
\n\
[NO_HTTP_SEND]\n\
us=\"HTTP cannot be used as a sending protocol at this time.\\n\"\n\
\n\
[UNKNOWN_PROTOCOL]\n\
us=\"Unknown protocol %s.\\n\"\n\
\n\
[NO_KEYS_SELECTED_FOR_EXTRACTION]\n\
us=\"No keys were selected for extraction.\\n\"\n\
\n\
[ENABLE_THIS_KEY]\n\
us=\"\\nEnable this key? [y/N] \"\n\
\n\
[DISABLE_THIS_KEY]\n\
us=\"\\nDisable this key? [y/N] \"\n\
\n\
[KEY_ENABLED]\n\
us=\"\\nKey enabled.\\n\"\n\
\n\
[KEY_DISABLED]\n\
us=\"\\nKey disabled.\\n\"\n\
\n\
[CANNOT_TRUST_INVALID_KEYS]\n\
us=\"This key is not valid, and cannot be assigned trust\\n\"\n\
\n\
[DO_YOU_WISH_TO_CHANGE_INTRODUCER_RELIABITY]\n\
us=\"Do you want to change your estimate of this key owner's reliability\\n\\\n\
as an introducer of other keys [y/N]? \"\n\
\n\
[NO_CHANGES_MADE]\n\
us=\"No changes made.\\n\"\n\
\n\
[DETERMINE_IN_YOUR_MIND]\n\
us=\"\\n\"\\\n\
\"Make a determination in your own mind whether this key actually\\n\"\\\n\
\"belongs to the person whom you think it belongs to, based on available\\n\"\\\n\
\"evidence.  If you think it does, then based on your estimate of\\n\"\\\n\
\"that person's integrity and competence in key management, answer\\n\"\\\n\
\"the following question:\\n\"\n\
\n\
[WOULD_YOU_TRUST_THIS_KEY_AND_OWNER]\n\
us=\"\\nWould you trust this key owner to act as an introducer and\\n\\\n\
certify other people's public keys to you?\\n\\\n\
(1=I don't know. 2=No. 3=Usually. 4=Yes, always.) : \"\n\
\n\
[UNRECOGNIZED_RESPONSE]\n\
us=\"Unrecognized response.\\n\"\n\
\n\
[UNABLE_TO_SET_TRUST]\n\
us=\"Unable to set trust\\n\"\n\
\n\
[DESCRIBE_CONFIDENCE_AS_INTRODUCER]\n\
us=\"\\nDescribe the confidence you have in this person as an introducer.\\n\\\n\
What are the odds that this key owner is going to be wrong about\\n\\\n\
a key which she has signed as an introducer?\\n\"\n\
\n\
[CURRENTLY_INFINITE_TRUST]\n\
us=\"(Currently she is listed as having essentially zero chance\\\n\
 of being wrong.)\\n\"\n\
\n\
[CURRENTLY_ZERO_TRUST]\n\
us=\"(Currently he is listed as not having any confidence as an\\\n\
 introducer.)\\n\"\n\
\n\
[CURRENTLY_HAS_PERCENT_TRUST_START]\n\
us=\"(Currently she is listed as having a one in \"\n\
\n\
[CURRENTLY_HAS_PERCENT_TRUST_END]\n\
us=\" chance of being wrong.)\\n\"\n\
\n\
[ENTER_A_TRUST_RANGE]\n\
us=\"Enter a number from 1 to 2 million\"\n\
\n\
[OR_HIT_RETURN_TO_LEAVE_UNCHANGED]\n\
us=\", or hit return to leave unchanged.\"\n\
\n\
[WILL_BE_WRONG_TIME_TIME_IN]\n\
us=\"\\nShe will be wrong one time in: \"\n\
\n\
[DO_YOU_WANT_THIS_KEY_AXIOMATIC]\n\
us=\"\\nDo you want to set this key as axiomatic [y/N]? \"\n\
\n\
[PUBLIC_KEYRING_UPDATED]\n\
us=\"Public keyring updated.\\n\"\n\
\n\
[NEED_OLD_PASSPHRASE]\n\
us=\"Need old passphrase. \"\n\
\n\
[NEED_NEW_PASSPHRASE]\n\
us=\"Need new passphrase. \"\n\
\n\
[ENTER_IT_A_SECOND_TIME]\n\
us=\"Enter it a second time. \"\n\
\n\
[PASSPHRASES_ARE_DIFFERENT]\n\
us=\"Passphrases are different\\n\"\n\
\n\
[CHANGING_MASTER_KEY_PASSPHRASE]\n\
us=\"Changing master key passphrase...\\n\"\n\
\n\
[PASSPHRASE_CHANGE_FAILED_MASTER]\n\
us=\"Passphrase change failed for master key.\\n\"\n\
\n\
[CHANGING_SUBKEY_PASSPHRASE]\n\
us=\"Changing subkey passphrase...\\n\"\n\
\n\
[PASSPHRASE_CHANGE_FAILED_SUBKEY]\n\
us=\"Passphrase change failed for subkey.\\n\"\n\
\n\
[CONFIRM_NON_AXIOMATIC]\n\
us=\"\\nDo you want to unset this key as axiomatic [y/N]? \"\n\
\n\
[CONFIRM_ADD_NEW_USERID]\n\
us=\"\\nDo you want to add a new user ID [y/N]? \"\n\
\n\
[ENTER_NEW_USERID]\n\
us=\"Enter the new user ID: \"\n\
\n\
[NO_NAME_ENTERED]\n\
us=\"No name entered.\\n\"\n\
\n\
[UNABLE_TO_ADD_NEW_USERID]\n\
us=\"Unable to add new User ID (%d)\\n\"\n\
\n\
[CONFIRM_CHANGE_PASSPHRASE]\n\
us=\"\\nDo you want to change your pass phrase (y/N)? \"\n\
\n\
[CHANGE_PASSPHRASE_FAILED]\n\
us=\"Change passphrase failed (%d)\\n\"\n\
\n\
[CONFIRM_SET_DEFAULT_KEY]\n\
us=\"\\nDo want to set this as your default key [y/N]? \"\n\
\n\
[KEYRINGS_UPDATED]\n\
us=\"Keyrings updated.\\n\"\n\
\n\
[TO_BE_REMOVED_FRAGMENT]\n\
us=\"to be removed\"\n\
\n\
[SIGNATURE_FRAGMENT]\n\
us=\"signature\"\n\
\n\
[USERID_FRAGMENT]\n\
us=\"user ID\"\n\
\n\
[KEY_FRAGMENT]\n\
us=\"key\"\n\
\n\
[SELECTED_KEY_HAS_ONLY_ONE_USERID\"]\n\
us=\"Selected key has only one user ID; can't be selected %s\\n\"\n\
\n\
[FOLLOWING_OBJECT_HAS_BEEN_SELECTED]\n\
us=\"\\nThe following %s has been selected %s:\\n\"\n\
\n\
[UNABLE_TO_REMOVE_OBJECT]\n\
us=\"Unable to remove object\\n\"\n\
\n\
[TO_BE_SIGNED_FRAGMENT]\n\
us=\"to be signed\"\n\
\n\
[VALIDITY_CERTIFICATION_WARNING]\n\
us=\"\\n\\n\\\n\
READ CAREFULLY:  Based on your own direct first-hand knowledge, are\\n\\\n\
you absolutely certain that you are prepared to solemnly certify that\\n\\\n\
the above public key actually belongs to the user specified by the\\n\\\n\
above user ID [y/N]? \"\n\
\n\
[KEY_SIGNING_CANCELED]\n\
us=\"Key sign operation cancelled.\\n\"\n\
\n\
[KEY_SELECTED_FOR_SIGNING_IS]\n\
us=\"Key selected for signing is:\\n\"\n\
\n\
[KEY_SIGN_OPERATION_FAILED]\n\
us=\"Key sign operation failed\\n\"\n\
\n\
[KEY_SIG_CERT_ADDED]\n\
us=\"Key signature certificate added.\\n\"\n\
\n\
[TO_BE_REVOKED_FRAGMENT]\n\
us=\"to be revoked\"\n\
\n\
[YOU_DONT_HAVE_THE_PRIVATE_KEY]\n\
us=\"You don't have the private key corresponding to that key\\n\"\n\
\n\
[SIG_ALREADY_REVOKED]\n\
us=\"That signature has already been revoked.\\n\\\n\
Are you sure you want to add another revocation certificate [y/N]? \"\n\
\n\
[SIG_REVOCATION_CANCELLED]\n\
us=\"Signature revocation cancelled.\\n\"\n\
\n\
[CONFIRM_REVOKE_KEY]\n\
us=\"Do you want to permanently revoke your public key\\n\\\n\
by issuing a secret key compromise certificate on this key [y/N]? \"\n\
\n\
[CONFIRM_REVOKE_SIG]\n\
us=\"Do you want to revoke this signature [y/N]? \"\n\
\n\
[REVOKE_CANCELLED]\n\
us=\"Revoke cancelled.\\n\"\n\
\n\
[UNABLE_TO_GENERATE_REVOCATION_SIGNATURE]\n\
us=\"Unable to generate revocation signature\\n\"\n\
\n\
[KEY_REVOCATION_CERT_ADDED]\n\
us=\"Key revocation certificate added.\\n\"\n\
\n\
[SELECT_SIGNING_KEY]\n\
us=\"Please select a key to sign with:\"\n\
\n\
[UNABLE_TO_OPEN_KEYRING]\n\
us=\"Unable to open keyring\\n\"\n\
\n\
[PGPINITAPP_FAILED]\n\
us=\"pgpInitApp failed\\n\"\n\
\n\
[KEY_IS_ALREADY_REVOKED]\n\
us=\"That key has already been revoked\\n\"\n\
\n\
[USE_FORCE_TO_ALLOW_OVERWRITING]\n\
us=\"In batchmode, use +force to allow overwriting of output files\\n\"\n\
\n\
[INCONSISTENT_RECIPIENT_SET]\n\
us=\"No algorithm available that all keys support.\\n\"\n\
\n\
[UNKNOWN_ERROR]\n\
us=\"Unknown error code %i!\\n\"\n\
\n\
[VERIFY_REMOVE_KEY_PUBLIC_PRIVATE]\n\
us=\"\\nDo you wish to remove this key from your public and private \\\n\
keyrings?\\n[y/N]? \"\n\
\n\
[UNABLE_TO_ITERATE_KEY]\n\
us=\"Unable to iterate key!\\n\";\n\
\n\
[CANCELED]\n\
us=\"Canceled.\\n\"\n\
\n\
[REMOVED]\n\
us=\"Removed.\\n\"\n\
\n\
[NEED_FILE_TO_SAVE]\n\
us=\"Save file as [%s] \"\n\
\n\
[PGP_NEWTRUST_NOT_TRUSTED_SIGNING_KEY]\n\
us=\"WARNING: The signing key is not trusted to belong to:\\n\"\n\
\n\
[TO_DISABLE_OR_ENABLE]\n\
us=\"to disable or enable\"\n\
\n\
[TO_EDIT]\n\
us=\"to edit\"\n\
\n\
[SELECTED_KEY_HAS_ONLY_ONE_USERID]\n\
us=\"Selected key has only one user ID, can't be selected %s\\n\"\n\
\n\
[NO_DEFAULT_PRIVATE_KEY]\n\
us=\"No default private key\\n\"\n\
\n\
[MULTIPLE_RECIPIENTS_MATCHED]\n\
us=\"WARNING:  %i matches were found for recipient %s.\\n\\\n\
This may not be what you intended.\\n\"\n\
\n\
[ENOUGH_THANK_YOU]\n\
us=\"\\a -Enough, thank you.\\n\"\n\
\n\
[SEEDING_RANDPOOL_FROM_DEVICE]\n\
us=\"Seeding entropy pool with up to %u bits from %s...\\n\"\n\
\n\
[COMPLETE_READ_NUM_BITS]\n\
us=\"Complete.  Read %u bits.\\n\"\n\
\n\
[RSA_AND_DH_RECIPS]\n\
us=\"WARNING:  You are encrypting to both RSA and Diffie-Hellman keys.\\n\\\n\
If the RSA user is still using PGP version 2.6.3 or earlier; 4.0; or 4.5,\\n\\\n\
she will not be able to decrypt this message.\\n\"\n\
\n\
[ONLY_ONE_USER_ALLOWED]\n\
us=Specified operation may only be performed on one argument per execution.\\n\n\
\n\
[CANNOT_DISABLE_AXIOMATIC_KEYS]\n\
us=You cannot disable an axiomatic key.  Use pgpk -e to change your\\n\\\n\
trust of this key, first.\\n\n\
\n\
[RETRIEVING_URL]\n\
us=\"Retreiving %s:/%s:%i%s\\n\"\n\
\n\
[ADD_THESE_KEYS]\n\
us=\"\\nAdd these keys to your keyring? [Y/n] \"\n\
\n\
[ABORTED]\n\
us=\"\\nAborted.\\n\"\n\
\n\
[WARNING_NO_MRK]\n\
us=\"A requested Message Recovery Key (MRK) for this key was not\\\n\
found.\\n\"\n\
\n\
[MRK_FOUND]\n\
us=\"Message Recovery Key (MRK) found.  Will also encrypt this message\\n\\\n\
to Key ID %s.\\n\"\n\
\n\
#Everything from here down is automatically generated.\n\
\n\
[PGPERR_OK]\n\
us=\"No errors\\n\"\n\
\n\
[PGPERR_GENERIC]\n\
us=\"Generic error (should be changed)\\n\"\n\
\n\
[PGPERR_NOMEM]\n\
us=\"Out of Memory\\n\"\n\
\n\
[PGPERR_BADPARAM]\n\
us=\"Invalid Parameter\\n\"\n\
\n\
[PGPERR_NO_FILE]\n\
us=\"Cannot open file\\n\"\n\
\n\
[PGPERR_NO_KEYBITS]\n\
us=\"Internal keyring bits exhausted\\n\"\n\
\n\
[PGPERR_BAD_HASHNUM]\n\
us=\"Unknown hash number\\n\"\n\
\n\
[PGPERR_BAD_CIPHERNUM]\n\
us=\"Unknown cipher number\\n\"\n\
\n\
[PGPERR_BAD_KEYLEN]\n\
us=\"Illegal key length for cipher\\n\"\n\
\n\
[PGPERR_SIZEADVISE]\n\
us=\"SizeAdvise promise not kept\\n\"\n\
\n\
[PGPERR_CONFIG]\n\
us=\"Error parsing configuration\\n\"\n\
\n\
[PGPERR_CONFIG_BADFUNC]\n\
us=\"Invalid configuration function\\n\"\n\
\n\
[PGPERR_CONFIG_BADOPT]\n\
us=\"Unknown configuration option\\n\"\n\
\n\
[PGPERR_STRING_NOT_FOUND]\n\
us=\"Requested string not found\\n\"\n\
\n\
[PGPERR_STRING_NOT_IN_LANGUAGE]\n\
us=\"Requested string not in language\\n\"\n\
\n\
[PGPERR_KEY_ISLOCKED]\n\
us=\"Key requires passphrase to unlock\\n\"\n\
\n\
[PGPERR_KEY_UNUNLOCKABLE]\n\
us=\"Key requires passphrase each time\\n\"\n\
\n\
[PGPERR_SIG_ERROR]\n\
us=\"Error while processing signature\\n\"\n\
\n\
[PGPERR_ADDSIG_ERROR]\n\
us=\"Cannot add signature\\n\"\n\
\n\
[PGPERR_CANNOT_DECRYPT]\n\
us=\"Cannot decrypt message\\n\"\n\
\n\
[PGPERR_ADDESK_ERROR]\n\
us=\"Cannot add encrypted session key\\n\"\n\
\n\
[PGPERR_UNK_STRING2KEY]\n\
us=\"Don't know how to convert pass\\n\"\n\
\n\
[PGPERR_BAD_STRING2KEY]\n\
us=\"Invalid conversion from pass\\n\"\n\
\n\
[PGPERR_ESK_BADTYPE]\n\
us=\"Unknown encrypted session key type\\n\"\n\
\n\
[PGPERR_ESK_TOOSHORT]\n\
us=\"Encrypted session key too short\\n\"\n\
\n\
[PGPERR_ESK_TOOLONG]\n\
us=\"Encrypted session key too long\\n\"\n\
\n\
[PGPERR_ESK_BADVERSION]\n\
us=\"Encrypted session key version\\n\"\n\
\n\
[PGPERR_ESK_BADALGORITHM]\n\
us=\"Encrypted session key algorithm\\n\"\n\
\n\
[PGPERR_ESK_BITSWRONG]\n\
us=\"Wrong number of bits in ESK\\n\"\n\
\n\
[PGPERR_ESK_NOKEY]\n\
us=\"Can't find key to decrypt session key\\n\"\n\
\n\
[PGPERR_ESK_NODECRYPT]\n\
us=\"Can't decrypt this session key\\n\"\n\
\n\
[PGPERR_ESK_BADPASS]\n\
us=\"Passphrase incorrect\\n\"\n\
\n\
[PGPERR_SIG_BADTYPE]\n\
us=\"Unknown signature type\\n\"\n\
\n\
[PGPERR_SIG_TOOSHORT]\n\
us=\"Signature too short\\n\"\n\
\n\
[PGPERR_SIG_TOOLONG]\n\
us=\"Signature too long\\n\"\n\
\n\
[PGPERR_SIG_BADVERSION]\n\
us=\"Signature version unknown\\n\"\n\
\n\
[PGPERR_SIG_BADALGORITHM]\n\
us=\"Signature algorithm unknown\\n\"\n\
\n\
[PGPERR_SIG_BITSWRONG]\n\
us=\"Wrong number of bits in signature\\n\"\n\
\n\
[PGPERR_SIG_NOKEY]\n\
us=\"Can't find necessary key to check sig\\n\"\n\
\n\
[PGPERR_SIG_BADEXTRA]\n\
us=\"Invalid Extra Data for Signature\\n\"\n\
\n\
[PGPERR_NO_PUBKEY]\n\
us=\"No public key found\\n\"\n\
\n\
[PGPERR_NO_SECKEY]\n\
us=\"No secret key found\\n\"\n\
\n\
[PGPERR_UNKNOWN_KEYID]\n\
us=\"No matching keyid found\\n\"\n\
\n\
[PGPERR_NO_RECOVERYKEY]\n\
us=\"Requested message recovery key\\n\"\n\
\n\
[PGPERR_COMMIT_INVALID]\n\
us=\"Invalid commit response\\n\"\n\
\n\
[PGPERR_CANNOT_HASH]\n\
us=\"Cannot hash message\\n\"\n\
\n\
[PGPERR_UNBALANCED_SCOPE]\n\
us=\"Unbalanced scope\\n\"\n\
\n\
[PGPERR_WRONG_SCOPE]\n\
us=\"Data sent in wrong scope\\n\"\n\
\n\
[PGPERR_UI_INVALID]\n\
us=\"Invalid UI Callback Object\\n\"\n\
\n\
[PGPERR_CB_INVALID]\n\
us=\"Invalid Parser Callback\\n\"\n\
\n\
[PGPERR_INTERRUPTED]\n\
us=\"Interrupted encrypt/decrypt\\n\"\n\
\n\
[PGPERR_PUBKEY_TOOSMALL]\n\
us=\"Public Key too small for data\\n\"\n\
\n\
[PGPERR_PUBKEY_TOOBIG]\n\
us=\"Public key is too big for this version\\n\"\n\
\n\
[PGPERR_PUBKEY_UNIMP]\n\
us=\"Unimplemented public key operation\\n\"\n\
\n\
[PGPERR_RSA_CORRUPT]\n\
us=\"Corrupt data decrypting RSA block\\n\"\n\
\n\
[PGPERR_PK_CORRUPT]\n\
us=\"Corrupt data decrypting public\\n\"\n\
\n\
[PGPERR_CMD_TOOBIG]\n\
us=\"Command to Buffer too big\\n\"\n\
\n\
[PGPERR_FIFO_READ]\n\
us=\"Incomplete read from Fifo\\n\"\n\
\n\
[PGPERR_VRFYSIG_WRITE]\n\
us=\"Data illegally written into\\n\"\n\
\n\
[PGPERR_VRFYSIG_BADANN]\n\
us=\"Invalid annotation to signature\\n\"\n\
\n\
[PGPERR_ADDHDR_FLUSH]\n\
us=\"Cannot flush buffer until size\\n\"\n\
\n\
[PGPERR_JOIN_BADANN]\n\
us=\"Invalid annotation to join module\\n\"\n\
\n\
[PGPERR_RANDSEED_TOOSMALL]\n\
us=\"Not enough data in randseed file\\n\"\n\
\n\
[PGPERR_ENV_LOWPRI]\n\
us=\"Env Var not set: priority too low\\n\"\n\
\n\
[PGPERR_ENV_BADVAR]\n\
us=\"Invalid environment variable\\n\"\n\
\n\
[PGPERR_CHARMAP_UNKNOWN]\n\
us=\"Unknown Charset\\n\"\n\
\n\
[PGPERR_FILE_PERMISSIONS]\n\
us=\"Unsufficient file permissions\\n\"\n\
\n\
[PGPERR_FILE_WRITELOCKED]\n\
us=\"File already open for writing\\n\"\n\
\n\
[PGPERR_FILE_BADOP]\n\
us=\"Invalid PgpFile Operation\\n\"\n\
\n\
[PGPERR_FILE_OPFAIL]\n\
us=\"PgpFile Operation Failed\\n\"\n\
\n\
[PGPERR_IMMUTABLE]\n\
us=\"Attempt to change an\\n\"\n\
\n\
[PGPERR_PARSEASC_INCOMPLETE]\n\
us=\"Ascii Armor Input Incomplete\\n\"\n\
\n\
[PGPERR_PARSEASC_BADINPUT]\n\
us=\"PGP text input is corrupted\\n\"\n\
\n\
[PGPERR_FILEFIFO_SEEK]\n\
us=\"Temp-File Seek Error\\n\"\n\
\n\
[PGPERR_FILEFIFO_WRITE]\n\
us=\"Temp-File Write Error\\n\"\n\
\n\
[PGPERR_FILEFIFO_READ]\n\
us=\"Temp-File Read Error\\n\"\n\
\n\
[PGPERR_FILEIO_BADPKT]\n\
us=\"Corrupted or bad packet in\\n\"\n\
\n\
[PGPERR_SYSTEM_PGPK]\n\
us=\"Error Executing PGPK Program\\n\"\n\
\n\
[PGPERR_KEYIO_READING]\n\
us=\"I/O error reading keyring\\n\"\n\
\n\
[PGPERR_KEYIO_WRITING]\n\
us=\"I/O error writing keyring\\n\"\n\
\n\
[PGPERR_KEYIO_FTELL]\n\
us=\"I/O error finding keyring position\\n\"\n\
\n\
[PGPERR_KEYIO_SEEKING]\n\
us=\"I/O error seeking keyring\\n\"\n\
\n\
[PGPERR_KEYIO_OPENING]\n\
us=\"I/O error opening keyring\\n\"\n\
\n\
[PGPERR_KEYIO_CLOSING]\n\
us=\"I/O error closing keyring\\n\"\n\
\n\
[PGPERR_KEYIO_FLUSHING]\n\
us=\"I/O error flushing keyring\\n\"\n\
\n\
[PGPERR_KEYIO_EOF]\n\
us=\"Unexpected EOF fetching key packet\\n\"\n\
\n\
[PGPERR_KEYIO_BADPKT]\n\
us=\"Bad data found where key\\n\"\n\
\n\
[PGPERR_KEYIO_BADFILE]\n\
us=\"Not a keyring file\\n\"\n\
\n\
[PGPERR_TROUBLE_KEYSUBKEY]\n\
us=\"Key matches subkey\\n\"\n\
\n\
[PGPERR_TROUBLE_SIGSUBKEY]\n\
us=\"Signature by subkey\\n\"\n\
\n\
[PGPERR_TROUBLE_BADTRUST]\n\
us=\"Trust packet malformed\\n\"\n\
\n\
[PGPERR_TROUBLE_UNKPKTBYTE]\n\
us=\"Unknown packet byte in keyring\\n\"\n\
\n\
[PGPERR_TROUBLE_UNXSUBKEY]\n\
us=\"Unexpected subkey (before key)\\n\"\n\
\n\
[PGPERR_TROUBLE_UNXNAME]\n\
us=\"Unexpected name (before key)\\n\"\n\
\n\
[PGPERR_TROUBLE_UNXSIG]\n\
us=\"Unexpected sig (before key)\\n\"\n\
\n\
[PGPERR_TROUBLE_UNXUNK]\n\
us=\"Packet of unknown type in unexpected\\n\"\n\
\n\
[PGPERR_TROUBLE_UNXTRUST]\n\
us=\"Unexpected trust packet\\n\"\n\
\n\
[PGPERR_TROUBLE_KEY2BIG]\n\
us=\"Key grossly oversized\\n\"\n\
\n\
[PGPERR_TROUBLE_SEC2BIG]\n\
us=\"Secret key grossly oversized\\n\"\n\
\n\
[PGPERR_TROUBLE_NAME2BIG]\n\
us=\"Name grossly oversized\\n\"\n\
\n\
[PGPERR_TROUBLE_SIG2BIG]\n\
us=\"Sig grossly oversized\\n\"\n\
\n\
[PGPERR_TROUBLE_UNK2BIG]\n\
us=\"Packet of unknown type too large\\n\"\n\
\n\
[PGPERR_TROUBLE_DUPKEYID]\n\
us=\"Duplicate KeyID, different keys\\n\"\n\
\n\
[PGPERR_TROUBLE_DUPKEY]\n\
us=\"Duplicate key (in same keyring)\\n\"\n\
\n\
[PGPERR_TROUBLE_DUPSEC]\n\
us=\"Duplicate secret (in same keyring)\\n\"\n\
\n\
[PGPERR_TROUBLE_DUPNAME]\n\
us=\"Duplicate name (in same keyring)\\n\"\n\
\n\
[PGPERR_TROUBLE_DUPSIG]\n\
us=\"Duplicate signature (in same keyring)\\n\"\n\
\n\
[PGPERR_TROUBLE_DUPUNK]\n\
us=\"Duplicate unknown \\\"thing\\\" in keyring\\n\"\n\
\n\
[PGPERR_TROUBLE_BAREKEY]\n\
us=\"Key found with no names\\n\"\n\
\n\
[PGPERR_TROUBLE_VERSION_BUG_PREV]\n\
us=\"Bug introduced by legal_kludge\\n\"\n\
\n\
[PGPERR_TROUBLE_VERSION_BUG_CUR]\n\
us=\"Bug introduced by legal_kludge\\n\"\n\
\n\
[PGPERR_TROUBLE_OLDSEC]\n\
us=\"Passphrase is out of date\\n\"\n\
\n\
[PGPERR_TROUBLE_NEWSEC]\n\
us=\"Passphrase is newer than another\\n\"\n\
\n\
[PGPERR_KEY_NO_RSA_ENCRYPT]\n\
us=\"No RSA Encryption/Signature support\\n\"\n\
\n\
[PGPERR_KEY_NO_RSA_DECRYPT]\n\
us=\"No RSA Decryption/Verification support\\n\"\n\
\n\
[PGPERR_KEY_NO_RSA]\n\
us=\"No RSA key support\\n\"\n\
\n\
[PGPERR_KEY_LONG]\n\
us=\"Key packet has trailing junk\\n\"\n\
\n\
[PGPERR_KEY_SHORT]\n\
us=\"Key packet truncated\\n\"\n\
\n\
[PGPERR_KEY_VERSION]\n\
us=\"Key version unknown\\n\"\n\
\n\
[PGPERR_KEY_PKALG]\n\
us=\"Key algorithm unknown\\n\"\n\
\n\
[PGPERR_KEY_MODMPI]\n\
us=\"Key modulus mis-formatted\\n\"\n\
\n\
[PGPERR_KEY_EXPMPI]\n\
us=\"Key exponent mis-formatted\\n\"\n\
\n\
[PGPERR_KEY_MODEVEN]\n\
us=\"RSA public modulus is even\\n\"\n\
\n\
[PGPERR_KEY_EXPEVEN]\n\
us=\"RSA public exponent is even\\n\"\n\
\n\
[PGPERR_KEY_MPI]\n\
us=\"Key component mis-formatted\\n\"\n\
\n\
[PGPERR_KEY_UNSUPP]\n\
us=\"Key is not supported by this version of PGP\\n\"\n\
\n\
[PGPERR_SIG_LONG]\n\
us=\"Signature packet has trailing junk\\n\"\n\
\n\
[PGPERR_SIG_SHORT]\n\
us=\"Signature truncated\\n\"\n\
\n\
[PGPERR_SIG_MPI]\n\
us=\"Signature integer mis-formatted\\n\"\n\
\n\
[PGPERR_SIG_PKALG]\n\
us=\"Signature algorithm unknown\\n\"\n\
\n\
[PGPERR_SIG_EXTRALEN]\n\
us=\"Bad signature extra material (not 5)\\n\"\n\
\n\
[PGPERR_SIG_VERSION]\n\
us=\"Signature version unknown\\n\"\n\
\n\
[PGPERR_KEYDB_BADPASSPHRASE]\n\
us=\"Bad passphrase\\n\"\n\
\n\
[PGPERR_KEYDB_KEYDBREADONLY]\n\
us=\"Key database is read-only\\n\"\n\
\n\
[PGPERR_KEYDB_NEEDMOREBITS]\n\
us=\"Insufficient random bits\\n\"\n\
\n\
[PGPERR_KEYDB_OBJECTREADONLY]\n\
us=\"Object is read-only\\n\"\n\
\n\
[PGPERR_KEYDB_INVALIDPROPERTY]\n\
us=\"Invalid property name\\n\"\n\
\n\
[PGPERR_KEYDB_BUFFERTOOSHORT]\n\
us=\"Buffer too short\\n\"\n\
\n\
[PGPERR_KEYDB_CORRUPT]\n\
us=\"Key database is corrupt\\n\"\n\
\n\
[PGPERR_KEYDB_VERSIONTOONEW]\n\
us=\"Data is too new to be read\\n\"\n\
\n\
[PGPERR_KEYDB_IOERROR]\n\
us=\"Input/output error\\n\"\n\
\n\
[PGPERR_KEYDB_VALUETOOLONG]\n\
us=\"Value too long\\n\"\n\
\n\
[PGPERR_KEYDB_DUPLICATE_CERT]\n\
us=\"Duplicate certification\\n\"\n\
\n\
[PGPERR_KEYDB_DUPLICATE_USERID]\n\
us=\"Duplicate UserID\\n\"\n\
\n\
[PGPERR_KEYDB_CERTIFYINGKEY_DEAD]\n\
us=\"Certifying key no longer\\n\"\n\
\n\
[PGPERR_KEYDB_OBJECT_DELETED]\n\
us=\"Object has been deleted\\n\"\n\
\n\
";
