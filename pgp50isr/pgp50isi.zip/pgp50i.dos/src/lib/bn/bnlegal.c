/*
* bnlegal.c
*
* Copyright (C) 1995-1997 Pretty Good Privacy, Inc. All rights reserved.
*
* $Id: bnlegal.c,v 1.2.2.1 1997/06/07 09:49:39 mhw Exp $
*/

#ifndef HAVE_CONFIG_H
#define HAVE_CONFIG_H 0
#endif
#if HAVE_CONFIG_H
#include "config.h"	 /* For "const"! */
#endif

/* Force inclusion of this... */
#include "bnlegal.h"
volatile const char bnCopyright[] =
	"\0bnlib 1.1.2 Copyright (C) 1995-1997 Pretty Good Privacy, Inc."
	"  All rights reserved.";
