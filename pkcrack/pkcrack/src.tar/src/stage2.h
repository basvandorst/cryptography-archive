/* pkcrack - stage2.h
 *
 * (C) by Peter Conrad <conrad@unix-ag.uni-kl.de>
 *
 * $Id: stage2.h,v 1.2 1996/06/12 09:47:26 conrad Release $
 *
 * $Log: stage2.h,v $
 * Revision 1.2  1996/06/12 09:47:26  conrad
 * Release version
 *
 * Revision 1.1  1996/06/10 18:07:33  conrad
 * Initial revision
 *
 */

extern void buildKey2Lists( uword aKey2_13 );
extern void initMulTab( );

extern uword	loesung0, loesung1, loesung2;

