/* pkcrack - mktemptbl.c
 *
 * (C) by Peter Conrad <conrad@unix-ag.uni-kl.de>
 *
 * $Id: mktemptbl.c,v 1.2 1996/06/12 09:47:17 conrad Release $
 *
 * $Log: mktemptbl.c,v $
 * Revision 1.2  1996/06/12 09:47:17  conrad
 * Release version
 *
 * Revision 1.1  1996/06/10 17:52:22  conrad
 * Initial revision
 *
 */

static char RCSID[]="$Id: mktemptbl.c,v 1.2 1996/06/12 09:47:17 conrad Release $";

#include <stdio.h>
#include <sys/types.h>

#define byte	unsigned char

ushort tempTable[256][64];

static int numEntries[256];

void preCompTemp( )
{
ushort	temp;
byte	key3;

    for( temp = 0; temp < 256; temp++ )
	numEntries[temp] = 0;

    temp = 65532;
    do{
	temp += 4;
	key3 = (((temp|2) * (temp|3))>>8)&0xff;
	tempTable[key3][numEntries[key3]++] = temp;
	if( numEntries[key3] > 64 )
	    fprintf( stderr, "Warning! Lookup-table corrupted!\n" );
    }while( temp < 65532 );
}

