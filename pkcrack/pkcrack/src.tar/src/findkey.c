/* pkcrack - findkey.c
 *
 * (C) by Peter Conrad <conrad@unix-ag.uni-kl.de>
 *
 * $Id: findkey.c,v 1.1 1996/06/10 17:41:53 conrad Exp $
 *
 * $Log: findkey.c,v $
 * Revision 1.1  1996/06/10 17:41:53  conrad
 * Initial revision
 *
 *
 */

#include <sys/types.h>
#include "pkcrack.h"
#include "stage3.h"
#include "crc.h"

main( )
{
uword	key0, key1, key2;

    mkCrcTab( );
    initStage3Tab( );

    printf( "Enter key0-value (in hex): " );
    scanf( "%x", &key0 );
    printf( "Enter key1-value (in hex): " );
    scanf( "%x", &key1 );
    printf( "Enter key2-value (in hex): " );
    scanf( "%x", &key2 );

    findPwd( key0, key1, key2 );
}

