/* pkcrack - mktemptbl.h
 *
 * (C) by Peter Conrad <conrad@unix-ag.uni-kl.de>
 *
 * $Id: mktemptbl.h,v 1.2 1996/06/12 09:47:18 conrad Release $
 *
 * $Log: mktemptbl.h,v $
 * Revision 1.2  1996/06/12 09:47:18  conrad
 * Release version
 *
 * Revision 1.1  1996/06/10 17:53:41  conrad
 * Initial revision
 *
 */

#include <sys/types.h>

extern ushort tempTable[256][64];
extern void   preCompTemp( void );

