/* pkcrack - pkcrack.h
 *
 * (C) by Peter Conrad <conrad@unix-ag.uni-kl.de>
 *
 * $Id: pkcrack.h,v 1.2 1996/06/12 09:47:20 conrad Release $
 *
 * $Log: pkcrack.h,v $
 * Revision 1.2  1996/06/12 09:47:20  conrad
 * Release version
 *
 * Revision 1.1  1996/06/10 17:55:27  conrad
 * Initial revision
 *
 */

#define byte	unsigned char /*  8 bit wide */
#define uword	unsigned int  /* 32 bit wide */

#define	MAXFILELEN	40000
#define	KEY2SPACE	((1<<22)+(1<<20))	/* some more just for safety */

#define	KEY3(i)	(plaintext[(i)]^ciphertext[(i)])

extern byte	plaintext[MAXFILELEN], ciphertext[MAXFILELEN];
extern uword	key2i[KEY2SPACE];
extern int	numKey2s;

