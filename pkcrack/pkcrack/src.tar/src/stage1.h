/* pkcrack - stage1.h
 *
 * (C) by Peter Conrad <conrad@unix-ag.uni-kl.de>
 *
 * $Id: stage1.h,v 1.2 1996/06/12 09:47:23 conrad Release $
 *
 * $Log: stage1.h,v $
 * Revision 1.2  1996/06/12 09:47:23  conrad
 * Release version
 *
 * Revision 1.1  1996/06/10 18:02:56  conrad
 * Initial revision
 *
 */

extern void generate1stSetOfKey2s( int n );
extern void reduceKey2s( int i );

