/* R_RANDOM.H - header file for R_RANDOM.C
 */

/* Copyright (C) 1991-2 RSA Laboratories, a division of RSA Data
   Security, Inc. All rights reserved.
 */

int R_GenerateBytes PROTO_LIST
  ((unsigned char *, unsigned int, R_RANDOM_STRUCT *));
